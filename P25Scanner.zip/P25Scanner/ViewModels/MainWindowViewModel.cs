using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reactive;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.Extensions.Logging;
using P25Scanner.Models;
using P25Scanner.Services;
using ReactiveUI;
using ReactiveUI.Fody.Helpers;

namespace P25Scanner.ViewModels
{
    /// <summary>
    /// Main view model for the P25Scanner application.
    /// Coordinates RTLSDRService, AudioService, and P25Decoder to provide
    /// scanner functionality through a reactive UI.
    /// </summary>
    public class MainWindowViewModel : ReactiveObject, IActivatableViewModel, IDisposable
    {
        private readonly ILogger<MainWindowViewModel> _logger;
        private readonly RtlSdrService _rtlSdrService;
        private readonly AudioService _audioService;
        private readonly P25Decoder _p25Decoder;
        private readonly CompositeDisposable _disposables = new CompositeDisposable();
        private bool _isDisposed;
        private System.Timers.Timer _recordingTimer;
        /// <summary>
        /// Gets the activator that coordinates activation and deactivation of the view model.
        /// </summary>
        public ViewModelActivator Activator { get; }

        #region Properties

        /// <summary>
        /// Gets or sets the minimum frequency in Hz.
        /// </summary>
        [Reactive]
        public ulong MinFrequency { get; set; } = 24_000_000; // 24 MHz

        /// <summary>
        /// Gets or sets the maximum frequency in Hz.
        /// </summary>
        [Reactive]
        public ulong MaxFrequency { get; set; } = 1_700_000_000; // 1.7 GHz

        /// <summary>
        /// Gets or sets the selected frequency in Hz.
        /// </summary>
        [Reactive]
        public ulong Frequency { get; set; } = 853_000_000; // Default to 853 MHz

        /// <summary>
        /// Gets or sets the minimum gain value in dB.
        /// </summary>
        [Reactive]
        public double MinGain { get; set; } = 0.0;

        /// <summary>
        /// Gets or sets the maximum gain value in dB.
        /// </summary>
        [Reactive]
        public double MaxGain { get; set; } = 49.6;

        /// <summary>
        /// Gets or sets the gain value in dB.
        /// </summary>
        [Reactive]
        public double Gain { get; set; } = 32.8; // Default gain value

        /// <summary>
        /// Gets or sets a value indicating whether automatic gain control is enabled.
        /// </summary>
        [Reactive]
        public bool IsAgcEnabled { get; set; } = true;

        /// <summary>
        /// Gets or sets a value indicating whether the scanner is currently running.
        /// </summary>
        [Reactive]
        public bool IsScanning { get; set; }

        /// <summary>
        /// Gets or sets the audio volume (0.0 - 1.0).
        /// </summary>
        [Reactive]
        public double Volume { get; set; } = 0.8;

        /// <summary>
        /// Gets or sets a value indicating whether audio output is muted.
        /// </summary>
        [Reactive]
        public bool IsMuted { get; set; }

        /// <summary>
        /// Gets the collection of available RTL-SDR devices.
        /// </summary>
        [Reactive]
        public ObservableCollection<DeviceInfo> AvailableDevices { get; private set; } = new ObservableCollection<DeviceInfo>();

        /// <summary>
        /// Gets or sets the selected RTL-SDR device.
        /// </summary>
        [Reactive]
        public DeviceInfo SelectedDevice { get; set; }

        /// <summary>
        /// Gets the collection of available audio output devices.
        /// </summary>
        [Reactive]
        public ObservableCollection<string> AudioDevices { get; private set; } = new ObservableCollection<string>();

        /// <summary>
        /// Gets or sets the selected audio output device.
        /// </summary>
        [Reactive]
        public string SelectedAudioDevice { get; set; }

        /// <summary>
        /// Gets the collection of available sample rates.
        /// </summary>
        [Reactive]
        public ObservableCollection<uint> SampleRates { get; private set; } = new ObservableCollection<uint>();

        /// <summary>
        /// Gets or sets the selected sample rate.
        /// </summary>
        [Reactive]
        public uint SelectedSampleRate { get; set; } = 2_048_000; // Default to 2.048 MSPS

        /// <summary>
        /// Gets the collection of active talkgroups.
        /// </summary>
        [Reactive]
        public ObservableCollection<Talkgroup> ActiveTalkgroups { get; private set; } = new ObservableCollection<Talkgroup>();

        /// <summary>
        /// Gets the status message to display to the user.
        /// </summary>
        [Reactive]
        public string StatusMessage { get; private set; } = "Ready";

        /// <summary>
        /// Gets or sets the currently active talkgroup.
        /// </summary>
        [Reactive]
        public Talkgroup CurrentTalkgroup { get; set; }

        /// <summary>
        /// Gets a value indicating whether a device is selected and ready.
        /// </summary>
        [Reactive]
        public bool IsDeviceReady { get; private set; }

        /// <summary>
        /// Gets the current device connection status.
        /// </summary>
        [Reactive]
        public DeviceConnectionStatus ConnectionStatus { get; private set; } = DeviceConnectionStatus.Disconnected;

        /// <summary>
        /// Gets the current signal strength in dBFS.
        /// </summary>
        [Reactive]
        public double SignalStrength { get; private set; } = -120.0;

        /// <summary>
        /// Gets the peak signal strength in dBFS.
        /// </summary>
        [Reactive]
        public double PeakSignalStrength { get; private set; } = -120.0;

        /// <summary>
        /// Gets or sets the squelch level in dBFS.
        /// </summary>
        [Reactive]
        public double SquelchLevel { get; set; } = -70.0;

        /// <summary>
        /// Gets a value indicating whether the signal is above the squelch threshold.
        /// </summary>
        [Reactive]
        public bool IsSignalActive { get; private set; }

        /// <summary>
        /// Gets or sets a value indicating whether recording is active.
        /// </summary>
        [Reactive]
        public bool IsRecording { get; private set; }

        /// <summary>
        /// Gets the current recording duration.
        /// </summary>
        [Reactive]
        public TimeSpan RecordingDuration { get; private set; } = TimeSpan.Zero;

        /// <summary>
        /// Gets the current recording file path.
        /// </summary>
        [Reactive]
        public string RecordingFilePath { get; private set; }

        #endregion

        #region Commands

        /// <summary>
        /// Gets the command to start the scanner.
        /// </summary>
        public ReactiveCommand<Unit, Unit> StartScanCommand { get; private set; }

        /// <summary>
        /// Gets the command to stop the scanner.
        /// </summary>
        public ReactiveCommand<Unit, Unit> StopScanCommand { get; private set; }

        /// <summary>
        /// Gets the command to refresh the list of available devices.
        /// </summary>
        public ReactiveCommand<Unit, Unit> RefreshDevicesCommand { get; private set; }

        /// <summary>
        /// Gets the command to tune to a specific frequency.
        /// </summary>
        public ReactiveCommand<Unit, Unit> TuneCommand { get; private set; }

        /// <summary>
        /// Gets the command to save the current settings.
        /// </summary>
        public ReactiveCommand<Unit, Unit> SaveSettingsCommand { get; private set; }

        /// <summary>
        /// Gets the command to load saved settings.
        /// </summary>
        public ReactiveCommand<Unit, Unit> LoadSettingsCommand { get; private set; }

        /// <summary>
        /// Gets the command to start recording audio.
        /// </summary>
        public ReactiveCommand<Unit, Unit> StartRecordingCommand { get; private set; }

        /// <summary>
        /// Gets the command to stop recording audio.
        /// </summary>
        public ReactiveCommand<Unit, Unit> StopRecordingCommand { get; private set; }

        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="MainWindowViewModel"/> class.
        /// </summary>
        /// <param name="logger">The logger instance.</param>
        /// <param name="rtlSdrService">The RTL-SDR service.</param>
        /// <param name="audioService">The audio service.</param>
        /// <param name="p25Decoder">The P25 decoder.</param>
        public MainWindowViewModel(
            ILogger<MainWindowViewModel> logger,
            RtlSdrService rtlSdrService,
            AudioService audioService,
            P25Decoder p25Decoder)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _rtlSdrService = rtlSdrService ?? throw new ArgumentNullException(nameof(rtlSdrService));
            _audioService = audioService ?? throw new ArgumentNullException(nameof(audioService));
            _p25Decoder = p25Decoder ?? throw new ArgumentNullException(nameof(p25Decoder));

            Activator = new ViewModelActivator();

            // Initialize commands
            SetupCommands();
            
            // Setup wire event handlers to service events
            SetupEventHandlers();

            // Setup property observers
            SetupPropertyObservers();

            this.WhenActivated(disposables =>
            {
                // Code to execute when the view model is activated
                _logger.LogInformation("MainWindowViewModel activated");
                
                // Load available devices on activation
                _ = Task.Run(LoadAvailableDevicesAsync);
                
                // Setup audio service
                _audioService.InitializeAudio();
                
                // Load audio devices
                _ = Task.Run(LoadAudioDevicesAsync);
                
                // Initialize sample rates
                InitializeSampleRates();
                
                Disposable.Create(() => _logger.LogInformation("MainWindowViewModel deactivated"))
                    .DisposeWith(disposables);
            });
        }

        private void SetupCommands()
        {
            var canStart = this.WhenAnyValue(
                x => x.IsScanning,
                x => x.IsDeviceReady,
                (isScanning, isDeviceReady) => !isScanning && isDeviceReady);

            var canStop = this.WhenAnyValue(
                x => x.IsScanning,
                isScanning => isScanning);

            StartScanCommand = ReactiveCommand.CreateFromTask(StartScanningAsync, canStart);
            StopScanCommand = ReactiveCommand.Create(StopScanning, canStop);
            RefreshDevicesCommand = ReactiveCommand.CreateFromTask(LoadAvailableDevicesAsync);
            TuneCommand = ReactiveCommand.CreateFromTask(TuneToFrequencyAsync);
            SaveSettingsCommand = ReactiveCommand.Create(SaveSettings);
            LoadSettingsCommand = ReactiveCommand.Create(LoadSettings);
            
            var canStartRecording = this.WhenAnyValue(
                x => x.IsRecording,
                x => x.IsDeviceReady,
                (isRecording, isDeviceReady) => !isRecording && isDeviceReady);
            
            var canStopRecording = this.WhenAnyValue(
                x => x.IsRecording,
                isRecording => isRecording);
                
            StartRecordingCommand = ReactiveCommand.CreateFromTask(StartRecordingAsync, canStartRecording);
            StopRecordingCommand = ReactiveCommand.Create(StopRecording, canStopRecording);

            // Handle command errors
            StartScanCommand.ThrownExceptions
                .Subscribe(ex => HandleCommandError("Error starting scanner", ex))
                .DisposeWith(_disposables);

            StopScanCommand.ThrownExceptions
                .Subscribe(ex => HandleCommandError("Error stopping scanner", ex))
                .DisposeWith(_disposables);

            RefreshDevicesCommand.ThrownExceptions
                .Subscribe(ex => HandleCommandError("Error refreshing devices", ex))
                .DisposeWith(_disposables);

            TuneCommand.ThrownExceptions
                .Subscribe(ex => HandleCommandError("Error tuning to frequency", ex))
                .DisposeWith(_disposables);
                
            StartRecordingCommand.ThrownExceptions
                .Subscribe(ex => HandleCommandError("Error starting recording", ex))
                .DisposeWith(_disposables);
                
            StopRecordingCommand.ThrownExceptions
                .Subscribe(ex => HandleCommandError("Error stopping recording", ex))
                .DisposeWith(_disposables);
        }

        private void SetupEventHandlers()
        {
            // RTL-SDR service events
            _rtlSdrService.DeviceStatusChanged += (sender, args) =>
            {
                StatusMessage = args.StatusMessage;
                IsDeviceReady = args.IsConnected;
                ConnectionStatus = args.IsConnected ? 
                    DeviceConnectionStatus.Connected : 
                    (args.IsInitialized ? DeviceConnectionStatus.Initialized : DeviceConnectionStatus.Disconnected);
            };

            _rtlSdrService.IQDataAvailable += (sender, args) =>
            {
                try
                {
                    // Update signal strength
                    UpdateSignalStrength(args.IQData);
                    
                    // Forward IQ data to the P25 decoder
                    _p25Decoder.ProcessIQData(args.IQData, args.SampleRate);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error processing IQ data");
                }
            };

            // P25Decoder events
            _p25Decoder.DecodedAudioAvailable += (sender, args) =>
            {
                try
                {
                    if (!IsMuted)
                    {
                        // Send decoded audio to the audio service for playback
                        _audioService.PlayAudio(args.AudioData, args.SampleRate);
                        
                        // If recording, save the audio
                        if (IsRecording)
                        {
                            SaveRecordedAudio(args.AudioData, args.SampleRate);
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error playing decoded audio");
                }
            };

            _p25Decoder.TalkgroupActivity += (sender, args) =>
            {
                try
                {
                    // Update the current active talkgroup
                    CurrentTalkgroup = args.Talkgroup;

                    // Add to active talkgroups if not already present
                    if (!ActiveTalkgroups.Any(tg => tg.Id == args.Talkgroup.Id))
                    {
                        Application.Current.Dispatcher.Invoke(() =>
                        {
                            ActiveTalkgroups.Add(args.Talkgroup);
                        });
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error handling talkgroup activity");
                }
            };
        }

        private void SetupPropertyObservers()
        {
            // Update volume when Volume property changes
            this.WhenAnyValue(x => x.Volume)
                .Skip(1) // Skip initial value
                .Subscribe(volume =>
                {
                    _audioService.SetVolume(volume);
                })
                .DisposeWith(_disposables);

            // Update mute state when IsMuted property changes
            this.WhenAnyValue(x => x.IsMuted)
                .Skip(1) // Skip initial value
                .Subscribe(isMuted =>
                {
                    _audioService.SetMute(isMuted);
                })
                .DisposeWith(_disposables);

            // Update device when SelectedDevice changes
            this.WhenAnyValue(x => x.SelectedDevice)
                .Skip(1) // Skip initial value
                .Where(device => device != null)
                .Subscribe(async device =>
                {
                    try
                    {
                        await _rtlSdrService.SelectDeviceAsync(device.Index);
                        _logger.LogInformation($"Selected device: {device.Name}");
                        IsDeviceReady = true;
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, $"Error selecting device {device.Name}");
                        IsDeviceReady = false;
                    }
                })
                .DisposeWith(_disposables);
                
            // Update selected audio device when SelectedAudioDevice changes
            this.WhenAnyValue(x => x.SelectedAudioDevice)
                .Skip(1) // Skip initial value
                .Where(device => device != null)
                .Subscribe(device =>
                {
                    try
                    {
                        _audioService.SetOutputDevice(device);
                        _logger.LogInformation($"Selected audio device: {device}");
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, $"Error selecting audio device {device}");
                    }
                })
                .DisposeWith(_disposables);
                
            // Update sample rate when SelectedSampleRate changes
            this.WhenAnyValue(x => x.SelectedSampleRate)
                .Skip(1) // Skip initial value
                .Subscribe(async sampleRate =>
                {
                    try
                    {
                        if (IsScanning)
                        {
                            // Need to restart scanning with new sample rate
                            await StopScanningAsync();
                            await _rtlSdrService.SetSampleRateAsync(sampleRate);
                            await StartScanningAsync();
                        }
                        else
                        {
                            await _rtlSdrService.SetSampleRateAsync(sampleRate);
                        }
                        _logger.LogInformation($"Set sample rate to {sampleRate / 1_000_000.0:F3} MSPS");
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, $"Error setting sample rate to {sampleRate}");
                    }
                })
                .DisposeWith(_disposables);
                
            // Update the squelch function when the threshold changes
            this.WhenAnyValue(x => x.SquelchLevel)
                .Skip(1) // Skip initial value
                .Subscribe(level =>
                {
                    _p25Decoder.SetSquelchLevel(level);
                    _logger.LogInformation($"Set squelch level to {level:F1} dBFS");
                })
                .DisposeWith(_disposables);
        }

        private async Task LoadAvailableDevicesAsync()
        {
            try
            {
                StatusMessage = "Loading available devices...";
                var devices = await _rtlSdrService.GetAvailableDevicesAsync();
                
                Application.Current.Dispatcher.Invoke(() =>
                {
                    AvailableDevices.Clear();
                    foreach (var device in devices)
                    {
                        AvailableDevices.Add(device);
                    }
                });
                
                if (AvailableDevices.Count > 0 && SelectedDevice == null)
                {
                    SelectedDevice = AvailableDevices[0];
                }
                
                StatusMessage = $"Found {AvailableDevices.Count} devices";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading available devices");
                StatusMessage = "Error loading devices: " + ex.Message;
            }
        }
        
        private async Task LoadAudioDevicesAsync()
        {
            try
            {
                StatusMessage = "Loading audio devices...";
                var devices = await Task.Run(() => _audioService.GetAvailableOutputDevices());
                
                Application.Current.Dispatcher.Invoke(() =>
                {
                    AudioDevices.Clear();
                    foreach (var device in devices)
                    {
                        AudioDevices.Add(device);
                    }
                });
                
                if (AudioDevices.Count > 0 && string.IsNullOrEmpty(SelectedAudioDevice))
                {
                    SelectedAudioDevice = AudioDevices[0];
                }
                
                _logger.LogInformation($"Found {AudioDevices.Count} audio devices");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading available audio devices");
                StatusMessage = "Error loading audio devices: " + ex.Message;
            }
        }
        private async Task StartScanningAsync()
        {
            try
            {
                StatusMessage = "Starting scanner...";
                
                // Configure the device with current settings
                await _rtlSdrService.ConfigureDeviceAsync(Frequency, Gain, IsAgcEnabled);
                
                // Initialize P25 decoder
                _p25Decoder.Initialize();
                
                // Start RTL-SDR streaming
                await _rtlSdrService.StartStreamingAsync();
                
                IsScanning = true;
                StatusMessage = $"Scanning on {Frequency / 1_000_000.0:F3} MHz";
                
                _logger.LogInformation($"Started scanning on {Frequency / 1_000_000.0:F3} MHz with gain {Gain} dB");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error starting scanner");
                StatusMessage = "Error starting scanner: " + ex.Message;
                IsScanning = false;
            }
        }

        private void StopScanning()
        {
            try
            {
                StatusMessage = "Stopping scanner...";
                
                // Stop RTL-SDR streaming
                _rtlSdrService.StopStreaming();
                
                // Shutdown P25 decoder
                _p25Decoder.Shutdown();
                
                IsScanning = false;
                StatusMessage = "Scanner stopped";
                
                _logger.LogInformation("Scanner stopped");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error stopping scanner");
                StatusMessage = "Error stopping scanner: " + ex.Message;
            }
        }

        private async Task TuneToFrequencyAsync()
        {
            try
            {
                if (IsScanning)
                {
                    await _rtlSdrService.SetFrequencyAsync(Frequency);
                    StatusMessage = $"Tuned to {Frequency / 1_000_000.0:F3} MHz";
                    _logger.LogInformation($"Tuned to {Frequency / 1_000_000.0:F3} MHz");
                }
                else
                {
                    StatusMessage = "Start scanner before tuning";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error tuning to frequency");
                StatusMessage = "Error tuning: " + ex.Message;
            }
        }

        private void SaveSettings()
        {
            try
            {
                // Implementation left for actual settings service
                _logger.LogInformation("Settings saved");
                StatusMessage = "Settings saved";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error saving settings");
                StatusMessage = "Error saving settings: " + ex.Message;
            }
        }

        private void LoadSettings()
        {
            try
            {
                // Implementation for settings service
                StatusMessage = "Loading settings...";
                
                // Load frequency settings
                Frequency = Properties.Settings.Default.LastFrequency;
                MinFrequency = Properties.Settings.Default.MinFrequency;
                MaxFrequency = Properties.Settings.Default.MaxFrequency;
                
                // Load gain settings
                Gain = Properties.Settings.Default.LastGain;
                IsAgcEnabled = Properties.Settings.Default.AgcEnabled;
                
                // Load audio settings
                Volume = Properties.Settings.Default.Volume;
                IsMuted = Properties.Settings.Default.IsMuted;
                SquelchLevel = Properties.Settings.Default.SquelchLevel;
                
                // Load device settings
                string lastDeviceSerial = Properties.Settings.Default.LastDeviceSerial;
                if (!string.IsNullOrEmpty(lastDeviceSerial) && AvailableDevices.Count > 0)
                {
                    var device = AvailableDevices.FirstOrDefault(d => d.SerialNumber == lastDeviceSerial);
                    if (device != null)
                    {
                        SelectedDevice = device;
                    }
                }
                
                // Load sample rate
                uint savedSampleRate = Properties.Settings.Default.SampleRate;
                if (savedSampleRate > 0 && SampleRates.Contains(savedSampleRate))
                {
                    SelectedSampleRate = savedSampleRate;
                }
                
                // Load audio device
                string lastAudioDevice = Properties.Settings.Default.LastAudioDevice;
                if (!string.IsNullOrEmpty(lastAudioDevice) && AudioDevices.Contains(lastAudioDevice))
                {
                    SelectedAudioDevice = lastAudioDevice;
                }
                
                _logger.LogInformation("Settings loaded");
                StatusMessage = "Settings loaded";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading settings");
                StatusMessage = "Error loading settings: " + ex.Message;
            }
        }
        
        /// <summary>
        /// Initializes the available sample rates collection with commonly supported values.
        /// </summary>
        private void InitializeSampleRates()
        {
            try
            {
                // Common RTL-SDR sample rates
                List<uint> commonRates = new List<uint>
                {
                    240_000,
                    960_000,
                    1_024_000,
                    1_800_000,
                    2_048_000,
                    2_400_000,
                    2_560_000,
                    2_880_000,
                    3_200_000
                };
                
                SampleRates.Clear();
                foreach (var rate in commonRates)
                {
                    SampleRates.Add(rate);
                }
                
                // Default to 2.048 MSPS if not already set
                if (SelectedSampleRate == 0 || !SampleRates.Contains(SelectedSampleRate))
                {
                    SelectedSampleRate = 2_048_000;
                }
                
                _logger.LogInformation($"Initialized {SampleRates.Count} sample rates");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error initializing sample rates");
                StatusMessage = "Error initializing sample rates: " + ex.Message;
            }
        }
        
        /// <summary>
        /// Updates the signal strength based on the IQ data.
        /// </summary>
        /// <param name="iqData">The complex IQ data samples.</param>
        private void UpdateSignalStrength(Complex[] iqData)
        {
            try
            {
                if (iqData == null || iqData.Length == 0)
                    return;
                
                // Calculate signal power
                double signalPower = 0;
                foreach (var sample in iqData)
                {
                    // Power = I^2 + Q^2
                    double magnitude = (sample.Real * sample.Real) + (sample.Imaginary * sample.Imaginary);
                    signalPower += magnitude;
                }
                
                // Average power
                signalPower /= iqData.Length;
                
                // Convert to dBFS (decibels full scale)
                // 0 dBFS is maximum power, so we use log10 and multiply by 10 (power ratio)
                double signalDbfs = 10 * Math.Log10(signalPower);
                
                // Update signal strength properties
                SignalStrength = signalDbfs;
                
                // Update peak if current signal is stronger
                if (signalDbfs > PeakSignalStrength)
                {
                    PeakSignalStrength = signalDbfs;
                }
                
                // Update signal active flag based on squelch threshold
                IsSignalActive = signalDbfs > SquelchLevel;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating signal strength");
            }
        }
        
        /// <summary>
        /// Starts recording audio to a file.
        /// </summary>
        /// <returns>A task representing the asynchronous operation.</returns>
        private async Task StartRecordingAsync()
        {
            try
            {
                if (IsRecording)
                    return;
                
                StatusMessage = "Starting recording...";
                
                // Create recordings directory if it doesn't exist
                string recordingsPath = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                    "P25Scanner", 
                    "Recordings");
                
                Directory.CreateDirectory(recordingsPath);
                
                // Create a filename based on current date/time and frequency
                string fileName = $"P25_{DateTime.Now:yyyyMMdd_HHmmss}_{Frequency / 1000000.0:F3}MHz.wav";
                RecordingFilePath = Path.Combine(recordingsPath, fileName);
                
                // Initialize the audio recording
                await Task.Run(() => _audioService.StartRecording(RecordingFilePath));
                
                // Start the recording timer
                _recordingTimer = new System.Timers.Timer(1000); // Update every second
                _recordingTimer.Elapsed += (s, e) => 
                {
                    RecordingDuration = RecordingDuration.Add(TimeSpan.FromSeconds(1));
                };
                _recordingTimer.Start();
                
                IsRecording = true;
                StatusMessage = $"Recording to {fileName}";
                
                _logger.LogInformation($"Started recording to {RecordingFilePath}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error starting recording");
                StatusMessage = "Error starting recording: " + ex.Message;
                RecordingFilePath = null;
                IsRecording = false;
            }
        }
        
        /// <summary>
        /// Stops the current audio recording.
        /// </summary>
        private void StopRecording()
        {
            try
            {
                if (!IsRecording)
                    return;
                
                StatusMessage = "Stopping recording...";
                
                // Stop the recording timer
                if (_recordingTimer != null)
                {
                    _recordingTimer.Stop();
                    _recordingTimer.Dispose();
                    _recordingTimer = null;
                }
                
                // Stop the audio recording
                _audioService.StopRecording();
                
                IsRecording = false;
                StatusMessage = $"Recording saved to {Path.GetFileName(RecordingFilePath)}";
                
                _logger.LogInformation($"Stopped recording. File saved to {RecordingFilePath}");
                
                // Reset recording duration
                RecordingDuration = TimeSpan.Zero;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error stopping recording");
                StatusMessage = "Error stopping recording: " + ex.Message;
                IsRecording = false;
            }
        }
        
        /// <summary>
        /// Saves decoded audio data to the recording file.
        /// </summary>
        /// <param name="audioData">The audio data to save.</param>
        /// <param name="sampleRate">The sample rate of the audio data.</param>
        private void SaveRecordedAudio(float[] audioData, int sampleRate)
        {
            try
            {
                if (!IsRecording || audioData == null || audioData.Length == 0)
                    return;
                
                _audioService.WriteRecordingData(audioData);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error saving recorded audio");
                // Don't stop recording on error, just log it
            }
        }
        
        /// <summary>
        /// Stops any ongoing processes and cleanly disposes resources.
        /// </summary>
        private async Task StopScanningAsync()
        {
            try
            {
                // Use existing StopScanning method
                StopScanning();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error stopping scanning during async operation");
            }
        }

        /// <summary>
        /// Disposes resources used by the view model.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        
        /// <summary>
        /// Disposes resources used by the view model.
        /// </summary>
        /// <param name="disposing">True if called from Dispose(), false if called from finalizer.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (_isDisposed)
                return;
            
            if (disposing)
            {
                // Stop recording if active
                if (IsRecording)
                {
                    StopRecording();
                }
                
                // Stop scanning if active
                if (IsScanning)
                {
                    StopScanning();
                }
                
                // Dispose of timer if it exists
                if (_recordingTimer != null)
                {
                    _recordingTimer.Dispose();
                    _recordingTimer = null;
                }
                
                // Dispose of disposables collection
                _disposables.Dispose();
                
                _logger.LogInformation("MainWindowViewModel disposed");
            }
            
            _isDisposed = true;
        }
