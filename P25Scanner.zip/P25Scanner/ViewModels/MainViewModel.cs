using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Input;
using P25Scanner.Models;
using P25Scanner.Services;

namespace P25Scanner.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private readonly IP25Scanner _scanner;
        private bool _isScanning;
        private bool _isPaused;
        private double _currentFrequency;
        private string _statusMessage;
        private ScannerConfiguration _configuration;
        private Signal _selectedSignal;

        public MainViewModel(IP25Scanner scanner)
        {
            _scanner = scanner ?? throw new ArgumentNullException(nameof(scanner));
            Signals = new ObservableCollection<Signal>();
            
            // Initialize commands
            StartScanCommand = new RelayCommand(ExecuteStartScan, CanExecuteStartScan);
            StopScanCommand = new RelayCommand(ExecuteStopScan, CanExecuteStopScan);
            PauseScanCommand = new RelayCommand(ExecutePauseScan, CanExecutePauseScan);
            SaveConfigurationCommand = new RelayCommand(ExecuteSaveConfiguration, CanExecuteSaveConfiguration);
            
            // Set default values
            _configuration = new ScannerConfiguration
            {
                StartFrequency = 851000000,  // Default start frequency (851 MHz)
                EndFrequency = 866000000,    // Default end frequency (866 MHz)
                StepSize = 12500,            // Default step size (12.5 kHz)
                DwellTime = 100,             // Default dwell time in ms
                Gain = 20.0                  // Default gain in dB
            };
            
            StatusMessage = "Ready to scan";
            
            // Subscribe to scanner events
            _scanner.SignalDetected += OnSignalDetected;
            _scanner.FrequencyChanged += OnFrequencyChanged;
        }

        #region Properties

        public ObservableCollection<Signal> Signals { get; }

        public bool IsScanning
        {
            get => _isScanning;
            private set
            {
                if (_isScanning != value)
                {
                    _isScanning = value;
                    OnPropertyChanged();
                    // Update command availability
                    (StartScanCommand as RelayCommand)?.RaiseCanExecuteChanged();
                    (StopScanCommand as RelayCommand)?.RaiseCanExecuteChanged();
                    (PauseScanCommand as RelayCommand)?.RaiseCanExecuteChanged();
                }
            }
        }

        public bool IsPaused
        {
            get => _isPaused;
            private set
            {
                if (_isPaused != value)
                {
                    _isPaused = value;
                    OnPropertyChanged();
                    // Update command availability
                    (PauseScanCommand as RelayCommand)?.RaiseCanExecuteChanged();
                }
            }
        }

        public double CurrentFrequency
        {
            get => _currentFrequency;
            private set
            {
                if (Math.Abs(_currentFrequency - value) > 0.001)
                {
                    _currentFrequency = value;
                    OnPropertyChanged();
                }
            }
        }

        public string StatusMessage
        {
            get => _statusMessage;
            set
            {
                if (_statusMessage != value)
                {
                    _statusMessage = value;
                    OnPropertyChanged();
                }
            }
        }

        public ScannerConfiguration Configuration
        {
            get => _configuration;
            set
            {
                if (_configuration != value)
                {
                    _configuration = value;
                    OnPropertyChanged();
                }
            }
        }

        public Signal SelectedSignal
        {
            get => _selectedSignal;
            set
            {
                if (_selectedSignal != value)
                {
                    _selectedSignal = value;
                    OnPropertyChanged();
                }
            }
        }

        public string CurrentFrequencyFormatted => $"{CurrentFrequency / 1000000:F4} MHz";

        #endregion

        #region Commands

        public ICommand StartScanCommand { get; }
        public ICommand StopScanCommand { get; }
        public ICommand PauseScanCommand { get; }
        public ICommand SaveConfigurationCommand { get; }

        private bool CanExecuteStartScan(object parameter) => !IsScanning;
        
        private async void ExecuteStartScan(object parameter)
        {
            try
            {
                IsScanning = true;
                IsPaused = false;
                StatusMessage = "Scanning...";
                
                // Clear previous signals if requested
                if (parameter is bool clearSignals && clearSignals)
                {
                    Signals.Clear();
                }
                
                // Configure scanner
                _scanner.Configure(Configuration);
                
                // Start scanning
                await Task.Run(() => _scanner.Start());
            }
            catch (Exception ex)
            {
                StatusMessage = $"Error starting scan: {ex.Message}";
                IsScanning = false;
            }
        }

        private bool CanExecuteStopScan(object parameter) => IsScanning;
        
        private void ExecuteStopScan(object parameter)
        {
            try
            {
                _scanner.Stop();
                IsScanning = false;
                IsPaused = false;
                StatusMessage = "Scan stopped";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Error stopping scan: {ex.Message}";
            }
        }

        private bool CanExecutePauseScan(object parameter) => IsScanning;
        
        private void ExecutePauseScan(object parameter)
        {
            try
            {
                if (IsPaused)
                {
                    // Resume
                    _scanner.Resume();
                    IsPaused = false;
                    StatusMessage = "Scanning...";
                }
                else
                {
                    // Pause
                    _scanner.Pause();
                    IsPaused = true;
                    StatusMessage = "Scan paused";
                }
            }
            catch (Exception ex)
            {
                StatusMessage = $"Error toggling pause: {ex.Message}";
            }
        }

        private bool CanExecuteSaveConfiguration(object parameter) => true;
        
        private void ExecuteSaveConfiguration(object parameter)
        {
            try
            {
                // Validate configuration
                if (Configuration.StartFrequency >= Configuration.EndFrequency)
                {
                    StatusMessage = "Start frequency must be less than end frequency";
                    return;
                }
                
                if (Configuration.StepSize <= 0)
                {
                    StatusMessage = "Step size must be greater than zero";
                    return;
                }
                
                // Apply configuration
                if (IsScanning)
                {
                    // If scanning, stop, reconfigure, and restart
                    _scanner.Stop();
                    _scanner.Configure(Configuration);
                    _scanner.Start();
                    StatusMessage = "Configuration updated and scan restarted";
                }
                else
                {
                    // Just update configuration
                    _scanner.Configure(Configuration);
                    StatusMessage = "Configuration saved";
                }
            }
            catch (Exception ex)
            {
                StatusMessage = $"Error saving configuration: {ex.Message}";
            }
        }

        #endregion

        #region Event Handlers

        private void OnSignalDetected(object sender, SignalDetectedEventArgs e)
        {
            // Marshal to UI thread since this might be called from a background thread
            App.Current.Dispatcher.Invoke(() =>
            {
                Signals.Add(e.Signal);
                StatusMessage = $"Signal detected: {e.Signal.Frequency / 1000000:F4} MHz - {e.Signal.Description}";
            });
        }

        private void OnFrequencyChanged(object sender, FrequencyChangedEventArgs e)
        {
            // Marshal to UI thread
            App.Current.Dispatcher.Invoke(() =>
            {
                CurrentFrequency = e.Frequency;
            });
        }

        #endregion

        #region INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }

    // Relay command implementation for binding UI actions
    public class RelayCommand : ICommand
    {
        private readonly Action<object> _execute;
        private readonly Predicate<object> _canExecute;

        public RelayCommand(Action<object> execute, Predicate<object> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public bool CanExecute(object parameter) => _canExecute == null || _canExecute(parameter);

        public void Execute(object parameter) => _execute(parameter);

        public event EventHandler CanExecuteChanged;

        public void RaiseCanExecuteChanged()
        {
            CanExecuteChanged?.Invoke(this, EventArgs.Empty);
        }
    }
}

