using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using P25Scanner.Configuration;
using P25Scanner.Services;

namespace P25Scanner.ViewModels
{
    public class ConfigurationViewModel : ViewModelBase
    {
        private readonly ILogger<ConfigurationViewModel> _logger;
        private readonly AppConfig _config;
        private readonly AudioPlaybackManager _audioManager;
        private readonly ChannelListManager _channelManager;
        private string _selectedAudioDevice;
        private string _selectedLogLevel;
        private bool _enableRecording;
        private string _recordingsPath;
        private int _squelchThreshold;
        private string _selectedChannelList;
        private bool _autoStartScanning;

        public ObservableCollection<string> AudioDevices { get; }
        public ObservableCollection<string> LogLevels { get; }
        public ObservableCollection<string> ChannelLists { get; }

        public ICommand SaveCommand { get; }
        public ICommand ResetCommand { get; }
        public ICommand BrowseRecordingPathCommand { get; }
        public ICommand ImportChannelListCommand { get; }
        public ICommand ExportChannelListCommand { get; }

        public string SelectedAudioDevice
        {
            get => _selectedAudioDevice;
            set => SetProperty(ref _selectedAudioDevice, value);
        }

        public string SelectedLogLevel
        {
            get => _selectedLogLevel;
            set => SetProperty(ref _selectedLogLevel, value);
        }

        public bool EnableRecording
        {
            get => _enableRecording;
            set => SetProperty(ref _enableRecording, value);
        }

        public string RecordingsPath
        {
            get => _recordingsPath;
            set => SetProperty(ref _recordingsPath, value);
        }

        public int SquelchThreshold
        {
            get => _squelchThreshold;
            set => SetProperty(ref _squelchThreshold, value);
        }

        public string SelectedChannelList
        {
            get => _selectedChannelList;
            set => SetProperty(ref _selectedChannelList, value);
        }

        public bool AutoStartScanning
        {
            get => _autoStartScanning;
            set => SetProperty(ref _autoStartScanning, value);
        }

        public ConfigurationViewModel(
            ILogger<ConfigurationViewModel> logger,
            AppConfig config,
            AudioPlaybackManager audioManager,
            ChannelListManager channelManager)
        {
            _logger = logger;
            _config = config;
            _audioManager = audioManager;
            _channelManager = channelManager;

            AudioDevices = new ObservableCollection<string>();
            LogLevels = new ObservableCollection<string>
            {
                "Trace", "Debug", "Information", "Warning", "Error", "Critical"
            };
            ChannelLists = new ObservableCollection<string>();

            SaveCommand = new RelayCommand(async () => await SaveConfigurationAsync());
            ResetCommand = new RelayCommand(LoadConfiguration);
            BrowseRecordingPathCommand = new RelayCommand(BrowseRecordingPath);
            ImportChannelListCommand = new RelayCommand(async () => await ImportChannelListAsync());
            ExportChannelListCommand = new RelayCommand(async () => await ExportChannelListAsync());

            LoadConfiguration();
        }

        private void LoadConfiguration()
        {
            // Load audio devices
            AudioDevices.Clear();
            foreach (var device in _audioManager.GetAvailableDevices())
            {
                AudioDevices.Add(device.ProductName);
            }

            // Load channel lists
            ChannelLists.Clear();
            foreach (var list in _channelManager.GetChannelLists())
            {
                ChannelLists.Add(list.Key);
            }

            // Load current settings
            SelectedAudioDevice = _config.Audio.DeviceName;
            SelectedLogLevel = _config.LogLevel;
            EnableRecording = _config.Recording.Enabled;
            RecordingsPath = _config.Recording.Path;
            SquelchThreshold = _config.Sdr.SquelchThreshold;
            AutoStartScanning = _config.Scanner.AutoStart;
            SelectedChannelList = _config.Scanner.DefaultChannelList;
        }

        private async Task SaveConfigurationAsync()
        {
            try
            {
                // Update config
                _config.Audio.DeviceName = SelectedAudioDevice;
                _config.LogLevel = SelectedLogLevel;
                _config.Recording.Enabled = EnableRecording;
                _config.Recording.Path = RecordingsPath;
                _config.Sdr.SquelchThreshold = SquelchThreshold;
                _config.Scanner.AutoStart = AutoStartScanning;
                _config.Scanner.DefaultChannelList = SelectedChannelList;

                // Save to file
                await _config.SaveAsync();
                _logger.LogInformation("Configuration saved successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error saving configuration");
                throw;
            }
        }

        private void BrowseRecordingPath()
        {
            var dialog = new System.Windows.Forms.FolderBrowserDialog
            {
                Description = "Select Recordings Folder",
                SelectedPath = RecordingsPath
            };

            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                RecordingsPath = dialog.SelectedPath;
            }
        }

        private async Task ImportChannelListAsync()
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*",
                Title = "Import Channel List"
            };

            if (dialog.ShowDialog() == true)
            {
                try
                {
                    string listName = System.IO.Path.GetFileNameWithoutExtension(dialog.FileName);
                    await _channelManager.ImportFromCsvAsync(dialog.FileName, listName);
                    ChannelLists.Add(listName);
                    SelectedChannelList = listName;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error importing channel list");
                    throw;
                }
            }
        }

        private async Task ExportChannelListAsync()
        {
            if (string.IsNullOrEmpty(SelectedChannelList))
                return;

            var dialog = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*",
                Title = "Export Channel List",
                FileName = $"{SelectedChannelList}.csv"
            };

            if (dialog.ShowDialog() == true)
            {
                try
                {
                    await _channelManager.ExportToCsvAsync(SelectedChannelList, dialog.FileName);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error exporting channel list");
                    throw;
                }
            }
        }
    }
}

