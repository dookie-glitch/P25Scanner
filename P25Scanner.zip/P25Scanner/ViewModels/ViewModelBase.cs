using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace P25Scanner.ViewModels
{
    public abstract class ViewModelBase : INotifyPropertyChanged
    {
        private bool _hasChanges;
        private readonly Dictionary<string, object> _propertyValues = new Dictionary<string, object>();

        public event PropertyChangedEventHandler PropertyChanged;

        public bool HasPendingChanges
        {
            get => _hasChanges;
            protected set
            {
                if (_hasChanges != value)
                {
                    _hasChanges = value;
                    OnPropertyChanged();
                }
            }
        }

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        protected bool SetProperty<T>(ref T field, T value, [CallerMemberName] string propertyName = null)
        {
            if (EqualityComparer<T>.Default.Equals(field, value))
                return false;

            field = value;
            HasPendingChanges = true;
            OnPropertyChanged(propertyName);
            return true;
        }

        protected T GetValue<T>([CallerMemberName] string propertyName = null)
        {
            if (_propertyValues.TryGetValue(propertyName, out object value))
            {
                return (T)value;
            }
            return default;
        }

        protected bool SetValue<T>(T value, [CallerMemberName] string propertyName = null)
        {
            if (_propertyValues.TryGetValue(propertyName, out object currentValue))
            {
                if (EqualityComparer<T>.Default.Equals((T)currentValue, value))
                    return false;
            }

            _propertyValues[propertyName] = value;
            HasPendingChanges = true;
            OnPropertyChanged(propertyName);
            return true;
        }

        protected void ResetChanges()
        {
            HasPendingChanges = false;
        }
    }
}

