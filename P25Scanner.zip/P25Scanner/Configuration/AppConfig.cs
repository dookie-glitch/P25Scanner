using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;

namespace P25Scanner.Configuration
{
    public class AppConfig
    {
        private readonly IConfiguration _configuration;
        private readonly string _configPath;

        public AppConfig(IConfiguration configuration)
        {
            _configuration = configuration;
            _configPath = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "usersettings.json");
        }

        public class SdrSettings
        {
            public uint SampleRate { get; set; } = 2048000;
            public int DefaultGain { get; set; } = 30;
            public long DefaultFrequency { get; set; } = 855000000;
            public int BandwidthHz { get; set; } = 12500;
            public float SquelchThreshold { get; set; } = -30;
            public bool EnableAGC { get; set; } = true;
            public int BufferSize { get; set; } = 16384;
        }

        public class AudioSettings
        {
            public string OutputDevice { get; set; } = "default";
            public int SampleRate { get; set; } = 8000;
            public int Channels { get; set; } = 1;
            public int BufferSize { get; set; } = 1024;
            public bool EnableAGC { get; set; } = true;
        }

        public class TalkgroupSettings
        {
            public bool DefaultEnabled { get; set; } = false;
            public bool SaveFilters { get; set; } = true;
            public string FiltersPath { get; set; } = "talkgroups.json";
        }

        public class UISettings
        {
            public string Theme { get; set; } = "Dark";
            public int RefreshRate { get; set; } = 100;
            public bool EnableSpectrum { get; set; } = true;
            public int SpectrumUpdateRate { get; set; } = 30;
            public bool SaveWindowLayout { get; set; } = true;
        }

        public SdrSettings Sdr { get; private set; }
        public AudioSettings Audio { get; private set; }
        public TalkgroupSettings Talkgroups { get; private set; }
        public UISettings UI { get; private set; }

        public void LoadSettings()
        {
            // Load from appsettings.json
            Sdr = _configuration.GetSection("SDR").Get<SdrSettings>() ?? new SdrSettings();
            Audio = _configuration.GetSection("Audio").Get<AudioSettings>() ?? new AudioSettings();
            Talkgroups = _configuration.GetSection("TalkgroupFilters").Get<TalkgroupSettings>() ?? new TalkgroupSettings();
            UI = _configuration.GetSection("UI").Get<UISettings>() ?? new UISettings();

            // Override with user settings if they exist
            if (File.Exists(_configPath))
            {
                try
                {
                    var json = File.ReadAllText(_configPath);
                    var userSettings = JsonSerializer.Deserialize<AppConfig>(json);
                    
                    // Merge user settings
                    if (userSettings != null)
                    {
                        Sdr = userSettings.Sdr ?? Sdr;
                        Audio = userSettings.Audio ?? Audio;
                        Talkgroups = userSettings.Talkgroups ?? Talkgroups;
                        UI = userSettings.UI ?? UI;
                    }
                }
                catch (Exception)
                {
                    // Use defaults if user settings are corrupt
                }
            }
        }

        public async Task SaveSettingsAsync()
        {
            try
            {
                var options = new JsonSerializerOptions
                {
                    WriteIndented = true
                };

                var json = JsonSerializer.Serialize(this, options);
                await File.WriteAllTextAsync(_configPath, json);
            }
            catch (Exception)
            {
                // Log error but don't throw
            }
        }
    }
}

