using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace P25Scanner.Audio
{
    public class AudioVisualizer
    {
        private WriteableBitmap _waterfallBitmap;
        private int _width;
        private int _height;
        private byte[] _pixels;
        private readonly ColorGradient _gradient;

        public AudioVisualizer(int width, int height)
        {
            _width = width;
            _height = height;
            _waterfallBitmap = new WriteableBitmap(
                width, height, 96, 96, PixelFormats.Bgr32, null);
            _pixels = new byte[width * height * 4];
            _gradient = new ColorGradient();
        }

        public void UpdateSpectrum(float[] spectrum)
        {
            // Scroll existing waterfall down
            _waterfallBitmap.CopyPixels(
                new Int32Rect(0, 0, _width, _height - 1),
                _pixels, _width * 4, 0);

            // Add new line at top
            for (int x = 0; x < _width && x < spectrum.Length; x++)
            {
                var color = _gradient.GetColor(spectrum[x]);
                int pixel = x * 4;
                _pixels[pixel] = color.B;     // Blue
                _pixels[pixel + 1] = color.G; // Green
                _pixels[pixel + 2] = color.R; // Red
                _pixels[pixel + 3] = 255;     // Alpha
            }

            // Update bitmap
            _waterfallBitmap.WritePixels(
                new Int32Rect(0, 0, _width, _height),
                _pixels, _width * 4, 0);
        }

        public ImageSource WaterfallImage => _waterfallBitmap;

        public PointCollection GetSpectrumPoints(float[] spectrum)
        {
            var points = new PointCollection();
            double xScale = _width / (double)spectrum.Length;
            double yScale = _height / 100.0; // Assuming dB range of 100

            for (int i = 0; i < spectrum.Length; i++)
            {
                points.Add(new Point(
                    i * xScale,
                    _height - (spectrum[i] + 100) * yScale)); // Shift by 100 to make negative dB positive
            }

            return points;
        }

        private class ColorGradient
        {
            private static readonly Color[] Colors = new[]
            {
                Color.FromRgb(0, 0, 0),      // Black
                Color.FromRgb(0, 0, 255),    // Blue
                Color.FromRgb(0, 255, 255),  // Cyan
                Color.FromRgb(0, 255, 0),    // Green
                Color.FromRgb(255, 255, 0),  // Yellow
                Color.FromRgb(255, 0, 0)     // Red
            };

            public Color GetColor(float value)
            {
                // Normalize value to 0-1 range
                float normalized = Math.Max(0, Math.Min(1, (value + 100) / 100));
                
                // Find color indices
                float position = normalized * (Colors.Length - 1);
                int index = (int)position;
                float remainder = position - index;

                if (index >= Colors.Length - 1)
                    return Colors[Colors.Length - 1];

                // Interpolate between colors
                var c1 = Colors[index];
                var c2 = Colors[index + 1];

                return Color.FromRgb(
                    (byte)(c1.R + (c2.R - c1.R) * remainder),
                    (byte)(c1.G + (c2.G - c1.G) * remainder),
                    (byte)(c1.B + (c2.B - c1.B) * remainder));
            }
        }
    }
}

