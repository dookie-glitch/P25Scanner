using Microsoft.Extensions.Logging;
using NAudio.Wave;
using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;

namespace P25Scanner.Audio
{
    public class AudioManager : IDisposable
    {
        private readonly ILogger<AudioManager> _logger;
        private readonly ConcurrentQueue<float[]> _audioQueue;
        private readonly WaveFormat _waveFormat;
        private IWavePlayer _waveOut;
        private BufferedWaveProvider _bufferedWaveProvider;
        private CancellationTokenSource _playbackCts;
        private Task _playbackTask;
        private readonly float[] _silenceBuffer;
        private bool _isDisposed;

        public AudioManager(ILogger<AudioManager> logger)
        {
            _logger = logger;
            _audioQueue = new ConcurrentQueue<float[]>();
            _waveFormat = new WaveFormat(8000, 16, 1);
            _silenceBuffer = new float[_waveFormat.SampleRate / 10]; // 100ms of silence
        }

        public async Task StartAsync()
        {
            if (_waveOut != null)
                return;

            try
            {
                _waveOut = new WaveOutEvent();
                _bufferedWaveProvider = new BufferedWaveProvider(_waveFormat)
                {
                    DiscardOnBufferOverflow = true
                };

                _waveOut.Init(_bufferedWaveProvider);
                _waveOut.Play();

                _playbackCts = new CancellationTokenSource();
                _playbackTask = PlaybackLoopAsync(_playbackCts.Token);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to start audio playback");
                throw;
            }
        }

        public async Task StopAsync()
        {
            try
            {
                if (_playbackCts != null)
                {
                    _playbackCts.Cancel();
                    if (_playbackTask != null)
                    {
                        await _playbackTask;
                    }
                }

                _waveOut?.Stop();
                _waveOut?.Dispose();
                _waveOut = null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error stopping audio playback");
            }
        }

        public void QueueAudio(float[] samples)
        {
            if (samples == null || samples.Length == 0)
                return;

            _audioQueue.Enqueue(samples);
        }

        private async Task PlaybackLoopAsync(CancellationToken cancellationToken)
        {
            var buffer = new byte[4096];

            try
            {
                while (!cancellationToken.IsCancellationRequested)
                {
                    if (_audioQueue.TryDequeue(out float[] samples))
                    {
                        // Convert float samples to bytes
                        int byteCount = samples.Length * 2; // 16-bit samples
                        if (buffer.Length < byteCount)
                        {
                            buffer = new byte[byteCount];
                        }

                        int offset = 0;
                        for (int i = 0; i < samples.Length; i++)
                        {
                            short sample = (short)(samples[i] * short.MaxValue);
                            buffer[offset++] = (byte)(sample & 0xFF);
                            buffer[offset++] = (byte)(sample >> 8);
                        }

                        _bufferedWaveProvider.AddSamples(buffer, 0, byteCount);
                    }
                    else
                    {
                        // Add silence if no audio available
                        QueueSilence();
                        await Task.Delay(10, cancellationToken);
                    }
                }
            }
            catch (OperationCanceledException)
            {
                // Normal cancellation
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in audio playback loop");
            }
        }

        private void QueueSilence()
        {
            // Convert silence buffer to bytes
            var buffer = new byte[_silenceBuffer.Length * 2];
            _bufferedWaveProvider.AddSamples(buffer, 0, buffer.Length);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_isDisposed)
            {
                if (disposing)
                {
                    StopAsync().Wait();
                    _playbackCts?.Dispose();
                    _waveOut?.Dispose();
                }

                _isDisposed = true;
            }
        }
    }
}

