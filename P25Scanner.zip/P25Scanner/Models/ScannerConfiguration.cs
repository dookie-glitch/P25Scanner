using System;

namespace P25Scanner.Models
{
    /// <summary>
    /// Configuration settings for the P25 scanner
    /// </summary>
    public class ScannerConfiguration
    {
        /// <summary>
        /// Start frequency in Hz
        /// </summary>
        public double StartFrequency { get; set; }
        
        /// <summary>
        /// End frequency in Hz
        /// </summary>
        public double EndFrequency { get; set; }
        
        /// <summary>
        /// Step size in Hz
        /// </summary>
        public double StepSize { get; set; }
        
        /// <summary>
        /// Dwell time in milliseconds
        /// </summary>
        public int DwellTime { get; set; }
        
        /// <summary>
        /// Gain in dB
        /// </summary>
        public double Gain { get; set; }
        
        /// <summary>
        /// Enable automatic gain control
        /// </summary>
        public bool EnableAgc { get; set; }
        
        /// <summary>
        /// Use squelch to filter weak signals
        /// </summary>
        public bool UseSquelch { get; set; }
        
        /// <summary>
        /// Squelch threshold in dB
        /// </summary>
        public double SquelchThreshold { get; set; }
    }
}

