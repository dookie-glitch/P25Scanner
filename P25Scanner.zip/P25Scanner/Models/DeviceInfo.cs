
using System;
using ReactiveUI;

namespace P25Scanner.Models
{
    public class DeviceInfo : ReactiveObject
    {
        private int _deviceIndex;
        private string _name;
        private string _serialNumber;
        private string _manufacturer;
        private string _productId;
        private string _vendorId;
        private bool _isAvailable;
        private bool _isConnected;
        private DeviceCapabilities _capabilities;
        private DeviceSettings _settings;

        public int DeviceIndex
        {
            get => _deviceIndex;
            set => this.RaiseAndSetIfChanged(ref _deviceIndex, value);
        }

        public string Name
        {
            get => _name;
            set => this.RaiseAndSetIfChanged(ref _name, value);
        }

        public string SerialNumber
        {
            get => _serialNumber;
            set => this.RaiseAndSetIfChanged(ref _serialNumber, value);
        }

        public string Manufacturer
        {
            get => _manufacturer;
            set => this.RaiseAndSetIfChanged(ref _manufacturer, value);
        }

        public string ProductId
        {
            get => _productId;
            set => this.RaiseAndSetIfChanged(ref _productId, value);
        }

        public string VendorId
        {
            get => _vendorId;
            set => this.RaiseAndSetIfChanged(ref _vendorId, value);
        }

        public bool IsAvailable
        {
            get => _isAvailable;
            set => this.RaiseAndSetIfChanged(ref _isAvailable, value);
        }

        public bool IsConnected
        {
            get => _isConnected;
            set => this.RaiseAndSetIfChanged(ref _isConnected, value);
        }

        public DeviceCapabilities Capabilities
        {
            get => _capabilities;
            set => this.RaiseAndSetIfChanged(ref _capabilities, value);
        }

        public DeviceSettings Settings
        {
            get => _settings;
            set => this.RaiseAndSetIfChanged(ref _settings, value);
        }

        public DeviceInfo()
        {
            Capabilities = new DeviceCapabilities();
            Settings = new DeviceSettings();
        }

        public override string ToString() => Name ?? $"Device {DeviceIndex}";
    }

    public class DeviceCapabilities : ReactiveObject
    {
        private int _minFrequency = 24000000;  // 24 MHz
        private int _maxFrequency = 1766000000; // 1.766 GHz
        private int[] _supportedSampleRates = { 250000, 1024000, 1800000, 1920000, 2048000, 2400000 };
        private int[] _supportedGains = { 0, 9, 14, 27, 37, 49 };
        private bool _hasBiasTee;
        private bool _hasDirectSampling;

        public int MinFrequency
        {
            get => _minFrequency;
            set => this.RaiseAndSetIfChanged(ref _minFrequency, value);
        }

        public int MaxFrequency
        {
            get => _maxFrequency;
            set => this.RaiseAndSetIfChanged(ref _maxFrequency, value);
        }

        public int[] SupportedSampleRates
        {
            get => _supportedSampleRates;
            set => this.RaiseAndSetIfChanged(ref _supportedSampleRates, value);
        }

        public int[] SupportedGains
        {
            get => _supportedGains;
            set => this.RaiseAndSetIfChanged(ref _supportedGains, value);
        }

        public bool HasBiasTee
        {
            get => _hasBiasTee;
            set => this.RaiseAndSetIfChanged(ref _hasBiasTee, value);
        }

        public bool HasDirectSampling
        {
            get => _hasDirectSampling;
            set => this.RaiseAndSetIfChanged(ref _hasDirectSampling, value);
        }
    }

    public class DeviceSettings : ReactiveObject
    {
        private int _frequency = 856000000; // Default 856 MHz
        private int _sampleRate = 2048000;  // Default 2.048 MSPS
        private int _gain = 49;             // Default maximum gain
        private bool _agcMode = true;       // Default AGC on
        private bool _biasTee = false;      // Default bias-tee off
        private int _ppm = 0;               // Default 0 PPM correction
        private int _directSamplingMode = 0; // Default direct sampling off
        private int _bandwidth = 0;         // Default automatic bandwidth

        public int Frequency
        {
            get => _frequency;
            set => this.RaiseAndSetIfChanged(ref _frequency, value);
        }

        public int SampleRate
        {
            get => _sampleRate;
            set => this.RaiseAndSetIfChanged(ref _sampleRate, value);
        }

        public int Gain
        {
            get => _gain;
            set => this.RaiseAndSetIfChanged(ref _gain, value);
        }

        public bool AgcMode
        {
            get => _agcMode;
            set => this.RaiseAndSetIfChanged(ref _agcMode, value);
        }

        public bool BiasTee
        {
            get => _biasTee;
            set => this.RaiseAndSetIfChanged(ref _biasTee, value);
        }

        public int PpmCorrection
        {
            get => _ppm;
            set => this.RaiseAndSetIfChanged(ref _ppm, value);
        }

        public int DirectSamplingMode
        {
            get => _directSamplingMode;
            set => this.RaiseAndSetIfChanged(ref _directSamplingMode, value);
        }

        public int Bandwidth
        {
            get => _bandwidth;
            set => this.RaiseAndSetIfChanged(ref _bandwidth, value);
        }
    }
