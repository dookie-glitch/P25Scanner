using System;
using ReactiveUI;

namespace P25Scanner.Models
{
    public enum ChannelType
    {
        Conventional,
        TrunkControl,
        TrunkVoice
    }

    public enum SignalSystem
    {
        P25Phase1,
        P25Phase2,
        DMR,
        NXDN,
        Unknown
    }

    public class ChannelInfo : ReactiveObject
    {
        private int _channelId;
        private string _name;
        private string _description;
        private int _frequency;
        private ChannelType _channelType = ChannelType.Conventional;
        private SignalSystem _signalSystem = SignalSystem.P25Phase1;
        private bool _isActive;
        private bool _isMonitored = true;
        private DateTime _lastActivity = DateTime.MinValue;
        private double _signalStrength;
        private double _signalQuality;
        private bool _isEncrypted;
        private bool _isEmergency;

        // Talkgroup information
        private int _talkgroupId;
        private string _talkgroupName;
        private string _talkgroupDescription;
        private string _talkgroupTag;
        private int _talkgroupPriority;

        // System information
        private int _systemId;
        private string _systemName;
        private int _siteId;
        private string _siteName;
        private int _rfssId;

        // Caller information
        private int _sourceId;
        private string _sourceName;
        private int _destinationId;
        private string _destinationName;

        public int ChannelId
        {
            get => _channelId;
            set => this.RaiseAndSetIfChanged(ref _channelId, value);
        }

        public string Name
        {
            get => _name;
            set => this.RaiseAndSetIfChanged(ref _name, value);
        }

        public string Description
        {
            get => _description;
            set => this.RaiseAndSetIfChanged(ref _description, value);
        }

        public int Frequency
        {
            get => _frequency;
            set => this.RaiseAndSetIfChanged(ref _frequency, value);
        }

        public string FrequencyFormatted => $"{_frequency / 1000000.0:F6} MHz";

        public ChannelType ChannelType
        {
            get => _channelType;
            set => this.RaiseAndSetIfChanged(ref _channelType, value);
        }

        public SignalSystem SignalSystem
        {
            get => _signalSystem;
            set => this.RaiseAndSetIfChanged(ref _signalSystem, value);
        }

        public bool IsActive
        {
            get => _isActive;
            set => this.RaiseAndSetIfChanged(ref _isActive, value);
        }

        public bool IsMonitored
        {
            get => _isMonitored;
            set => this.RaiseAndSetIfChanged(ref _isMonitored, value);
        }

        public DateTime LastActivity
        {
            get => _lastActivity;
            set => this.RaiseAndSetIfChanged(ref _lastActivity, value);
        }

        public double SignalStrength
        {
            get => _signalStrength;
            set => this.RaiseAndSetIfChanged(ref _signalStrength, value);
        }

        public double SignalQuality
        {
            get => _signalQuality;
            set => this.RaiseAndSetIfChanged(ref _signalQuality, value);
        }

        public bool IsEncrypted
        {
            get => _isEncrypted;
            set => this.RaiseAndSetIfChanged(ref _isEncrypted, value);
        }

        public bool IsEmergency
        {
            get => _isEmergency;
            set => this.RaiseAndSetIfChanged(ref _isEmergency, value);
        }

        // Talkgroup properties
        public int TalkgroupId
        {
            get => _talkgroupId;
            set => this.RaiseAndSetIfChanged(ref _talkgroupId, value);
        }

        public string TalkgroupName
        {
            get => _talkgroupName;
            set => this.RaiseAndSetIfChanged(ref _talkgroupName, value);
        }

        public string TalkgroupDescription
        {
            get => _talkgroupDescription;
            set => this.RaiseAndSetIfChanged(ref _talkgroupDescription, value);
        }

        public string TalkgroupTag
        {
            get => _talkgroupTag;
            set => this.RaiseAndSetIfChanged(ref _talkgroupTag, value);
        }

        public int TalkgroupPriority
        {
            get => _talkgroupPriority;
            set => this.RaiseAndSetIfChanged(ref _talkgroupPriority, value);
        }

        // System properties
        public int SystemId
        {
            get => _systemId;
            set => this.RaiseAndSetIfChanged(ref _systemId, value);
        }

        public string SystemName
        {
            get => _systemName;
            set => this.RaiseAndSetIfChanged(ref _systemName, value);
        }

        public int SiteId
        {
            get => _siteId;
            set => this.RaiseAndSetIfChanged(ref _siteId, value);
        }

        public string SiteName
        {
            get => _siteName;
            set => this.RaiseAndSetIfChanged(ref _siteName, value);
        }

        public int RfssId
        {
            get => _rfssId;
            set => this.RaiseAndSetIfChanged(ref _rfssId, value);
        }

        // Caller properties
        public int SourceId
        {
            get => _sourceId;
            set => this.RaiseAndSetIfChanged(ref _sourceId, value);
        }

        public string SourceName
        {
            get => _sourceName;
            set => this.RaiseAndSetIfChanged(ref _sourceName, value);
        }

        public int DestinationId
        {
            get => _destinationId;
            set => this.RaiseAndSetIfChanged(ref _destinationId, value);
        }

        public string DestinationName
        {
            get => _destinationName;
            set => this.RaiseAndSetIfChanged(ref _destinationName, value);
        }

        // Utility methods
        public void UpdateActivity()
        {
            LastActivity = DateTime.Now;
            IsActive = true;
        }

        public void ClearActivity()
        {
            IsActive = false;
        }

        public override string ToString()
        {
            if (!string.IsNullOrEmpty(Name))
                return Name;
            
            if (_talkgroupId > 0 && !string.IsNullOrEmpty(_talkgroupName))
                return $"TG: {_talkgroupId} - {_talkgroupName}";
            
            if (_talkgroupId > 0)
                return $"TG: {_talkgroupId}";
            
            return $"Channel: {FrequencyFormatted}";
        }
    }
}

