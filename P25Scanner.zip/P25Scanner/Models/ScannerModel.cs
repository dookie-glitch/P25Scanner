using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using ReactiveUI;

namespace P25Scanner.Models
{
    public class ScannerModel : ReactiveObject, IDisposable
    {
        private bool _isScanning;
        private bool _isPaused;
        private DeviceInfo _selectedDevice;
        private double _frequency;
        private double _signalStrength;
        private double _volume = 100;
        private ObservableCollection<ChannelInfo> _activeChannels;
        private ObservableCollection<DeviceInfo> _availableDevices;
        private CancellationTokenSource _scanningCancellation;
        private string _statusMessage = "Ready";
        private bool _isInitialized;

        public ScannerModel()
        {
            ActiveChannels = new ObservableCollection<ChannelInfo>();
            AvailableDevices = new ObservableCollection<DeviceInfo>();
        }

        public bool IsScanning
        {
            get => _isScanning;
            set => this.RaiseAndSetIfChanged(ref _isScanning, value);
        }

        public bool IsPaused
        {
            get => _isPaused;
            set => this.RaiseAndSetIfChanged(ref _isPaused, value);
        }

        public DeviceInfo SelectedDevice
        {
            get => _selectedDevice;
            set => this.RaiseAndSetIfChanged(ref _selectedDevice, value);
        }

        public double Frequency
        {
            get => _frequency;
            set => this.RaiseAndSetIfChanged(ref _frequency, value);
        }

        public double SignalStrength
        {
            get => _signalStrength;
            set => this.RaiseAndSetIfChanged(ref _signalStrength, value);
        }

        public double Volume
        {
            get => _volume;
            set => this.RaiseAndSetIfChanged(ref _volume, value);
        }

        public ObservableCollection<ChannelInfo> ActiveChannels
        {
            get => _activeChannels;
            set => this.RaiseAndSetIfChanged(ref _activeChannels, value);
        }

        public ObservableCollection<DeviceInfo> AvailableDevices
        {
            get => _availableDevices;
            set => this.RaiseAndSetIfChanged(ref _availableDevices, value);
        }

        public string StatusMessage
        {
            get => _statusMessage;
            set => this.RaiseAndSetIfChanged(ref _statusMessage, value);
        }

        // Events for UI notifications
        public event EventHandler<ChannelEventArgs> ChannelDetected;
        public event EventHandler<ChannelEventArgs> ChannelLost;
        public event EventHandler<SignalEventArgs> SignalUpdated;
        public event EventHandler<ErrorEventArgs> ErrorOccurred;
        public event EventHandler DevicesUpdated;

        public async Task InitializeAsync()
        {
            if (_isInitialized)
                return;

            StatusMessage = "Initializing scanner...";
            
            try
            {
                // Enumerate available RTL-SDR devices
                await RefreshDevicesAsync();
                
                _isInitialized = true;
                StatusMessage = "Scanner initialized successfully";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Error initializing scanner: {ex.Message}";
                OnErrorOccurred(new ErrorEventArgs(ex));
            }
        }

        public async Task RefreshDevicesAsync()
        {
            try
            {
                StatusMessage = "Refreshing device list...";
                
                // Clear existing devices
                AvailableDevices.Clear();
                
                // Simulate device detection for now
                // In a real implementation, this would use the RTL-SDR library to detect devices
                await Task.Delay(500); // Simulate detection time
                
                // Add sample devices
                AvailableDevices.Add(new DeviceInfo
                {
                    DeviceIndex = 0,
                    Name = "RTL-SDR (0)",
                    SerialNumber = "00000001",
                    IsAvailable = true
                });
                
                AvailableDevices.Add(new DeviceInfo
                {
                    DeviceIndex = 1,
                    Name = "RTL-SDR (1)",
                    SerialNumber = "00000002",
                    IsAvailable = true
                });
                
                // Select the first device by default if available
                if (AvailableDevices.Count > 0 && SelectedDevice == null)
                {
                    SelectedDevice = AvailableDevices[0];
                }
                
                StatusMessage = $"Found {AvailableDevices.Count} device(s)";
                OnDevicesUpdated();
            }
            catch (Exception ex)
            {
                StatusMessage = $"Error refreshing devices: {ex.Message}";
                OnErrorOccurred(new ErrorEventArgs(ex));
            }
        }

        public async Task StartScanningAsync()
        {
            if (IsScanning)
                return;
            
            if (SelectedDevice == null)
            {
                StatusMessage = "No device selected";
                OnErrorOccurred(new ErrorEventArgs(new InvalidOperationException("No device selected")));
                return;
            }
            
            try
            {
                _scanningCancellation = new CancellationTokenSource();
                IsScanning = true;
                IsPaused = false;
                StatusMessage = "Starting scanner...";
                
                // Initialize the selected device
                await Task.Delay(500); // Simulate device initialization
                
                StatusMessage = $"Scanning with device: {SelectedDevice.Name}";
                
                // Start the scanning loop
                _ = Task.Run(() => ScanningLoopAsync(_scanningCancellation.Token));
            }
            catch (Exception ex)
            {
                StopScanning();
                StatusMessage = $"Error starting scanner: {ex.Message}";
                OnErrorOccurred(new ErrorEventArgs(ex));
            }
        }

        public void StopScanning()
        {
            if (!IsScanning)
                return;
            
            try
            {
                _scanningCancellation?.Cancel();
                _scanningCancellation?.Dispose();
                _scanningCancellation = null;
                IsScanning = false;
                IsPaused = false;
                StatusMessage = "Scanner stopped";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Error stopping scanner: {ex.Message}";
                OnErrorOccurred(new ErrorEventArgs(ex));
            }
        }

        public void PauseScanning()
        {
            if (!IsScanning || IsPaused)
                return;
            
            IsPaused = true;
            StatusMessage = "Scanner paused";
        }

        public void ResumeScanning()
        {
            if (!IsScanning || !IsPaused)
                return;
            
            IsPaused = false;
            StatusMessage = "Scanner resumed";
        }

        private async Task ScanningLoopAsync(CancellationToken cancellationToken)
        {
            var random = new Random();
            
            try
            {
                while (!cancellationToken.IsCancellationRequested)
                {
                    if (IsPaused)
                    {
                        await Task.Delay(100, cancellationToken);
                        continue;
                    }
                    
                    // Simulate signal detection
                    var signalStrength = random.NextDouble() * 100;
                    SignalStrength = signalStrength;
                    
                    // Simulate channel detection (occasionally)
                    if (random.NextDouble() > 0.95)
                    {
                        var channel = new ChannelInfo
                        {
                            SystemId = random.Next(1, 100),
                            GroupId = random.Next(100, 1000),
                            Frequency = 800 + random.NextDouble() * 100,
                            Name = $"Channel {random.Next(1, 999)}",
                            SignalStrength = signalStrength,
                            LastSeen = DateTime.Now
                        };
                        
                        await Task.Run(() => {
                            // Add to active channels on the UI thread
                            System.Windows.Application.Current.Dispatcher.Invoke(() => {
                                ActiveChannels.Add(channel);
                                OnChannelDetected(new ChannelEventArgs(channel));
                            });
                        });
                    }
                    
                    // Update existing channels
                    if (ActiveChannels.Count > 0)
                    {
                        foreach (var channel in ActiveChannels.ToList())
                        {
                            // Update signal strength
                            channel.SignalStrength = random.NextDouble() * 100;
                            
                            // Occasionally remove a channel
                            if (random.NextDouble() > 0.98)
                            {
                                await Task.Run(() => {
                                    System.Windows.Application.Current.Dispatcher.Invoke(() => {
                                        ActiveChannels.Remove(channel);
                                        OnChannelLost(new ChannelEventArgs(channel));
                                    });
                                });
                            }
                        }
                    }
                    
                    OnSignalUpdated(new SignalEventArgs(SignalStrength, Frequency));
                    
                    await Task.Delay(100, cancellationToken);
                }
            }
            catch (OperationCanceledException)
            {
                // Expected when cancellation is requested
            }
            catch (Exception ex)
            {
                if (!cancellationToken.IsCancellationRequested)
                {
                    System.Windows.Application.Current.Dispatcher.Invoke(() => {
                        StatusMessage = $"Scanning error: {ex.Message}";
                        OnErrorOccurred(new ErrorEventArgs(ex));
                    });
                }
            }
            finally
            {
                System.Windows.Application.Current.Dispatcher.Invoke(() => {
                    IsScanning = false;
                });
            }
        }

        // Event invokers
        protected virtual void OnChannelDetected(ChannelEventArgs e)
        {
            ChannelDetected?.Invoke(this, e);
        }

        protected virtual void OnChannelLost(ChannelEventArgs e)
        {
            ChannelLost?.Invoke(this, e);
        }

        protected virtual void OnSignalUpdated(SignalEventArgs e)
        {
            SignalUpdated?.Invoke(this, e);
        }

        protected virtual void OnErrorOccurred(ErrorEventArgs e)
        {
            ErrorOccurred?.Invoke(this, e);
        }

        protected virtual void OnDevicesUpdated()
        {
            DevicesUpdated?.Invoke(this, EventArgs.Empty);
        }

        public void Dispose()
        {
            StopScanning();
            _scanningCancellation?.Dispose();
        }
    }

    // Event argument classes
    public class ChannelEventArgs : EventArgs
    {
        public ChannelInfo Channel { get; }

        public ChannelEventArgs(ChannelInfo channel)
        {
            Channel = channel;
        }
    }

    public class SignalEventArgs : EventArgs
    {
        public double Strength { get; }
        public double Frequency { get; }

        public SignalEventArgs(double strength, double frequency)
        {
            Strength = strength;
            Frequency = frequency;
        }
    }

    public class ErrorEventArgs : EventArgs
    {
        public Exception Error { get; }

        public ErrorEventArgs(Exception error)
        {
            Error = error;
        }
    }
}

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using P25Scanner.Services;

namespace P25Scanner.Models
{
    public class ScannerModel
    {
        private readonly P25Decoder _p25Decoder;
        private CancellationTokenSource _scanCancellationTokenSource;
        private bool _isScanning;
        private const int DefaultSampleRate = 2048000;

        public ObservableCollection<ChannelInfo> Channels { get; private set; }
        public ObservableCollection<ChannelInfo> ActiveChannels { get; private set; }

        // Events
        public event EventHandler<ChannelInfo> ChannelUpdated;
        public event EventHandler<string> StatusUpdated;
        public event EventHandler<Exception> ErrorOccurred;
        public event EventHandler ScanStarted;
        public event EventHandler ScanStopped;

        // Device properties
        public int DeviceIndex { get; set; }
        public int SampleRate { get; set; } = DefaultSampleRate;
        public int Gain { get; set; } = 20; // Default gain
        public double CenterFrequency { get; set; }
        public List<double> FrequenciesToScan { get; set; } = new List<double>();

        public bool IsScanning
        {
            get => _isScanning;
            private set
            {
                _isScanning = value;
                if (_isScanning)
                    ScanStarted?.Invoke(this, EventArgs.Empty);
                else
                    ScanStopped?.Invoke(this, EventArgs.Empty);
            }
        }

        public ScannerModel(P25Decoder p25Decoder)
        {
            _p25Decoder = p25Decoder ?? throw new ArgumentNullException(nameof(p25Decoder));
            Channels = new ObservableCollection<ChannelInfo>();
            ActiveChannels = new ObservableCollection<ChannelInfo>();

            // Subscribe to P25Decoder events
            _p25Decoder.FrameDecoded += OnP25FrameDecoded;
            _p25Decoder.SignalDetected += OnP25SignalDetected;
        }

        public async Task StartScanningAsync()
        {
            if (IsScanning)
                return;

            try
            {
                _scanCancellationTokenSource = new CancellationTokenSource();
                IsScanning = true;
                UpdateStatus("Initializing RTL-SDR device...");

                await InitializeDeviceAsync();
                await ScanFrequenciesAsync(_scanCancellationTokenSource.Token);
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke(this, ex);
                UpdateStatus($"Error starting scan: {ex.Message}");
                await StopScanningAsync();
            }
        }

        public async Task StopScanningAsync()
        {
            if (!IsScanning)
                return;

            try
            {
                _scanCancellationTokenSource?.Cancel();
                await Task.Delay(100); // Give time for tasks to cancel

                // Cleanup RTL-SDR resources
                CleanupDevice();
                
                IsScanning = false;
                UpdateStatus("Scanner stopped");
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke(this, ex);
                UpdateStatus($"Error stopping scan: {ex.Message}");
            }
        }

        public void AddChannel(ChannelInfo channel)
        {
            if (channel == null)
                throw new ArgumentNullException(nameof(channel));

            Channels.Add(channel);
        }

        public void RemoveChannel(ChannelInfo channel)
        {
            if (channel == null)
                throw new ArgumentNullException(nameof(channel));

            Channels.Remove(channel);
            if (ActiveChannels.Contains(channel))
                ActiveChannels.Remove(channel);
        }

        public void ClearChannels()
        {
            Channels.Clear();
            ActiveChannels.Clear();
        }

        public void UpdateFrequenciesToScan(List<double> frequencies)
        {
            FrequenciesToScan = frequencies ?? throw new ArgumentNullException(nameof(frequencies));
        }

        private async Task InitializeDeviceAsync()
        {
            // This would normally initialize the RTL-SDR device
            // For now, we'll simulate this with a delay
            await Task.Delay(500);
            UpdateStatus("RTL-SDR device initialized");
        }

        private void CleanupDevice()
        {
            // This would normally clean up RTL-SDR resources
            UpdateStatus("RTL-SDR device released");
        }

        private async Task ScanFrequenciesAsync(CancellationToken cancellationToken)
        {
            UpdateStatus("Scanning started");

            try
            {
                while (!cancellationToken.IsCancellationRequested)
                {
                    foreach (var frequency in FrequenciesToScan)
                    {
                        if (cancellationToken.IsCancellationRequested)
                            break;

                        await TuneToFrequencyAsync(frequency);
                        await ProcessSignalAsync(frequency, cancellationToken);
                    }

                    // Slight delay before next scan cycle
                    await Task.Delay(100, cancellationToken);
                }
            }
            catch (OperationCanceledException)
            {
                // Normal cancellation
                UpdateStatus("Scanning cancelled");
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke(this, ex);
                UpdateStatus($"Error during scan: {ex.Message}");
            }
        }

        private async Task TuneToFrequencyAsync(double frequency)
        {
            CenterFrequency = frequency;
            UpdateStatus($"Tuned to {frequency / 1000000.0:F4} MHz");
            
            // This would normally tune the RTL-SDR device
            // For now, we'll simulate this with a delay
            await Task.Delay(50);
        }

        private async Task ProcessSignalAsync(double frequency, CancellationToken cancellationToken)
        {
            // This would normally process IQ data from the RTL-SDR device
            // and pass it to the P25Decoder
            
            // For now, we'll simulate signal processing with a delay
            await Task.Delay(200, cancellationToken);
            
            // Check if a channel exists for this frequency
            var channel = Channels.FirstOrDefault(c => Math.Abs(c.Frequency - frequency) < 100);
            
            if (channel != null)
            {
                // Simulate updating channel signal information
                UpdateChannelSignal(channel, new Random().NextDouble() * 100);
            }
        }

        private void UpdateChannelSignal(ChannelInfo channel, double signalStrength)
        {
            channel.SignalStrength = signalStrength;
            channel.SignalQuality = signalStrength > 50 ? 0.9 : 0.5; // Simplified calculation
            channel.LastActivity = DateTime.Now;
            
            if (signalStrength > 30 && !channel.Active)
            {
                channel.Active = true;
                if (!ActiveChannels.Contains(channel))
                {
                    ActiveChannels.Add(channel);
                }
            }
            else if (signalStrength <= 30 && channel.Active)
            {
                channel.Active = false;
                if (ActiveChannels.Contains(channel))
                {
                    ActiveChannels.Remove(channel);
                }
            }
            
            ChannelUpdated?.Invoke(this, channel);
        }

        private void OnP25FrameDecoded(object sender, P25FrameEventArgs e)
        {
            // Update channel information based on decoded frame
            // This is a simplified example - actual implementation would extract information
            // from the P25 frame and update the relevant channel
            
            var channel = Channels.FirstOrDefault(c => c.TGID == e.TGID);
            if (channel != null)
            {
                UpdateChannelSignal(channel, e.SignalStrength);
            }
            else
            {
                // New channel discovered
                var newChannel = new ChannelInfo
                {
                    TGID = e.TGID,
                    System = e.SystemId,
                    Name = $"TG-{e.TGID}",
                    Frequency = CenterFrequency,
                    SignalStrength = e.SignalStrength,
                    SignalQuality = e.SignalQuality,
                    LastActivity = DateTime.Now,
                    Active = true
                };
                
                AddChannel(newChannel);
                ActiveChannels.Add(newChannel);
                ChannelUpdated?.Invoke(this, newChannel);
            }
        }

        private void OnP25SignalDetected(object sender, P25SignalEventArgs e)
        {
            // Update status based on detected signal
            UpdateStatus($"P25 signal detected at {e.Frequency / 1000000.0:F4} MHz");
        }

        private void UpdateStatus(string status)
        {
            StatusUpdated?.Invoke(this, status);
        }
    }

    // These would typically be defined in the P25Decoder service,
    // but they're included here for completeness
    public class P25FrameEventArgs : EventArgs
    {
        public int TGID { get; set; }
        public string SystemId { get; set; }
        public double SignalStrength { get; set; }
        public double SignalQuality { get; set; }
    }

    public class P25SignalEventArgs : EventArgs
    {
        public double Frequency { get; set; }
        public double SignalStrength { get; set; }
    }
}

