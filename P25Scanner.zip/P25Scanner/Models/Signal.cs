using System;

namespace P25Scanner.Models
{
    /// <summary>
    /// Represents a detected P25 signal
    /// </summary>
    public class Signal
    {
        /// <summary>
        /// Unique identifier for the signal
        /// </summary>
        public Guid Id { get; set; } = Guid.NewGuid();
        
        /// <summary>
        /// Frequency in Hz
        /// </summary>
        public double Frequency { get; set; }
        
        /// <summary>
        /// Signal strength in dB
        /// </summary>
        public double SignalStrength { get; set; }
        
        /// <summary>
        /// Time when the signal was detected
        /// </summary>
        public DateTime DetectedTime { get; set; } = DateTime.Now;
        
        /// <summary>
        /// System ID for P25
        /// </summary>
        public string SystemId { get; set; }
        
        /// <summary>
        /// Talk group ID
        /// </summary>
        public string TalkGroupId { get; set; }
        
        /// <summary>
        /// Radio ID
        /// </summary>
        public string RadioId { get; set; }
        
        /// <summary>
        /// Description or decoded message
        /// </summary>
        public string Description { get; set; }
        
        /// <summary>
        /// Signal type (voice, data, etc.)
        /// </summary>
        public SignalType Type { get; set; }
    }

    /// <summary>
    /// Types of signals that can be detected
    /// </summary>
    public enum SignalType
    {
        Unknown,
        Voice,
        Data,
        Control,
        Emergency
    }
}

