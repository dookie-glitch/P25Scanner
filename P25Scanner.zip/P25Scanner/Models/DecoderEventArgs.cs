using System;

namespace P25Scanner.Services.Models
{
    /// <summary>
    /// Status of the P25 decoder
    /// </summary>
    public enum DecoderStatus
    {
        /// <summary>
        /// Decoder is stopped
        /// </summary>
        Stopped,

        /// <summary>
        /// Decoder is initialized
        /// </summary>
        Initialized,

        /// <summary>
        /// Decoder is running
        /// </summary>
        Running,

        /// <summary>
        /// Decoder encountered an error
        /// </summary>
        Error
    }

    /// <summary>
    /// Event arguments for decoder status changes
    /// </summary>
    public class DecoderStatusEventArgs : EventArgs
    {
        /// <summary>
        /// Gets the decoder status
        /// </summary>
        public DecoderStatus Status { get; }

        /// <summary>
        /// Gets the status message (if any)
        /// </summary>
        public string Message { get; }

        /// <summary>
        /// Gets the timestamp of the status change
        /// </summary>
        public DateTime Timestamp { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="DecoderStatusEventArgs"/> class
        /// </summary>
        public DecoderStatusEventArgs(DecoderStatus status, string message = null)
        {
            Status = status;
            Message = message;
            Timestamp = DateTime.UtcNow;
        }
    }

    /// <summary>
    /// Event arguments for decoded audio data
    /// </summary>
    public class DecodedAudioEventArgs : EventArgs
    {
        /// <summary>
        /// Gets the decoded audio samples
        /// </summary>
        public float[] AudioSamples { get; }

        /// <summary>
        /// Gets the sample rate of the audio
        /// </summary>
        public int SampleRate { get; }

        /// <summary>
        /// Gets the talkgroup ID associated with the audio
        /// </summary>
        public int TalkgroupId { get; }

        /// <summary>
        /// Gets the Network Access Code (NAC)
        /// </summary>
        public int NAC { get; }

        /// <summary>
        /// Gets the timestamp when the audio was decoded
        /// </summary>
        public DateTime Timestamp { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="DecodedAudioEventArgs"/> class
        /// </summary>
        public DecodedAudioEventArgs(float[] audioSamples, int sampleRate, int talkgroupId, int nac, DateTime timestamp)
        {
            AudioSamples = audioSamples;
            SampleRate = sampleRate;
            TalkgroupId = talkgroupId;
            NAC = nac;
            Timestamp = timestamp;
        }
    }

    /// <summary>
    /// Event arguments for talkgroup detection
    /// </summary>
    public class TalkgroupEventArgs : EventArgs
    {
        /// <summary>
        /// Gets the talkgroup ID
        /// </summary>
        public int TalkgroupId { get; }

        /// <summary>
        /// Gets the Network Access Code (NAC)
        /// </summary>
        public int NAC { get; }

        /// <summary>
        /// Gets a value indicating whether the talkgroup is active
        /// </summary>
        public bool IsActive { get; }

        /// <summary>
        /// Gets the source radio ID
        /// </summary>
        public int SourceId { get; }

        /// <summary>
        /// Gets the timestamp when the talkgroup was detected
        /// </summary>
        public DateTime Timestamp { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="TalkgroupEventArgs"/> class
        /// </summary>
        public TalkgroupEventArgs(int talkgroupId, int nac, bool isActive, int sourceId)
        {
            TalkgroupId = talkgroupId;
            NAC = nac;
            IsActive = isActive;
            SourceId = sourceId;
            Timestamp = DateTime.UtcNow;
        }
    }
}

