param (
    [string]$InstallPath = "$env:ProgramFiles\P25Scanner",
    [string]$ServiceName = "P25Scanner",
    [string]$ServiceDisplayName = "P25 Digital Scanner Service",
    [string]$ServiceDescription = "Monitors and decodes P25 digital radio transmissions"
)

# Require administrator privileges
#Requires -RunAsAdministrator

$ErrorActionPreference = "Stop"

function Write-Step {
    param([string]$Message)
    Write-Host "`n=== $Message ===" -ForegroundColor Cyan
}

try {
    # Create installation directory
    Write-Step "Creating installation directory"
    if (-not (Test-Path $InstallPath)) {
        New-Item -ItemType Directory -Force -Path $InstallPath | Out-Null
    }

    # Copy application files
    Write-Step "Copying application files"
    $sourceFiles = Join-Path $PSScriptRoot "..\bin\Release\net7.0\*"
    Copy-Item -Path $sourceFiles -Destination $InstallPath -Recurse -Force

    # Create data directories
    Write-Step "Creating data directories"
    @("Logs", "Recordings", "ChannelLists", "Statistics") | ForEach-Object {
        $path = Join-Path $InstallPath $_
        if (-not (Test-Path $path)) {
            New-Item -ItemType Directory -Force -Path $path | Out-Null
        }
    }

    # Create default configuration if it doesn't exist
    $configPath = Join-Path $InstallPath "appsettings.json"
    if (-not (Test-Path $configPath)) {
        Write-Step "Creating default configuration"
        @{
            "Scanner" = @{
                "AutoStart" = $true
                "DefaultChannelList" = "default"
            }
            "Sdr" = @{
                "SampleRate" = 2048000
                "Gain" = 42
                "SquelchThreshold" = -35
            }
            "Audio" = @{
                "Enabled" = $true
                "Volume" = 1.0
            }
            "Recording" = @{
                "Enabled" = $true
                "Path" = Join-Path $InstallPath "Recordings"
            }
            "LogLevel" = "Information"
        } | ConvertTo-Json -Depth 10 | Out-File $configPath -Encoding UTF8
    }

    # Install Windows Service
    Write-Step "Installing Windows Service"
    $servicePath = Join-Path $InstallPath "P25Scanner.exe"
    
    if (Get-Service $ServiceName -ErrorAction SilentlyContinue) {
        Write-Host "Stopping and removing existing service..."
        Stop-Service $ServiceName -Force
        Remove-Service $ServiceName
    }

    $params = @{
        Name = $ServiceName
        BinaryPathName = "`"$servicePath`""
        DisplayName = $ServiceDisplayName
        Description = $ServiceDescription
        StartupType = "Automatic"
    }

    New-Service @params | Out-Null

    # Set service recovery options
    Write-Step "Configuring service recovery options"
    $recoveryActions = @(
        "/rst:0", # First failure: Restart
        "/rst:0", # Second failure: Restart
        "/rst:0"  # Subsequent failures: Restart
    )
    sc.exe failure $ServiceName reset= 86400 actions= $recoveryActions

    # Create firewall rules
    Write-Step "Configuring firewall rules"
    $ruleName = "P25Scanner"
    if (Get-NetFirewallRule -Name $ruleName -ErrorAction SilentlyContinue) {
        Remove-NetFirewallRule -Name $ruleName
    }

    New-NetFirewallRule `
        -Name $ruleName `
        -DisplayName "P25 Scanner" `
        -Description $ServiceDescription `
        -Direction Inbound `
        -Program $servicePath `
        -Action Allow | Out-Null

    # Start the service
    Write-Step "Starting service"
    Start-Service $ServiceName
    
    # Check service status
    $service = Get-Service $ServiceName
    if ($service.Status -eq "Running") {
        Write-Host "`nService installed and started successfully!" -ForegroundColor Green
        Write-Host "Installation path: $InstallPath"
        Write-Host "Service name: $ServiceName"
        Write-Host "Status: $($service.Status)"
    }
    else {
        throw "Service failed to start. Status: $($service.Status)"
    }
}
catch {
    Write-Host "`nError: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Stack trace: $($_.ScriptStackTrace)" -ForegroundColor Red
    exit 1
}

