param (
    [string]$ServiceName = "P25Scanner",
    [string]$InstallPath = "$env:ProgramFiles\P25Scanner",
    [switch]$KeepData
)

#Requires -RunAsAdministrator

$ErrorActionPreference = "Stop"

try {
    # Stop and remove service
    if (Get-Service $ServiceName -ErrorAction SilentlyContinue) {
        Write-Host "Stopping service..."
        Stop-Service $ServiceName -Force
        Write-Host "Removing service..."
        Remove-Service $ServiceName
    }

    # Remove firewall rule
    if (Get-NetFirewallRule -Name $ServiceName -ErrorAction SilentlyContinue) {
        Write-Host "Removing firewall rule..."
        Remove-NetFirewallRule -Name $ServiceName
    }

    # Remove application files
    if (Test-Path $InstallPath) {
        if ($KeepData) {
            Write-Host "Preserving data directories..."
            # Move data directories to temp location
            $tempPath = Join-Path $env:TEMP "P25Scanner_Data"
            New-Item -ItemType Directory -Force -Path $tempPath | Out-Null
            @("Logs", "Recordings", "ChannelLists", "Statistics") | ForEach-Object {
                $sourcePath = Join-Path $InstallPath $_
                if (Test-Path $sourcePath) {
                    Move-Item -Path $sourcePath -Destination $tempPath -Force
                }
            }
        }

        Write-Host "Removing installation directory..."
        Remove-Item -Path $InstallPath -Recurse -Force

        if ($KeepData) {
            # Move data directories back
            New-Item -ItemType Directory -Force -Path $InstallPath | Out-Null
            Get-ChildItem -Path $tempPath | Move-Item -Destination $InstallPath
            Remove-Item -Path $tempPath -Recurse -Force
        }
    }

    Write-Host "`nP25Scanner service uninstalled successfully!" -ForegroundColor Green
}
catch {
    Write-Host "`nError: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

