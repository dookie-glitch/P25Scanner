param (
    [string]$Configuration = "Release",
    [string]$Framework = "net7.0",
    [string]$Platform = "win-x64"
)

# Script variables
$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $PSScriptRoot
$buildFolder = Join-Path -Path $projectRoot -ChildPath "bin\$Configuration\$Framework"
$publishFolder = Join-Path -Path $projectRoot -ChildPath "bin\$Configuration\$Framework\$Platform\publish"
$desktopPath = [Environment]::GetFolderPath("Desktop")
$releaseFolderName = "P25ScannerRelease"
$releaseFolder = Join-Path -Path $desktopPath -ChildPath $releaseFolderName
$zipFileName = "p25scanner-$Configuration-$(Get-Date -Format 'yyyyMMdd').zip"
$zipFilePath = Join-Path -Path $desktopPath -ChildPath $zipFileName

function Write-Step {
    param([string]$Message)
    Write-Host "`n=== $Message ===" -ForegroundColor Cyan
}

try {
    # Clean and build the project
    Write-Step "Building project in $Configuration configuration"
    dotnet clean $projectRoot
    dotnet build $projectRoot -c $Configuration
    if ($LASTEXITCODE -ne 0) { throw "Build failed" }

    # Publish the application
    Write-Step "Publishing application"
    dotnet publish $projectRoot -c $Configuration -r $Platform --self-contained false
    if ($LASTEXITCODE -ne 0) { throw "Publish failed" }

    # Create and clean release folder
    Write-Step "Preparing release folder"
    if (Test-Path $releaseFolder) {
        Remove-Item -Path $releaseFolder -Recurse -Force
    }
    New-Item -ItemType Directory -Force -Path $releaseFolder | Out-Null

    # Copy published files
    Write-Step "Copying files to release folder"
    Copy-Item -Path "$publishFolder\*" -Destination $releaseFolder -Recurse

    # Copy configuration files
    Copy-Item -Path "$projectRoot\appsettings.json" -Destination $releaseFolder
    Copy-Item -Path "$projectRoot\appsettings.*.json" -Destination $releaseFolder -ErrorAction SilentlyContinue

    # Copy documentation
    Copy-Item -Path "$projectRoot\README.md" -Destination $releaseFolder
    Copy-Item -Path "$projectRoot\TECHNICAL.md" -Destination $releaseFolder -ErrorAction SilentlyContinue
    Copy-Item -Path "$projectRoot\LICENSE" -Destination $releaseFolder -ErrorAction SilentlyContinue

    # Create necessary folders
    Write-Step "Creating application folders"
    @("Logs", "Recordings", "ChannelLists", "Statistics") | ForEach-Object {
        New-Item -ItemType Directory -Force -Path "$releaseFolder\$_" | Out-Null
    }

    # Create version info file
    Write-Step "Creating version information"
    @"
P25Scanner Release Information
============================
Version: $((Get-Item "$buildFolder\P25Scanner.dll").VersionInfo.FileVersion)
Build Date: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
Configuration: $Configuration
Framework: $Framework
Platform: $Platform
"@ | Out-File -FilePath "$releaseFolder\version.txt"

    # Create zip file
    Write-Step "Creating zip archive"
    if (Test-Path $zipFilePath) {
        Remove-Item -Path $zipFilePath -Force
    }
    Compress-Archive -Path $releaseFolder\* -DestinationPath $zipFilePath

    # Clean up
    Write-Step "Cleaning up"
    Remove-Item -Path $releaseFolder -Recurse -Force

    Write-Host "`nPackage created successfully at: $zipFilePath" -ForegroundColor Green
    Write-Host "Size: $([math]::Round((Get-Item $zipFilePath).Length / 1MB, 2)) MB"
}
catch {
    Write-Host "`nError: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

