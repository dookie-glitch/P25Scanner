using System;
using System.Runtime.Serialization;
using P25Scanner.Native;

namespace P25Scanner.Exceptions
{
    /// <summary>
    /// Exception thrown when an RTL-SDR operation fails.
    /// </summary>
    [Serializable]
    public class RtlSdrException : Exception
    {
        /// <summary>
        /// The native error code returned by the RTL-SDR library.
        /// </summary>
        public int ErrorCode { get; }

        /// <summary>
        /// The error type categorized from the error code.
        /// </summary>
        public RtlSdr.RtlSdrError ErrorType { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="RtlSdrException"/> class.
        /// </summary>
        public RtlSdrException() : base("An RTL-SDR operation failed.")
        {
            ErrorCode = 0;
            ErrorType = RtlSdr.RtlSdrError.None;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RtlSdrException"/> class with a specified error message.
        /// </summary>
        /// <param name="message">The message that describes the error.</param>
        public RtlSdrException(string message) : base(message)
        {
            ErrorCode = 0;
            ErrorType = RtlSdr.RtlSdrError.None;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RtlSdrException"/> class with a specified error message
        /// and a reference to the inner exception that is the cause of this exception.
        /// </summary>
        /// <param name="message">The message that describes the error.</param>
        /// <param name="innerException">The exception that is the cause of the current exception.</param>
        public RtlSdrException(string message, Exception innerException) : base(message, innerException)
        {
            ErrorCode = 0;
            ErrorType = RtlSdr.RtlSdrError.None;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RtlSdrException"/> class with a specified error message
        /// and error code.
        /// </summary>
        /// <param name="message">The message that describes the error.</param>
        /// <param name="errorCode">The native error code from the RTL-SDR library.</param>
        public RtlSdrException(string message, int errorCode) : base(message)
        {
            ErrorCode = errorCode;
            ErrorType = RtlSdr.GetErrorType(errorCode);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RtlSdrException"/> class with serialized data.
        /// </summary>
        /// <param name="info">The SerializationInfo that holds the serialized object data about the exception being thrown.</param>
        /// <param name="context">The StreamingContext that contains contextual information about the source or destination.</param>
        protected RtlSdrException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
            ErrorCode = info.GetInt32(nameof(ErrorCode));
            ErrorType = (RtlSdr.RtlSdrError)info.GetInt32(nameof(ErrorType));
        }

        /// <summary>
        /// Sets the SerializationInfo with information about the exception.
        /// </summary>
        /// <param name="info">The SerializationInfo that holds the serialized object data about the exception being thrown.</param>
        /// <param name="context">The StreamingContext that contains contextual information about the source or destination.</param>
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
            info.AddValue(nameof(ErrorCode), ErrorCode);
            info.AddValue(nameof(ErrorType), (int)ErrorType);
        }

        /// <summary>
        /// Gets a descriptive error message based on the error type.
        /// </summary>
        /// <returns>A descriptive error message.</returns>
        public string GetErrorDescription()
        {
            return ErrorType switch
            {
                RtlSdr.RtlSdrError.None => "No error",
                RtlSdr.RtlSdrError.NotFound => "Device not found",
                RtlSdr.RtlSdrError.InvalidParam => "Invalid parameter",
                RtlSdr.RtlSdrError.NotSupported => "Operation not supported",
                RtlSdr.RtlSdrError.AllocFailed => "Memory allocation failed",
                RtlSdr.RtlSdrError.InitFailed => "Device initialization failed",
                RtlSdr.RtlSdrError.IOError => "Input/output error",
                RtlSdr.RtlSdrError.Invalid => "Invalid operation",
                RtlSdr.RtlSdrError.Timeout => "Operation timed out",
                _ => $"Unknown error ({ErrorCode})"
            };
        }
    }
}

