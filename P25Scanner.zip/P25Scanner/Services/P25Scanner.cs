using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;

namespace P25Scanner.Services
{
    /// <summary>
    /// Event arguments for when a P25 signal is detected
    /// </summary>
    public class P25SignalEventArgs : EventArgs
    {
        public double Frequency { get; }
        public double SignalStrength { get; }
        public string Talkgroup { get; }
        public string UnitId { get; }
        public string Message { get; }
        public DateTime Timestamp { get; }

        public P25SignalEventArgs(double frequency, double signalStrength, string talkgroup, string unitId, string message)
        {
            Frequency = frequency;
            SignalStrength = signalStrength;
            Talkgroup = talkgroup;
            UnitId = unitId;
            Message = message;
            Timestamp = DateTime.Now;
        }
    }

    /// <summary>
    /// Configuration for the P25 Scanner
    /// </summary>
    public class P25ScannerConfig
    {
        /// <summary>
        /// Minimum frequency to scan in Hz
        /// </summary>
        public double MinFrequency { get; set; } = 138000000;
        
        /// <summary>
        /// Maximum frequency to scan in Hz
        /// </summary>
        public double MaxFrequency { get; set; } = 174000000;
        
        /// <summary>
        /// Step size for frequency scanning in Hz
        /// </summary>
        public double StepSize { get; set; } = 12500;
        
        /// <summary>
        /// Dwell time on each frequency in milliseconds
        /// </summary>
        public int DwellTimeMs { get; set; } = 200;
        
        /// <summary>
        /// Signal threshold for detecting a signal (in dB)
        /// </summary>
        public double SignalThreshold { get; set; } = -70;
        
        /// <summary>
        /// Gain to use for the RTL-SDR device
        /// </summary>
        public double Gain { get; set; } = 42.0;
        
        /// <summary>
        /// Sample rate to use for the RTL-SDR device
        /// </summary>
        public uint SampleRate { get; set; } = 2400000;
        
        /// <summary>
        /// List of specific frequencies to monitor (in Hz)
        /// </summary>
        public List<double> MonitorFrequencies { get; set; } = new List<double>();
        
        /// <summary>
        /// Whether to use frequency lists instead of scanning ranges
        /// </summary>
        public bool UseFrequencyList { get; set; } = false;
    }

    /// <summary>
    /// Represents the current state of the P25 scanner
    /// </summary>
    public enum ScannerState
    {
        Stopped,
        Scanning,
        Monitoring,
        Paused
    }

    /// <summary>
    /// Provides P25 scanning capabilities using an RTL-SDR device
    /// </summary>
    public class P25Scanner : IDisposable
    {
        private readonly RtlSdrDevice _device;
        private P25ScannerConfig _config;
        private ScannerState _state = ScannerState.Stopped;
        private CancellationTokenSource _scanCts;
        private Task _scanTask;
        private double _currentFrequency;
        private readonly object _lockObject = new object();
        private readonly Dictionary<double, int> _signalHits = new Dictionary<double, int>();
        
        // FFT processing variables
        private const int FftSize = 4096;
        private Complex[] _fftBuffer = new Complex[FftSize];
        private double[] _powerSpectrum = new double[FftSize];
        private int _samplesCollected = 0;
        
        // P25 specific constants
        private const double P25SymbolRate = 4800;
        private const double P25DeviationHz = 4000;

        /// <summary>
        /// Event that is raised when a P25 signal is detected
        /// </summary>
        public event EventHandler<P25SignalEventArgs> SignalDetected;
        
        /// <summary>
        /// Event that is raised when the scanner frequency changes
        /// </summary>
        public event EventHandler<double> FrequencyChanged;
        
        /// <summary>
        /// Event that is raised when the scanner state changes
        /// </summary>
        public event EventHandler<ScannerState> StateChanged;

        /// <summary>
        /// Gets the current scanner state
        /// </summary>
        public ScannerState State 
        { 
            get => _state;
            private set
            {
                if (_state != value)
                {
                    _state = value;
                    StateChanged?.Invoke(this, _state);
                }
            }
        }

        /// <summary>
        /// Gets the current frequency being scanned
        /// </summary>
        public double CurrentFrequency
        {
            get => _currentFrequency;
            private set
            {
                if (Math.Abs(_currentFrequency - value) > 0.1)
                {
                    _currentFrequency = value;
                    FrequencyChanged?.Invoke(this, _currentFrequency);
                }
            }
        }

        /// <summary>
        /// Creates a new P25Scanner with the default configuration
        /// </summary>
        public P25Scanner() : this(new P25ScannerConfig())
        {
        }

        /// <summary>
        /// Creates a new P25Scanner with the specified configuration
        /// </summary>
        /// <param name="config">The scanner configuration</param>
        public P25Scanner(P25ScannerConfig config)
        {
            _config = config ?? throw new ArgumentNullException(nameof(config));
            _device = new RtlSdrDevice();
            _device.SamplesAvailable += Device_SamplesAvailable;
        }

        /// <summary>
        /// Starts the scanner with the current configuration
        /// </summary>
        public async Task Start()
        {
            if (State != ScannerState.Stopped && State != ScannerState.Paused)
                return;

            if (!_device.IsOpen)
            {
                await OpenDevice();
            }

            _scanCts = new CancellationTokenSource();
            State = ScannerState.Scanning;
            
            _scanTask = Task.Run(() => ScanFrequencies(_scanCts.Token), _scanCts.Token);
        }

        /// <summary>
        /// Stops the scanner
        /// </summary>
        public async Task Stop()
        {
            if (State == ScannerState.Stopped)
                return;

            if (_scanCts != null)
            {
                _scanCts.Cancel();
                try
                {
                    if (_scanTask != null)
                        await _scanTask;
                }
                catch (OperationCanceledException)
                {
                    // Expected when cancelling
                }
                _scanCts.Dispose();
                _scanCts = null;
            }

            if (_device.IsOpen)
            {
                _device.StopReading();
                _device.Close();
            }

            State = ScannerState.Stopped;
        }

        /// <summary>
        /// Pauses the scanner
        /// </summary>
        public void Pause()
        {
            if (State != ScannerState.Scanning && State != ScannerState.Monitoring)
                return;

            _device.StopReading();
            State = ScannerState.Paused;
        }

        /// <summary>
        /// Updates the scanner configuration
        /// </summary>
        /// <param name="config">The new configuration</param>
        public void UpdateConfig(P25ScannerConfig config)
        {
            if (config == null)
                throw new ArgumentNullException(nameof(config));

            bool wasRunning = State == ScannerState.Scanning || State == ScannerState.Monitoring;
            
            if (wasRunning)
            {
                _ = Stop().ConfigureAwait(false);
            }

            _config = config;

            if (wasRunning)
            {
                _ = Start().ConfigureAwait(false);
            }
        }

        /// <summary>
        /// Sets the scanner to monitor a specific frequency
        /// </summary>
        /// <param name="frequency">The frequency to monitor in Hz</param>
        public async Task MonitorFrequency(double frequency)
        {
            if (frequency < 24000000 || frequency > 1766000000)
                throw new ArgumentOutOfRangeException(nameof(frequency), "Frequency must be between 24 MHz and 1766 MHz");

            bool wasRunning = State == ScannerState.Scanning || State == ScannerState.Monitoring;
            
            if (wasRunning)
            {
                await Stop();
            }

            if (!_device.IsOpen)
            {
                await OpenDevice();
            }

            CurrentFrequency = frequency;
            await _device.SetCenterFrequency((uint)frequency);
            _device.StartReading();
            
            State = ScannerState.Monitoring;
        }

        private async Task OpenDevice()
        {
            if (_device.IsOpen)
                return;

            await _device.Open();
            await _device.SetSampleRate(_config.SampleRate);
            await _device.SetGain(_config.Gain);
            await _device.ResetBuffer();
        }

        private async Task ScanFrequencies(CancellationToken token)
        {
            IEnumerable<double> frequencies;
            
            if (_config.UseFrequencyList && _config.MonitorFrequencies.Count > 0)
            {
                frequencies = _config.MonitorFrequencies;
            }
            else
            {
                frequencies = GenerateFrequencyRange(_config.MinFrequency, _config.MaxFrequency, _config.StepSize);
            }

            while (!token.IsCancellationRequested)
            {
                foreach (double freq in frequencies)
                {
                    if (token.IsCancellationRequested)
                        break;

                    CurrentFrequency = freq;
                    await _device.SetCenterFrequency((uint)freq);
                    _device.StartReading();

                    // Wait on the current frequency for the dwell time
                    await Task.Delay(_config.DwellTimeMs, token);
                    
                    _device.StopReading();
                    
                    // Check if we detected a signal and should stay on this frequency
                    if (_signalHits.TryGetValue(freq, out int hits) && hits > 2)
                    {
                        // We have a signal, stay on this frequency longer
                        _device.StartReading();
                        State = ScannerState.Monitoring;
                        
                        // Wait longer on strong signals
                        await Task.Delay(1000, token);
                        
                        _device.StopReading();
                        State = ScannerState.Scanning;
                        
                        // Reset hit counter
                        _signalHits[freq] = 0;
                    }
                }
            }
        }

        private IEnumerable<double> GenerateFrequencyRange(double min, double max, double step)
        {
            for (double freq = min; freq <= max; freq += step)
            {
                yield return freq;
            }
        }

        private void Device_SamplesAvailable(object sender, SamplesAvailableEventArgs e)
        {
            ProcessSamples(e.Samples, e.Length);
        }

        private void ProcessSamples(Complex[] samples, int length)
        {
            // Copy samples to FFT buffer
            for (int i = 0; i < length && _samplesCollected < FftSize; i++)
            {
                _fftBuffer[_samplesCollected++] = samples[i];
            }

            // When we have enough samples, perform FFT and signal detection
            if (_samplesCollected >= FftSize)
            {
                double signalPower = PerformSignalDetection(_fftBuffer);
                
                if (signalPower > _config.SignalThreshold)
                {
                    RegisterSignalHit(CurrentFrequency);
                    
                    // Attempt P25 demodulation and decoding
                    TryDemodulateP25Signal(_fftBuffer);
                }
                
                _samplesCollected = 0;
            }
        }

        private double PerformSignalDetection(Complex[] samples)
        {
            // Simple power calculation for signal detection
            double power = 0;
            
            for (int i = 0; i < samples.Length; i++)
            {
                // Calculate magnitude squared
                double magnitude = samples[i].Magnitude;
                power += magnitude * magnitude;
            }
            
            // Convert to dB
            power /= samples.Length;
            double powerDb = 10 * Math.Log10(power);
            
            return powerDb;
        }

        private void RegisterSignalHit(double frequency)
        {
            lock (_lockObject)
            {
                if (!_signalHits.ContainsKey(frequency))
                {
                    _signalHits[frequency] = 0;
                }
                
                _signalHits[frequency]++;
            }
        }

        private void TryDemodulateP25Signal(Complex[] samples)
        {
            // This is a simplified placeholder for P25 demodulation
            // Real P25 demodulation would require more sophisticated signal processing
            
            // Here we're simulating finding a P25 signal
            // In a real implementation, we would:
            // 1. FM demodulate the signal
            // 2. Extract the P25 frames
            // 3. Decode the IMBE voice codec
            // 4. Extract talkgroup and unit IDs
            
            // For demonstration purposes, we'll randomly decide if we found a valid P25 signal
            if (new Random().NextDouble() < 0.1) // 10% chance of "finding" a P25 signal
            {
                // Generate sample P25 data
                string talkgroup = $"{new Random().Next(1, 9999):D4}";
                string unitId = $"{new Random().Next(100000, 999999)}";
                string message = "Signal detected";
                
                // Calculate signal strength based on sample power
                double signalStrength = CalculateSignalStrength(samples);
                
                // Raise the signal detected event
                SignalDetected?.Invoke(this, new P25SignalEventArgs(
                    CurrentFrequency,
                    signalStrength,
                    talkgroup,
                    unitId,
                    message));
            }
        }

        private double CalculateSignalStrength(Complex[] samples)
        {
            double power = 0;
            
            for (int i = 0; i < samples.Length; i++)
            {
                double magnitude = samples[i].Magnitude;
                power += magnitude * magnitude;
            }
            
            // Normalize and convert to dB
            power /= samples.Length;
            return 10 * Math.Log10(power);
        }

        #region IDisposable Support
        private bool _disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    // Dispose managed resources
                    _scanCts?.Cancel();
                    _scanCts?.Dispose();
                    _scanCts = null;

                    if (_device != null)
                    {
                        _device.SamplesAvailable -= Device_SamplesAvailable;
                        if (_device.IsOpen)
                        {
                            _device.StopReading();
                            _device.Close();
                        }
                        _device.Dispose();
                    }
                }

                // Free unmanaged resources
                // Set large fields to null

                _disposed = true;
            }
        }

        // Add a finalizer if the class uses unmanaged resources
        ~P25Scanner()
        {
            Dispose(false);
        }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion
