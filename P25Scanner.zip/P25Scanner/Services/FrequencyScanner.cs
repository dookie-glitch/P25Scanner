using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using P25Scanner.Configuration;

namespace P25Scanner.Services
{
    public class FrequencyScanner : IDisposable
    {
        private readonly ILogger<FrequencyScanner> _logger;
        private readonly AppConfig _config;
        private readonly IP25Decoder _decoder;
        private readonly ConcurrentDictionary<long, ChannelInfo> _channels;
        private CancellationTokenSource _scannerCts;
        private Task _scannerTask;
        private bool _isScanning;
        private bool _isPaused;
        private bool _isDisposed;
        private long _currentFrequency;
        private DateTime _lastActivityTime;
        private const int HOLD_TIME_MS = 1000;  // Time to hold on active frequency
        private const int SCAN_DELAY_MS = 100;  // Delay between frequency changes

        public class ChannelInfo
        {
            public long Frequency { get; set; }
            public string Name { get; set; }
            public DateTime LastActivity { get; set; }
            public float LastSignalQuality { get; set; }
            public int TalkgroupId { get; set; }
            public bool IsActive { get; set; }
            public int ActivityCount { get; set; }
        }

        public event EventHandler<ChannelInfo> ChannelActivityDetected;
        public event EventHandler<long> FrequencyChanged;

        public long CurrentFrequency => _currentFrequency;
        public bool IsScanning => _isScanning;
        public bool IsPaused => _isPaused;

        public FrequencyScanner(
            ILogger<FrequencyScanner> logger,
            AppConfig config,
            IP25Decoder decoder)
        {
            _logger = logger;
            _config = config;
            _decoder = decoder;
            _channels = new ConcurrentDictionary<long, ChannelInfo>();

            // Subscribe to decoder events
            _decoder.DecoderStatusChanged += Decoder_StatusChanged;
            _decoder.TalkgroupDetected += Decoder_TalkgroupDetected;
        }

        public void AddChannel(long frequency, string name = null)
        {
            var channel = new ChannelInfo
            {
                Frequency = frequency,
                Name = name ?? frequency.ToString()
            };

            _channels.TryAdd(frequency, channel);
            _logger.LogInformation("Added channel: {Frequency} Hz - {Name}", frequency, channel.Name);
        }

        public void RemoveChannel(long frequency)
        {
            if (_channels.TryRemove(frequency, out _))
            {
                _logger.LogInformation("Removed channel: {Frequency} Hz", frequency);
            }
        }

        public async Task StartScanningAsync(CancellationToken cancellationToken)
        {
            if (_isScanning)
                return;

            try
            {
                _scannerCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
                _isScanning = true;
                _isPaused = false;

                _scannerTask = ScanningLoopAsync(_scannerCts.Token);
                _logger.LogInformation("Scanner started");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error starting scanner");
                throw;
            }
        }

        public async Task StopScanningAsync()
        {
            if (!_isScanning)
                return;

            try
            {
                _scannerCts?.Cancel();
                if (_scannerTask != null)
                    await _scannerTask;

                _isScanning = false;
                _isPaused = false;
                _logger.LogInformation("Scanner stopped");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error stopping scanner");
            }
        }

        public void PauseScanning()
        {
            _isPaused = true;
            _logger.LogInformation("Scanner paused on frequency {Frequency} Hz", _currentFrequency);
        }

        public void ResumeScanning()
        {
            _isPaused = false;
            _logger.LogInformation("Scanner resumed");
        }

        private async Task ScanningLoopAsync(CancellationToken cancellationToken)
        {
            try
            {
                while (!cancellationToken.IsCancellationRequested)
                {
                    if (!_isPaused)
                    {
                        // Check if current frequency has recent activity
                        bool hasActivity = _currentFrequency != 0 &&
                                         DateTime.UtcNow.Subtract(_lastActivityTime).TotalMilliseconds < HOLD_TIME_MS;

                        if (!hasActivity)
                        {
                            // Move to next frequency
                            var nextFreq = GetNextFrequency();
                            if (nextFreq != _currentFrequency)
                            {
                                await SetFrequencyAsync(nextFreq);
                            }
                        }
                    }

                    await Task.Delay(SCAN_DELAY_MS, cancellationToken);
                }
            }
            catch (OperationCanceledException)
            {
                // Normal cancellation
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in scanning loop");
            }
        }

        private long GetNextFrequency()
        {
            if (_channels.IsEmpty)
                return 0;

            var frequencies = new List<long>(_channels.Keys);
            int currentIndex = frequencies.IndexOf(_currentFrequency);
            int nextIndex = (currentIndex + 1) % frequencies.Count;
            return frequencies[nextIndex];
        }

        private async Task SetFrequencyAsync(long frequency)
        {
            _currentFrequency = frequency;
            FrequencyChanged?.Invoke(this, frequency);
            _logger.LogDebug("Scanning frequency: {Frequency} Hz", frequency);
        }

        private void Decoder_StatusChanged(object sender, Services.Interfaces.DecoderStatusEventArgs e)
        {
            if (_channels.TryGetValue(_currentFrequency, out var channel))
            {
                channel.LastSignalQuality = _decoder.SignalQuality;
                channel.IsActive = e.Status == Services.Interfaces.DecoderStatus.Running;

                if (channel.IsActive)
                {
                    _lastActivityTime = DateTime.UtcNow;
                    channel.LastActivity = _lastActivityTime;
                    channel.ActivityCount++;
                    ChannelActivityDetected?.Invoke(this, channel);
                }
            }
        }

        private void Decoder_TalkgroupDetected(object sender, Services.Interfaces.TalkgroupEventArgs e)
        {
            if (_channels.TryGetValue(_currentFrequency, out var channel))
            {
                channel.TalkgroupId = e.TalkgroupId;
            }
        }

        public IReadOnlyDictionary<long, ChannelInfo> GetChannels()
        {
            return _channels;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_isDisposed)
            {
                if (disposing)
                {
                    StopScanningAsync().Wait();
                    _scannerCts?.Dispose();
                    _decoder.DecoderStatusChanged -= Decoder_StatusChanged;
                    _decoder.TalkgroupDetected -= Decoder_TalkgroupDetected;
                }

                _isDisposed = true;
            }
        }
    }
}

