using System;
using Microsoft.Extensions.DependencyInjection;
using P25Scanner.Services;

namespace P25Scanner
{
    /// <summary>
    /// Extension methods for setting up P25Scanner services in an <see cref="IServiceCollection"/>.
    /// </summary>
    public static class ServiceCollectionExtensions
    {
        /// <summary>
        /// Adds P25Scanner services to the specified <see cref="IServiceCollection"/>.
        /// </summary>
        /// <param name="services">The <see cref="IServiceCollection"/> to add services to.</param>
        /// <returns>The <see cref="IServiceCollection"/> so that additional calls can be chained.</returns>
        public static IServiceCollection AddP25ScannerServices(this IServiceCollection services)
        {
            if (services == null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            // Register the RtlSdrDevice as transient since it represents a hardware connection
            // that should be created/disposed as needed
            services.AddTransient<RtlSdrDevice>();

            // Register the P25ScannerConfig as a singleton with default values
            services.AddSingleton<P25ScannerConfig>();

            // Register the P25Scanner as a singleton since we only want one scanner instance
            services.AddSingleton<P25Scanner>();

            return services;
        }

        /// <summary>
        /// Adds P25Scanner services to the specified <see cref="IServiceCollection"/> with custom configuration.
        /// </summary>
        /// <param name="services">The <see cref="IServiceCollection"/> to add services to.</param>
        /// <param name="configureOptions">A callback to configure the <see cref="P25ScannerConfig"/>.</param>
        /// <returns>The <see cref="IServiceCollection"/> so that additional calls can be chained.</returns>
        public static IServiceCollection AddP25ScannerServices(
            this IServiceCollection services,
            Action<P25ScannerConfig> configureOptions)
        {
            if (services == null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            if (configureOptions == null)
            {
                throw new ArgumentNullException(nameof(configureOptions));
            }

            // Register the RtlSdrDevice as transient
            services.AddTransient<RtlSdrDevice>();

            // Register the P25ScannerConfig as a singleton with custom configuration
            services.AddSingleton(provider => {
                var config = new P25ScannerConfig();
                configureOptions(config);
                return config;
            });

            // Register the P25Scanner as a singleton
            services.AddSingleton<P25Scanner>();

            return services;
        }
    }
}

