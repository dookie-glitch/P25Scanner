using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NAudio.Wave;
using P25Scanner.Configuration;

namespace P25Scanner.Services
{
    public class AudioPlaybackManager : IDisposable
    {
        private readonly ILogger<AudioPlaybackManager> _logger;
        private readonly AppConfig _config;
        private readonly ConcurrentQueue<float[]> _audioBuffer;
        private IWavePlayer _waveOut;
        private BufferedWaveProvider _bufferedWaveProvider;
        private WaveFileReader _fileReader;
        private CancellationTokenSource _playbackCts;
        private Task _playbackTask;
        private bool _isDisposed;
        private float _volume = 1.0f;
        private bool _isMuted;

        public bool IsPlaying => _waveOut?.PlaybackState == PlaybackState.Playing;
        public float Volume
        {
            get => _volume;
            set
            {
                _volume = Math.Clamp(value, 0, 1);
                if (_waveOut != null)
                    _waveOut.Volume = _isMuted ? 0 : _volume;
            }
        }

        public bool IsMuted
        {
            get => _isMuted;
            set
            {
                _isMuted = value;
                if (_waveOut != null)
                    _waveOut.Volume = _isMuted ? 0 : _volume;
            }
        }

        public AudioPlaybackManager(ILogger<AudioPlaybackManager> logger, AppConfig config)
        {
            _logger = logger;
            _config = config;
            _audioBuffer = new ConcurrentQueue<float[]>();
        }

        public async Task InitializeAsync(int deviceNumber = -1)
        {
            try
            {
                if (_waveOut != null)
                    return;

                // Create wave output device
                _waveOut = new WaveOutEvent
                {
                    DeviceNumber = deviceNumber,
                    DesiredLatency = 100
                };

                // Create buffered provider
                _bufferedWaveProvider = new BufferedWaveProvider(new WaveFormat(8000, 16, 1))
                {
                    DiscardOnBufferOverflow = true
                };

                _waveOut.Init(_bufferedWaveProvider);
                _waveOut.Play();

                // Start playback task
                _playbackCts = new CancellationTokenSource();
                _playbackTask = PlaybackLoopAsync(_playbackCts.Token);

                _logger.LogInformation("Audio playback initialized with device {DeviceNumber}", deviceNumber);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to initialize audio playback");
                throw;
            }
        }

        public async Task StopAsync()
        {
            try
            {
                _playbackCts?.Cancel();
                if (_playbackTask != null)
                    await _playbackTask;

                _waveOut?.Stop();
                _fileReader?.Dispose();
                _fileReader = null;

                while (_audioBuffer.TryDequeue(out _)) { }

                _logger.LogInformation("Audio playback stopped");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error stopping audio playback");
            }
        }

        public void QueueAudio(float[] samples)
        {
            if (samples == null || samples.Length == 0)
                return;

            _audioBuffer.Enqueue(samples);
        }

        public async Task PlayRecordingAsync(string filePath)
        {
            try
            {
                await StopAsync();

                _fileReader = new WaveFileReader(filePath);
                var waveOut = new WaveOutEvent();
                waveOut.Init(_fileReader);
                waveOut.PlaybackStopped += (s, e) =>
                {
                    _fileReader?.Dispose();
                    _fileReader = null;
                    waveOut.Dispose();
                };
                waveOut.Play();

                _logger.LogInformation("Started playing recording: {FilePath}", filePath);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error playing recording");
                throw;
            }
        }

        private async Task PlaybackLoopAsync(CancellationToken cancellationToken)
        {
            var bytesBuffer = new byte[4096];

            try
            {
                while (!cancellationToken.IsCancellationRequested)
                {
                    if (_audioBuffer.TryDequeue(out float[] samples))
                    {
                        // Convert float samples to 16-bit PCM
                        var pcmSamples = new short[samples.Length];
                        for (int i = 0; i < samples.Length; i++)
                        {
                            float sample = samples[i] * _volume;
                            if (_isMuted) sample = 0;
                            pcmSamples[i] = (short)(sample * short.MaxValue);
                        }

                        // Convert to bytes and add to buffer
                        var byteCount = pcmSamples.Length * 2;
                        if (bytesBuffer.Length < byteCount)
                            bytesBuffer = new byte[byteCount];

                        Buffer.BlockCopy(pcmSamples, 0, bytesBuffer, 0, byteCount);
                        _bufferedWaveProvider.AddSamples(bytesBuffer, 0, byteCount);
                    }
                    else
                    {
                        await Task.Delay(10, cancellationToken);
                    }
                }
            }
            catch (OperationCanceledException)
            {
                // Normal cancellation
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in audio playback loop");
            }
        }

        public IReadOnlyList<WaveOutCapabilities> GetAvailableDevices()
        {
            var devices = new List<WaveOutCapabilities>();
            for (int i = 0; i < WaveOut.DeviceCount; i++)
            {
                devices.Add(WaveOut.GetCapabilities(i));
            }
            return devices;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_isDisposed)
            {
                if (disposing)
                {
                    StopAsync().Wait();
                    _playbackCts?.Dispose();
                    _waveOut?.Dispose();
                    _fileReader?.Dispose();
                }

                _isDisposed = true;
            }
        }
    }
}

