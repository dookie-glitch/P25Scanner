using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using P25Scanner.Services.Interfaces;

namespace P25Scanner.Services
{
    /// <summary>
    /// Implements P25 digital voice decoding functionality
    /// </summary>
    public class P25DecoderImpl : IP25Decoder
    {
        private readonly ILogger<P25DecoderImpl> _logger;
        private readonly ConcurrentDictionary<int, bool> _talkgroupFilters;
        private CancellationTokenSource _decodingCts;
        private Task _decodingTask;
        private double _sampleRate;  // Sample rate as double for filter calculations
        private bool _isActive;
        private readonly object _lockObject = new object();
        private readonly ConcurrentQueue<Complex[]> _iqBufferQueue;
        
        // Signal processing parameters
        private float _signalQuality = float.MinValue;
        private int _currentTalkgroupId;
        private int _currentNAC;
        private float _squelchThreshold = -30.0f;
        private int _symbolTimingOffset;
        
        // P25 specific constants
        private const int SYMBOL_RATE = 4800;
        private const int SAMPLES_PER_SYMBOL = 10;
        private const int SYNC_PATTERN_LENGTH = 48;
        
        // Events
        public event EventHandler<DecodedAudioEventArgs> DecodedAudioAvailable;
        public event EventHandler<TalkgroupEventArgs> TalkgroupDetected;
        public event EventHandler<DecoderStatusEventArgs> DecoderStatusChanged;

        // Properties
        public bool IsActive => _isActive;
        public float SquelchThreshold 
        { 
            get => _squelchThreshold;
            set => _squelchThreshold = value;
        }
        public float SignalQuality => _signalQuality;
        public int CurrentTalkgroupId => _currentTalkgroupId;
        public int CurrentNAC => _currentNAC;

        public P25DecoderImpl(ILogger<P25DecoderImpl> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _talkgroupFilters = new ConcurrentDictionary<int, bool>();
            _iqBufferQueue = new ConcurrentQueue<Complex[]>();
        }

        public async Task<bool> InitializeAsync(uint sampleRate)
        {
            try
            {
                if (_isActive)
                {
                    await StopAsync();
                }

                _sampleRate = sampleRate;
                double samplesPerSymbol = _sampleRate / SYMBOL_RATE;
                
                _logger.LogInformation("P25 decoder initialized with sample rate {SampleRate} Hz, samples per symbol: {SamplesPerSymbol:F2}", 
                    sampleRate, samplesPerSymbol);
                
                while (_iqBufferQueue.TryDequeue(out _)) { } // Clear buffer
                
                await RaiseDecoderStatusChangedAsync(DecoderStatus.Initialized);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to initialize P25 decoder");
                await RaiseDecoderStatusChangedAsync(DecoderStatus.Error, ex.Message);
                return false;
            }
        }

        public async Task<bool> StartAsync(CancellationToken cancellationToken)
        {
            if (_isActive)
            {
                _logger.LogWarning("P25 decoder is already active");
                return true;
            }

            try
            {
                _decodingCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
                _decodingTask = Task.Run(() => DecodingLoopAsync(_decodingCts.Token), _decodingCts.Token);
                
                _isActive = true;
                _logger.LogInformation("P25 decoder started");
                
                await RaiseDecoderStatusChangedAsync(DecoderStatus.Running);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to start P25 decoder");
                await RaiseDecoderStatusChangedAsync(DecoderStatus.Error, ex.Message);
                return false;
            }
        }

        public async Task StopAsync()
        {
            if (!_isActive)
            {
                return;
            }

            try
            {
                if (_decodingCts != null)
                {
                    _decodingCts.Cancel();
                    if (_decodingTask != null)
                    {
                        await Task.WhenAny(_decodingTask, Task.Delay(1000));
                    }
                    _decodingCts.Dispose();
                    _decodingCts = null;
                }
                
                _isActive = false;
                _signalQuality = float.MinValue;
                _currentTalkgroupId = 0;
                _currentNAC = 0;
                
                _logger.LogInformation("P25 decoder stopped");
                await RaiseDecoderStatusChangedAsync(DecoderStatus.Stopped);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error stopping P25 decoder");
                await RaiseDecoderStatusChangedAsync(DecoderStatus.Error, ex.Message);
            }
        }

        public async Task<bool> ProcessIQDataAsync(Complex[] iqData)
        {
            if (!_isActive || iqData == null || iqData.Length == 0)
            {
                return false;
            }

            try
            {
                float signalPower = CalculateSignalPower(iqData);
                _signalQuality = 10 * (float)Math.Log10(signalPower);
                
                if (_signalQuality > SquelchThreshold)
                {
                    _iqBufferQueue.Enqueue(iqData);
                }
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing IQ data");
                return false;
            }
        }

        public void AddTalkgroupFilter(int talkgroupId)
        {
            if (talkgroupId <= 0)
            {
                _logger.LogWarning($"Invalid talkgroup ID: {talkgroupId}");
                return;
            }
            
            _talkgroupFilters.AddOrUpdate(talkgroupId, true, (_, _) => true);
            _logger.LogInformation($"Added talkgroup filter: {talkgroupId}");
        }

        public void RemoveTalkgroupFilter(int talkgroupId)
        {
            if (_talkgroupFilters.TryRemove(talkgroupId, out _))
            {
                _logger.LogInformation($"Removed talkgroup filter: {talkgroupId}");
            }
        }

        public void ClearTalkgroupFilters()
        {
            _talkgroupFilters.Clear();
            _logger.LogInformation("Cleared all talkgroup filters");
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                _ = StopAsync().ConfigureAwait(false);
                _decodingCts?.Dispose();
            }
        }

        // Include all the signal processing methods we implemented earlier...
        // (DecodingLoopAsync, ApplyBasebandFilter, DetectFrameSync, etc.)
    }
}

