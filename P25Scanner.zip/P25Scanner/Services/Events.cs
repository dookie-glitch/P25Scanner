using System;
using P25Scanner.Models;

namespace P25Scanner.Services
{
    /// <summary>
    /// Event arguments for signal detection events
    /// </summary>
    public class SignalDetectedEventArgs : EventArgs
    {
        /// <summary>
        /// The detected signal
        /// </summary>
        public Signal Signal { get; }

        public SignalDetectedEventArgs(Signal signal)
        {
            Signal = signal;
        }
    }

    /// <summary>
    /// Event arguments for frequency change events
    /// </summary>
    public class FrequencyChangedEventArgs : EventArgs
    {
        /// <summary>
        /// The current frequency in Hz
        /// </summary>
        public double Frequency { get; }

        public FrequencyChangedEventArgs(double frequency)
        {
            Frequency = frequency;
        }
    }
}

