using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.Extensions.Logging;
using P25Scanner.Configuration;

namespace P25Scanner.Services
{
    public class ChannelListManager
    {
        private readonly ILogger<ChannelListManager> _logger;
        private readonly AppConfig _config;
        private readonly string _channelListPath;
        private readonly Dictionary<string, ChannelList> _channelLists;

        public class Channel
        {
            public long Frequency { get; set; }
            public string Name { get; set; }
            public string Description { get; set; }
            public string Category { get; set; }
            public Dictionary<string, string> Tags { get; set; }
            public bool IsEnabled { get; set; } = true;
            public int Priority { get; set; }
            public DateTime LastSeen { get; set; }
        }

        public class ChannelList
        {
            public string Name { get; set; }
            public string Description { get; set; }
            public DateTime Created { get; set; }
            public DateTime LastModified { get; set; }
            public Dictionary<long, Channel> Channels { get; set; }
            public bool IsActive { get; set; }
        }

        public ChannelListManager(ILogger<ChannelListManager> logger, AppConfig config)
        {
            _logger = logger;
            _config = config;
            _channelListPath = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "ChannelLists");
            _channelLists = new Dictionary<string, ChannelList>();

            if (!Directory.Exists(_channelListPath))
            {
                Directory.CreateDirectory(_channelListPath);
            }
        }

        public async Task LoadChannelListsAsync()
        {
            try
            {
                var files = Directory.GetFiles(_channelListPath, "*.json");
                foreach (var file in files)
                {
                    var json = await File.ReadAllTextAsync(file);
                    var channelList = JsonSerializer.Deserialize<ChannelList>(json);
                    if (channelList != null)
                    {
                        _channelLists[channelList.Name] = channelList;
                    }
                }

                _logger.LogInformation("Loaded {Count} channel lists", _channelLists.Count);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading channel lists");
            }
        }

        public async Task SaveChannelListAsync(string name)
        {
            if (!_channelLists.TryGetValue(name, out var channelList))
                return;

            try
            {
                channelList.LastModified = DateTime.UtcNow;
                var options = new JsonSerializerOptions { WriteIndented = true };
                var json = JsonSerializer.Serialize(channelList, options);
                string filePath = Path.Combine(_channelListPath, $"{name}.json");
                await File.WriteAllTextAsync(filePath, json);

                _logger.LogInformation("Saved channel list: {Name}", name);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error saving channel list: {Name}", name);
            }
        }

        public async Task<bool> ImportFromCsvAsync(string filePath, string listName)
        {
            try
            {
                var channelList = new ChannelList
                {
                    Name = listName,
                    Created = DateTime.UtcNow,
                    LastModified = DateTime.UtcNow,
                    Channels = new Dictionary<long, Channel>()
                };

                using var reader = new StreamReader(filePath);
                // Skip header
                await reader.ReadLineAsync();

                string line;
                while ((line = await reader.ReadLineAsync()) != null)
                {
                    var parts = line.Split(',');
                    if (parts.Length >= 3 && long.TryParse(parts[0], out long frequency))
                    {
                        var channel = new Channel
                        {
                            Frequency = frequency,
                            Name = parts[1].Trim(),
                            Description = parts[2].Trim(),
                            Category = parts.Length > 3 ? parts[3].Trim() : null,
                            Tags = new Dictionary<string, string>(),
                            IsEnabled = true,
                            Priority = 0
                        };

                        channelList.Channels[frequency] = channel;
                    }
                }

                _channelLists[listName] = channelList;
                await SaveChannelListAsync(listName);

                _logger.LogInformation(
                    "Imported {Count} channels to list: {Name}",
                    channelList.Channels.Count, listName);

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error importing channels from CSV");
                return false;
            }
        }

        public async Task ExportToCsvAsync(string listName, string filePath)
        {
            if (!_channelLists.TryGetValue(listName, out var channelList))
                return;

            try
            {
                using var writer = new StreamWriter(filePath);
                await writer.WriteLineAsync("Frequency,Name,Description,Category,IsEnabled,Priority");

                foreach (var channel in channelList.Channels.Values)
                {
                    await writer.WriteLineAsync(
                        $"{channel.Frequency},{channel.Name},{channel.Description}," +
                        $"{channel.Category},{channel.IsEnabled},{channel.Priority}");
                }

                _logger.LogInformation(
                    "Exported {Count} channels from list: {Name}",
                    channelList.Channels.Count, listName);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error exporting channels to CSV");
            }
        }

        public IEnumerable<Channel> GetActiveChannels()
        {
            return _channelLists
                .Where(cl => cl.Value.IsActive)
                .SelectMany(cl => cl.Value.Channels.Values)
                .Where(c => c.IsEnabled)
                .OrderBy(c => c.Priority);
        }

        public void SetChannelActivity(long frequency, DateTime timestamp)
        {
            foreach (var list in _channelLists.Values)
            {
                if (list.Channels.TryGetValue(frequency, out var channel))
                {
                    channel.LastSeen = timestamp;
                }
            }
        }

        public void DeleteChannelList(string name)
        {
            if (_channelLists.Remove(name))
            {
                string filePath = Path.Combine(_channelListPath, $"{name}.json");
                if (File.Exists(filePath))
                {
                    File.Delete(filePath);
                }
                _logger.LogInformation("Deleted channel list: {Name}", name);
            }
        }

        public IReadOnlyDictionary<string, ChannelList> GetChannelLists()
        {
            return _channelLists;
        }

        public ChannelList GetChannelList(string name)
        {
            return _channelLists.TryGetValue(name, out var list) ? list : null;
        }
    }
}

