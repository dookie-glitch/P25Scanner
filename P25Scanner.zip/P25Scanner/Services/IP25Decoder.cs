using System;

namespace P25Scanner.Services
{
    /// <summary>
    /// Interface for the P25 Decoder service that handles decoding of P25 digital signals
    /// </summary>
    public interface IP25Decoder
    {
        /// <summary>
        /// Event that is raised when a talkgroup transmission is detected
        /// </summary>
        event EventHandler<TalkgroupEventArgs> TalkgroupDetected;

        /// <summary>
        /// Initialize the decoder
        /// </summary>
        void Initialize();

        /// <summary>
        /// Shut down the decoder and release resources
        /// </summary>
        void Shutdown();

        /// <summary>
        /// Process IQ data from the RTL-SDR receiver
        /// </summary>
        /// <param name="iqData">Complex IQ data samples</param>
        /// <param name="sampleRate">The sample rate of the IQ data</param>
        void ProcessIQData(System.Numerics.Complex[] iqData, int sampleRate);
    }

    /// <summary>
    /// Event arguments for talkgroup transmission events
    /// </summary>
    public class TalkgroupEventArgs : EventArgs
    {
        /// <summary>
        /// Gets the timestamp when the transmission was detected
        /// </summary>
        public DateTime Timestamp { get; }

        /// <summary>
        /// Gets the system identifier
        /// </summary>
        public int SystemId { get; }

        /// <summary>
        /// Gets the priority level of the transmission
        /// </summary>
        public int Priority { get; }

        /// <summary>
        /// Gets the encryption type used (if any)
        /// </summary>
        public string EncryptionType { get; }

        /// <summary>
        /// Gets the signal quality as a value between 0 and 100
        /// </summary>
        public int SignalQuality { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="TalkgroupEventArgs"/> class.
        /// </summary>
        /// <param name="timestamp">The timestamp when the transmission was detected</param>
        /// <param name="systemId">The system identifier</param>
        /// <param name="priority">The priority level</param>
        /// <param name="encryptionType">The encryption type</param>
        /// <param name="signalQuality">The signal quality</param>
        public TalkgroupEventArgs(DateTime timestamp, int systemId, int priority, string encryptionType, int signalQuality)
        {
            Timestamp = timestamp;
            SystemId = systemId;
            Priority = priority;
            EncryptionType = encryptionType;
            SignalQuality = signalQuality;
        }
    }
}

