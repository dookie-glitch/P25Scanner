using System.Windows;
using Microsoft.Win32;
using System.Windows.Forms;

namespace P25Scanner.Services
{
    public static class DialogService
    {
        public static MessageBoxResult ShowMessage(
            string message,
            string title = null,
            MessageBoxButton buttons = MessageBoxButton.OK,
            MessageBoxImage icon = MessageBoxImage.None)
        {
            return System.Windows.MessageBox.Show(
                message,
                title ?? "P25 Scanner",
                buttons,
                icon);
        }

        public static void ShowError(string title, string message)
        {
            ShowMessage(
                message,
                title,
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }

        public static void ShowWarning(string title, string message)
        {
            ShowMessage(
                message,
                title,
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
        }

        public static void ShowInfo(string title, string message)
        {
            ShowMessage(
                message,
                title,
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }

        public static string ShowOpenFileDialog(
            string filter = null,
            string title = null,
            string initialDirectory = null)
        {
            var dialog = new OpenFileDialog
            {
                Filter = filter ?? "All files (*.*)|*.*",
                Title = title ?? "Open File",
                InitialDirectory = initialDirectory
            };

            return dialog.ShowDialog() == true ? dialog.FileName : null;
        }

        public static string ShowSaveFileDialog(
            string filter = null,
            string title = null,
            string initialDirectory = null,
            string defaultFileName = null)
        {
            var dialog = new SaveFileDialog
            {
                Filter = filter ?? "All files (*.*)|*.*",
                Title = title ?? "Save File",
                InitialDirectory = initialDirectory,
                FileName = defaultFileName
            };

            return dialog.ShowDialog() == true ? dialog.FileName : null;
        }

        public static string ShowFolderBrowserDialog(
            string description = null,
            string selectedPath = null)
        {
            using var dialog = new FolderBrowserDialog
            {
                Description = description ?? "Select Folder",
                SelectedPath = selectedPath,
                ShowNewFolderButton = true
            };

            return dialog.ShowDialog() == DialogResult.OK ? dialog.SelectedPath : null;
        }
    }
}

