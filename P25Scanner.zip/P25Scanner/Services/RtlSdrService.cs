using System;
using System.Buffers;
using System.Collections.Concurrent;
using System.Numerics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using RTLSDR.NET;

namespace P25Scanner.Services
{
    /// <summary>
    /// Service for managing and operating RTL-SDR devices, providing IQ data streaming functionality.
    /// </summary>
    public class RtlSdrService : IDisposable
    {
        private readonly ILogger<RtlSdrService> _logger;
        private RTLSDRDevice _device;
        private CancellationTokenSource _streamCancellation;
        private readonly ConcurrentQueue<Complex[]> _sampleBufferQueue = new();
        private readonly SemaphoreSlim _deviceLock = new(1, 1);
        private bool _isStreaming;
        private bool _isDisposed;

        /// <summary>
        /// Gets a value indicating whether the RTL-SDR device is currently connected.
        /// </summary>
        public bool IsDeviceConnected => _device != null && !_isDisposed;

        /// <summary>
        /// Gets a value indicating whether the RTL-SDR device is currently streaming data.
        /// </summary>
        public bool IsStreaming => _isStreaming && IsDeviceConnected;

        /// <summary>
        /// Gets the current center frequency in Hz.
        /// </summary>
        public uint CurrentFrequency { get; private set; }

        /// <summary>
        /// Gets the current sample rate in Hz.
        /// </summary>
        public uint CurrentSampleRate { get; private set; }

        /// <summary>
        /// Gets the current gain setting in dB.
        /// </summary>
        public double CurrentGain { get; private set; }

        /// <summary>
        /// Gets the RTL-SDR device name if available.
        /// </summary>
        public string DeviceName { get; private set; }

        /// <summary>
        /// Event raised when a new batch of IQ data is available.
        /// </summary>
        public event EventHandler<IQDataEventArgs> IQDataAvailable;

        /// <summary>
        /// Event raised when the device connection status changes.
        /// </summary>
        public event EventHandler<DeviceStatusEventArgs> DeviceStatusChanged;

        /// <summary>
        /// Initializes a new instance of the <see cref="RtlSdrService"/> class.
        /// </summary>
        /// <param name="logger">The logger instance.</param>
        public RtlSdrService(ILogger<RtlSdrService> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _logger.LogInformation("RTL-SDR service initialized");
        }

        /// <summary>
        /// Initializes the RTL-SDR device with the specified index.
        /// </summary>
        /// <param name="deviceIndex">The index of the device to initialize. Default is 0.</param>
        /// <returns>A task representing the asynchronous initialization operation.</returns>
        public async Task<bool> InitializeDeviceAsync(int deviceIndex = 0)
        {
            await _deviceLock.WaitAsync();
            try
            {
                if (IsDeviceConnected)
                {
                    _logger.LogWarning("Device already initialized. Call DisconnectDevice first.");
                    return true;
                }

                _logger.LogInformation("Initializing RTL-SDR device with index {DeviceIndex}", deviceIndex);
                
                try
                {
                    // Get the count of available devices
                    int deviceCount = RTLSDRDevice.GetDeviceCount();
                    if (deviceCount <= 0)
                    {
                        _logger.LogError("No RTL-SDR devices found");
                        RaiseDeviceStatusChanged(false, "No devices found");
                        return false;
                    }
                    
                    if (deviceIndex >= deviceCount)
                    {
                        _logger.LogError("Device index {DeviceIndex} is out of range. Only {DeviceCount} devices available.", deviceIndex, deviceCount);
                        RaiseDeviceStatusChanged(false, "Device index out of range");
                        return false;
                    }

                    // Create and open the device
                    _device = new RTLSDRDevice(deviceIndex);
                    _device.Open();
                    
                    // Get device name
                    DeviceName = _device.Name;
                    _logger.LogInformation("Connected to RTL-SDR device: {DeviceName}", DeviceName);
                    
                    // Set default values
                    await SetSampleRateAsync(2048000); // 2.048 MHz default
                    await SetFrequencyAsync(100000000); // 100 MHz default
                    await SetGainAsync(42.0); // Default gain
                    
                    // Reset endpoint to ensure clean start
                    _device.ResetBuffer();
                    
                    RaiseDeviceStatusChanged(true, "Device connected successfully");
                    return true;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Failed to initialize RTL-SDR device");
                    _device?.Dispose();
                    _device = null;
                    RaiseDeviceStatusChanged(false, $"Initialization failed: {ex.Message}");
                    return false;
                }
            }
            finally
            {
                _deviceLock.Release();
            }
        }

        /// <summary>
        /// Disconnects and releases the RTL-SDR device.
        /// </summary>
        /// <returns>A task representing the asynchronous disconnection operation.</returns>
        public async Task DisconnectDeviceAsync()
        {
            await _deviceLock.WaitAsync();
            try
            {
                if (_isStreaming)
                {
                    await StopStreamingAsync();
                }

                if (_device != null)
                {
                    _logger.LogInformation("Disconnecting RTL-SDR device");
                    _device.Dispose();
                    _device = null;
                    DeviceName = null;
                    RaiseDeviceStatusChanged(false, "Device disconnected");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error disconnecting RTL-SDR device");
            }
            finally
            {
                _deviceLock.Release();
            }
        }

        /// <summary>
        /// Sets the RTL-SDR device's center frequency.
        /// </summary>
        /// <param name="frequencyHz">The center frequency in Hz.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        public async Task<bool> SetFrequencyAsync(uint frequencyHz)
        {
            await _deviceLock.WaitAsync();
            try
            {
                if (!IsDeviceConnected)
                {
                    _logger.LogWarning("Cannot set frequency: Device not connected");
                    return false;
                }

                _logger.LogInformation("Setting frequency to {Frequency} Hz", frequencyHz);
                _device.CenterFrequency = frequencyHz;
                CurrentFrequency = frequencyHz;
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to set frequency to {Frequency} Hz", frequencyHz);
                return false;
            }
            finally
            {
                _deviceLock.Release();
            }
        }

        /// <summary>
        /// Sets the RTL-SDR device's sample rate.
        /// </summary>
        /// <param name="sampleRateHz">The sample rate in Hz.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        public async Task<bool> SetSampleRateAsync(uint sampleRateHz)
        {
            await _deviceLock.WaitAsync();
            try
            {
                if (!IsDeviceConnected)
                {
                    _logger.LogWarning("Cannot set sample rate: Device not connected");
                    return false;
                }

                _logger.LogInformation("Setting sample rate to {SampleRate} Hz", sampleRateHz);
                _device.SampleRate = sampleRateHz;
                CurrentSampleRate = sampleRateHz;
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to set sample rate to {SampleRate} Hz", sampleRateHz);
                return false;
            }
            finally
            {
                _deviceLock.Release();
            }
        }

        /// <summary>
        /// Sets the RTL-SDR device's gain.
        /// </summary>
        /// <param name="gainDb">The gain value in dB.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        public async Task<bool> SetGainAsync(double gainDb)
        {
            await _deviceLock.WaitAsync();
            try
            {
                if (!IsDeviceConnected)
                {
                    _logger.LogWarning("Cannot set gain: Device not connected");
                    return false;
                }

                _logger.LogInformation("Setting gain to {Gain} dB", gainDb);
                
                // Set manual gain mode
                _device.AGCMode = false;
                
                // Find nearest valid gain
                var gains = _device.GetTunerGains();
                int nearestGain = FindNearestGain(gains, gainDb);
                _device.GainMode = true;  // Enable manual gain control
                _device.Gain = nearestGain;
                
                CurrentGain = nearestGain / 10.0; // Convert from tenths of dB to dB
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to set gain to {Gain} dB", gainDb);
                return false;
            }
            finally
            {
                _deviceLock.Release();
            }
        }

        /// <summary>
        /// Enables or disables the automatic gain control (AGC).
        /// </summary>
        /// <param name="enabled">True to enable AGC, false to disable.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        public async Task<bool> SetAgcModeAsync(bool enabled)
        {
            await _deviceLock.WaitAsync();
            try
            {
                if (!IsDeviceConnected)
                {
                    _logger.LogWarning("Cannot set AGC mode: Device not connected");
                    return false;
                }

                _logger.LogInformation("{Action} automatic gain control", enabled ? "Enabling" : "Disabling");
                _device.AGCMode = enabled;
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to set AGC mode to {Enabled}", enabled);
                return false;
            }
            finally
            {
                _deviceLock.Release();
            }
        }

        /// <summary>
        /// Starts streaming IQ data from the RTL-SDR device.
        /// </summary>
        /// <returns>A task representing the asynchronous streaming operation.</returns>
        public async Task<bool> StartStreamingAsync()
        {
            await _deviceLock.WaitAsync();
            try
            {
                if (!IsDeviceConnected)
                {
                    _logger.LogWarning("Cannot start streaming: Device not connected");
                    return false;
                }

                if (_isStreaming)
                {
                    _logger.LogWarning("Streaming is already active");
                    return true;
                }

                _logger.LogInformation("Starting IQ data streaming");
                
                // Clear any existing data
                while (_sampleBufferQueue.TryDequeue(out _)) { }
                
                // Initialize cancellation token
                _streamCancellation = new CancellationTokenSource();
                
                // Start the streaming task
                _isStreaming = true;
                Task.Run(() => StreamDataAsync(_streamCancellation.Token));
                
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to start streaming");
                _isStreaming = false;
                _streamCancellation?.Cancel();
                _streamCancellation?.Dispose();
                _streamCancellation = null;
                return false;
            }
            finally
            {
                _deviceLock.Release();
            }
        }

        /// <summary>
        /// Stops streaming IQ data from the RTL-SDR device.
        /// </summary>
        /// <returns>A task representing the asynchronous operation.</returns>
        public async Task<bool> StopStreamingAsync()
        {
            await _deviceLock.WaitAsync();
            try
            {
                if (!_isStreaming)
                {
                    _logger.LogWarning("Streaming is not active");
                    return true;
                }

                _logger.LogInformation("Stopping IQ data streaming");
                
                // Signal cancellation
                _streamCancellation?.Cancel();
                
                // Wait a bit for the streaming task to stop
                await Task.Delay(100);
                
                // Clean up
                _streamCancellation?.Dispose();
                _streamCancellation = null;
                _isStreaming = false;
                
                // Clear buffer queue
                while (_sampleBufferQueue.TryDequeue(out _)) { }
                
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error stopping streaming");
                return false;
            }
            finally
            {
                _deviceLock.Release();
            }
        }
        
        /// <summary>
        /// Main streaming method that reads IQ data from the device and raises events.
        /// </summary>
        /// </summary>
        /// <param name="cancellationToken">Token to monitor for cancellation requests.</param>
        private async Task StreamDataAsync(CancellationToken cancellationToken)
        {
            const int BufferSize = 16384; // Buffer size for IQ samples
            byte[] rawBuffer = new byte[BufferSize * 2]; // 2 bytes per sample (I and Q)
            
            try
            {
                // Reset endpoint buffer
                _device.ResetBuffer();
                
                while (!cancellationToken.IsCancellationRequested && IsDeviceConnected)
                {
                    try
                    {
                        // Read samples from device
                        int bytesRead = _device.ReadSync(rawBuffer, rawBuffer.Length);
                        
                        if (bytesRead > 0)
                        {
                            // Process the buffer
                            Complex[] iqData = ProcessRawBuffer(rawBuffer, bytesRead);
                            
                            // Raise event with the IQ data
                            IQDataAvailable?.Invoke(this, new IQDataEventArgs(iqData, CurrentFrequency, CurrentSampleRate));
                            
                            // Limit buffer queue size to prevent memory issues
                            while (_sampleBufferQueue.Count > 10)
                            {
                                _sampleBufferQueue.TryDequeue(out _);
                            }
                            
                            // Add to buffer queue for any async consumers
                            _sampleBufferQueue.Enqueue(iqData);
                        }
                        
                        // Small delay to prevent tight loop
                        await Task.Delay(1, cancellationToken);
                    }
                    catch (OperationCanceledException)
                    {
                        break;
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Err                        _logger.LogError(ex, "Error during streaming");
                        await Task.Delay(1000, cancellationToken); // Delay before retry
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Fatal error in streaming thread");
            }
            finally
            {
                _logger.LogInformation("Streaming thread has stopped");
            }
        }

        /// <summary>
        /// Processes raw bytes from RTL-SDR into Complex IQ samples.
        /// </summary>
        /// <param name="buffer">The raw byte buffer from the RTL-SDR device.</param>
        /// <param name="bytesRead">The number of bytes actually read.</param>
        /// <returns>An array of Complex samples representing the IQ data.</returns>
        private Complex[] ProcessRawBuffer(byte[] buffer, int bytesRead)
        {
            // RTL-SDR provides alternating I/Q samples as unsigned bytes (0-255)
            // We need to convert these to normalized [-1.0, 1.0] values in Complex format
            int sampleCount = bytesRead / 2; // Two bytes per complex sample (one I, one Q)
            var iqData = new Complex[sampleCount];

            for (int i = 0; i < sampleCount; i++)
            {
                // Convert from unsigned byte (0-255) to normalized float (-1.0 to 1.0)
                // RTL-SDR provides 8-bit unsigned samples (127.5 = 0)
                float real = (buffer[i * 2] - 127.5f) / 127.5f;
                float imag = (buffer[i * 2 + 1] - 127.5f) / 127.5f;
                
                iqData[i] = new Complex(real, imag);
            }

            return iqData;
        }

        /// <summary>
        /// Finds the nearest valid gain value from a list of available gain values.
        /// </summary>
        /// <param name="gains">Array of available gain values in tenths of dB.</param>
        /// <param name="targetGain">The desired gain in dB.</param>
        /// <returns>The nearest available gain value in tenths of dB.</returns>
        private int FindNearestGain(int[] gains, double targetGain)
        {
            if (gains == null || gains.Length == 0)
                return 0;

            // Convert target gain to tenths of dB to match RTL-SDR API format
            int targetGainTenthsDb = (int)(targetGain * 10);
            
            // Find the gain value closest to the requested one
            int nearestGain = gains[0];
            int minDifference = Math.Abs(gains[0] - targetGainTenthsDb);
            
            foreach (int gain in gains)
            {
                int difference = Math.Abs(gain - targetGainTenthsDb);
                if (difference < minDifference)
                {
                    minDifference = difference;
                    nearestGain = gain;
                }
            }
            
            _logger.LogDebug("Target gain: {TargetGain} dB, selected nearest available gain: {NearestGain} dB", 
                targetGain, nearestGain / 10.0);
                
            return nearestGain;
        }

        /// <summary>
        /// Raises the DeviceStatusChanged event with the specified status.
        /// </summary>
        /// <param name="isConnected">Whether the device is connected.</param>
        /// <param name="message">Status message.</param>
        private void RaiseDeviceStatusChanged(bool isConnected, string message)
        {
            DeviceStatusChanged?.Invoke(this, new DeviceStatusEventArgs(isConnected, message));
        }

        #region IDisposable Implementation

        /// <summary>
        /// Disposes the RTL-SDR service, releasing all managed and unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Releases the unmanaged resources used by the RTL-SDR service and optionally releases the managed resources.
        /// </summary>
        /// <param name="disposing">True to release both managed and unmanaged resources; false to release only unmanaged resources.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!_isDisposed)
            {
                if (disposing)
                {
                    // Dispose managed resources
                    _streamCancellation?.Cancel();
                    Task.Run(async () => await DisconnectDeviceAsync()).Wait();
                    _streamCancellation?.Dispose();
                    _deviceLock?.Dispose();
                }

                // Clean up unmanaged resources
                _device?.Dispose();
                _device = null;
                _isDisposed = true;
            }
        }

        /// <summary>
        /// Finalizer to ensure unmanaged resources are cleaned up if Dispose is not called.
        /// </summary>
        ~RtlSdrService()
        {
            Dispose(false);
        }

        #endregion

        #region Event Argument Classes

        /// <summary>
        /// Provides data for the IQDataAvailable event.
        /// </summary>
        public class IQDataEventArgs : EventArgs
        {
            /// <summary>
            /// Gets the array of complex IQ samples.
            /// </summary>
            public Complex[] IQData { get; }
            
            /// <summary>
            /// Gets the center frequency in Hz for this data.
            /// </summary>
            public uint CenterFrequency { get; }
            
            /// <summary>
            /// Gets the sample rate in Hz for this data.
            /// </summary>
            public uint SampleRate { get; }
            
            /// <summary>
            /// Gets the timestamp when this data was received.
            /// </summary>
            public DateTime Timestamp { get; }

            /// <summary>
            /// Initializes a new instance of the <see cref="IQDataEventArgs"/> class.
            /// </summary>
            /// <param name="iqData">The array of complex IQ samples.</param>
            /// <param name="centerFrequency">The center frequency in Hz.</param>
            /// <param name="sampleRate">The sample rate in Hz.</param>
            public IQDataEventArgs(Complex[] iqData, uint centerFrequency, uint sampleRate)
            {
                IQData = iqData ?? throw new ArgumentNullException(nameof(iqData));
                CenterFrequency = centerFrequency;
                SampleRate = sampleRate;
                Timestamp = DateTime.UtcNow;
            }
        }
        
        /// <summary>
        /// Provides data for the DeviceStatusChanged event.
        /// </summary>
        public class DeviceStatusEventArgs : EventArgs
        {
            /// <summary>
            /// Gets a value indicating whether the device is connected.
            /// </summary>
            public bool IsConnected { get; }
            
            /// <summary>
            /// Gets a value indicating whether the device is receiving data.
            /// </summary>
            public bool IsReceiving { get; }
            
            /// <summary>
            /// Gets information about the device.
            /// </summary>
            public string DeviceName { get; }
            
            /// <summary>
            /// Gets a message describing the status change.
            /// </summary>
            public string Message { get; }

            /// <summary>
            /// Initializes a new instance of the <see cref="DeviceStatusEventArgs"/> class.
            /// </summary>
            /// <param name="
retry
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Fatal error in streaming thread");
            }
            finally
            {
                _logger.LogInformation("Streaming thread has stopped");
            }
        }

using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using P25Scanner.Services;

namespace P25Scanner.Services
{
    public class RtlSdrService : IDisposable
    {
        private readonly IP25Decoder _p25Decoder;
        private IntPtr _deviceHandle;
        private bool _isRunning;
        private bool _isDisposed;
        private CancellationTokenSource _cancellationTokenSource;
        private Thread _sampleThread;
        private readonly object _lockObject = new object();
        private const int DEFAULT_BUFFER_SIZE = 16 * 16384;
        private readonly byte[] _buffer;
        
        public event EventHandler<IQDataReceivedEventArgs> IQDataReceived;
        public event EventHandler<DeviceErrorEventArgs> DeviceError;
        public event EventHandler<DeviceChangedEventArgs> DeviceChanged;
        
        public int SampleRate { get; private set; } = 1024000;
        public int Frequency { get; private set; } = 162000000;
        public int Gain { get; private set; } = 420; // Typically in tenths of dB
        public bool IsRunning => _isRunning;
        public List<DeviceInfo> AvailableDevices { get; private set; } = new List<DeviceInfo>();
        public DeviceInfo CurrentDevice { get; private set; }

        public RtlSdrService(IP25Decoder p25Decoder)
        {
            _p25Decoder = p25Decoder ?? throw new ArgumentNullException(nameof(p25Decoder));
            _buffer = new byte[DEFAULT_BUFFER_SIZE];
            
            // Initialize the RTL-SDR library and enumerate devices
            EnumerateDevices();
        }

        public bool Start(int deviceIndex = 0, int frequency = 162000000, int sampleRate = 1024000, int gain = 420)
        {
            if (_isRunning)
                return false;

            try
            {
                lock (_lockObject)
                {
                    // Open the RTL-SDR device
                    // Note: This is a placeholder for the actual RTL-SDR API calls
                    _deviceHandle = OpenDevice(deviceIndex);
                    
                    if (_deviceHandle == IntPtr.Zero)
                    {
                        OnDeviceError(new DeviceErrorEventArgs("Failed to open RTL-SDR device"));
                        return false;
                    }

                    // Set device parameters
                    SetFrequency(frequency);
                    SetSampleRate(sampleRate);
                    SetGain(gain);
                    
                    // Start the sampling thread
                    _cancellationTokenSource = new CancellationTokenSource();
                    _sampleThread = new Thread(SamplingThreadProc);
                    _sampleThread.Start(_cancellationTokenSource.Token);
                    
                    _isRunning = true;
                    
                    // Update the current device
                    if (deviceIndex < AvailableDevices.Count)
                    {
                        CurrentDevice = AvailableDevices[deviceIndex];
                        OnDeviceChanged(new DeviceChangedEventArgs(CurrentDevice));
                    }
                    
                    return true;
                }
            }
            catch (Exception ex)
            {
                OnDeviceError(new DeviceErrorEventArgs($"Error starting RTL-SDR: {ex.Message}"));
                CleanupDevice();
                return false;
            }
        }

        public bool Stop()
        {
            if (!_isRunning)
                return true;

            try
            {
                lock (_lockObject)
                {
                    _cancellationTokenSource?.Cancel();
                    _sampleThread?.Join(1000);
                    CleanupDevice();
                    _isRunning = false;
                    return true;
                }
            }
            catch (Exception ex)
            {
                OnDeviceError(new DeviceErrorEventArgs($"Error stopping RTL-SDR: {ex.Message}"));
                return false;
            }
        }

        public void SetFrequency(int frequency)
        {
            if (frequency < 24000000 || frequency > 1766000000)
                throw new ArgumentOutOfRangeException(nameof(frequency), "Frequency must be between 24 MHz and 1766 MHz");

            // Call the RTL-SDR API to set frequency
            // This is a placeholder for the actual implementation
            Frequency = frequency;
        }

        public void SetSampleRate(int sampleRate)
        {
            if (sampleRate < 225001 || sampleRate > 3200000)
                throw new ArgumentOutOfRangeException(nameof(sampleRate), "Sample rate must be between 225001 and 3.2 MHz");

            // Call the RTL-SDR API to set sample rate
            // This is a placeholder for the actual implementation
            SampleRate = sampleRate;
        }

        public void SetGain(int gain)
        {
            // Call the RTL-SDR API to set gain
            // This is a placeholder for the actual implementation
            Gain = gain;
        }

        public void EnumerateDevices()
        {
            AvailableDevices.Clear();
            
            // This is a placeholder for the actual implementation
            // Typically, you would call the RTL-SDR API to get a list of connected devices
            int deviceCount = GetDeviceCount();
            
            for (int i = 0; i < deviceCount; i++)
            {
                string manufacturerName = GetDeviceManufacturer(i);
                string productName = GetDeviceProductName(i);
                string serialNumber = GetDeviceSerialNumber(i);
                
                AvailableDevices.Add(new DeviceInfo
                {
                    Index = i,
                    ManufacturerName = manufacturerName,
                    ProductName = productName,
                    SerialNumber = serialNumber
                });
            }
        }

        private void SamplingThreadProc(object obj)
        {
            CancellationToken cancellationToken = (CancellationToken)obj;
            
            try
            {
                while (!cancellationToken.IsCancellationRequested)
                {
                    // Read samples from the RTL-SDR device
                    // This is a placeholder for the actual implementation
                    int samplesRead = ReadSamples(_buffer, DEFAULT_BUFFER_SIZE);
                    
                    if (samplesRead > 0)
                    {
                        ProcessIQData(_buffer, samplesRead);
                    }
                    else
                    {
                        // Error reading samples or device disconnected
                        OnDeviceError(new DeviceErrorEventArgs("Error reading samples from RTL-SDR device"));
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                OnDeviceError(new DeviceErrorEventArgs($"Sampling thread error: {ex.Message}"));
            }
        }

        private void ProcessIQData(byte[] buffer, int bytesRead)
        {
            // Calculate how many complex samples we have (2 bytes per component, 2 components per sample)
            int sampleCount = bytesRead / 2;
            
            // Create arrays for I and Q samples
            float[] iSamples = new float[sampleCount / 2];
            float[] qSamples = new float[sampleCount / 2];
            Complex[] complexSamples = new Complex[sampleCount / 2];
            
            // Convert 8-bit unsigned samples to normalized float samples
            for (int i = 0, j = 0; i < sampleCount; i += 2, j++)
            {
                // Convert from unsigned byte (0-255) to normalized float (-1.0 to 1.0)
                // RTL-SDR provides 8-bit unsigned samples (127 = 0)
                float iSample = (buffer[i] - 127.5f) / 127.5f;
                float qSample = (buffer[i + 1] - 127.5f) / 127.5f;
                
                iSamples[j] = iSample;
                qSamples[j] = qSample;
                complexSamples[j] = new Complex(iSample, qSample);
            }
            
            // Send the samples to the P25 decoder
            _p25Decoder.ProcessSamples(iSamples, qSamples);
            
            // Notify subscribers
            OnIQDataReceived(new IQDataReceivedEventArgs
            {
                ISamples = iSamples,
                QSamples = qSamples,
                ComplexSamples = complexSamples,
                SampleRate = SampleRate,
                CenterFrequency = Frequency
            });
        }

        private void CleanupDevice()
        {
            // Close the RTL-SDR device
            // This is a placeholder for the actual implementation
            if (_deviceHandle != IntPtr.Zero)
            {
                CloseDevice(_deviceHandle);
                _deviceHandle = IntPtr.Zero;
            }
        }

        #region Event Methods
        protected virtual void OnIQDataReceived(IQDataReceivedEventArgs e)
        {
            IQDataReceived?.Invoke(this, e);
        }

        protected virtual void OnDeviceError(DeviceErrorEventArgs e)
        {
            DeviceError?.Invoke(this, e);
        }

        protected virtual void OnDeviceChanged(DeviceChangedEventArgs e)
        {
            DeviceChanged?.Invoke(this, e);
        }
        #endregion

        #region RTL-SDR API Placeholders
        // These methods are placeholders for the actual RTL-SDR library calls
        // You would replace these with actual P/Invoke calls to the RTL-SDR library
        
        private IntPtr OpenDevice(int index)
        {
            // Placeholder for rtlsdr_open
            return IntPtr.Zero;
        }
        
        private void CloseDevice(IntPtr deviceHandle)
        {
            // Placeholder for rtlsdr_close
        }
        
        private int GetDeviceCount()
        {
            // Placeholder for rtlsdr_get_device_count
            return 1; // Return 1 for testing
        }
        
        private string GetDeviceManufacturer(int index)
        {
            // Placeholder for rtlsdr_get_device_usb_strings
            return "RTL-SDR Manufacturer";
        }
        
        private string GetDeviceProductName(int index)
        {
            // Placeholder for rtlsdr_get_device_usb_strings
            return "RTL-SDR Receiver";
        }
        
        private string GetDeviceSerialNumber(int index)
        {
            // Placeholder for rtlsdr_get_device_usb_strings
            return "00000001";
        }
        
        private int ReadSamples(byte[] buffer, int length)
        {
            // Placeholder for rtlsdr_read_sync
            return 0;
        }
        #endregion

        #region IDisposable Implementation
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (_isDisposed)
                return;

            if (disposing)
            {
                // Free managed resources
                Stop();
                _cancellationTokenSource?.Dispose();
            }

            // Free unmanaged resources
            CleanupDevice();
            _isDisposed = true;
        }

        ~RtlSdrService()
        {
            Dispose(false);
        }
        #endregion
    }

    #region Event Argument Classes
    public class IQDataReceivedEventArgs : EventArgs
    {
        public float[] ISamples { get; set; }
        public float[] QSamples { get; set; }
        public Complex[] ComplexSamples { get; set; }
        public int SampleRate { get; set; }
        public int CenterFrequency { get; set; }
    }

    public class DeviceErrorEventArgs : EventArgs
    {
        public string ErrorMessage { get; }
        public Exception Exception { get; }

        public DeviceErrorEventArgs(string errorMessage, Exception exception = null)
        {
            ErrorMessage = errorMessage;
            Exception = exception;
        }
    }

    public class DeviceChangedEventArgs : EventArgs
    {
        public DeviceInfo Device { get; }

        public DeviceChangedEventArgs(DeviceInfo device)
        {
            Device = device;
        }
    }

    public class DeviceInfo
    {
        public int Index { get; set; }
        public string ManufacturerName { get; set; }
        public string ProductName { get; set; }
        public string SerialNumber { get; set; }
        public string DisplayName => $"{ProductName} ({SerialNumber})";

        public override string ToString()
        {
            return DisplayName;
        }
    }
    #endregion
}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Numerics;
using System.Runtime.InteropServices;
using Microsoft.Extensions.Logging;
using P25Scanner.Models;
using P25Scanner.Services;
using RtlSdr.Net;

namespace P25Scanner.Services
{
    public class RtlSdrService : IDisposable
    {
        private readonly ILogger<RtlSdrService> _logger;
        private readonly P25Decoder _p25Decoder;
        
        private RtlSdrDevice _device;
        private bool _isRunning;
        private CancellationTokenSource _cancellationTokenSource;
        
        // Device configuration
        private int _sampleRate = 1024000; // 1.024 MSPS is common for P25
        private int _frequency = 856000000; // Default to 856 MHz
        private int _gain = 420; // Auto gain
        private int _ppm = 0; // Frequency correction
        private int _bufferSize = 16 * 16384; // Buffer size for IQ data
        
        // Events
        public event EventHandler<IQDataEventArgs> IQDataReceived;
        public event EventHandler<DeviceStatusEventArgs> DeviceStatusChanged;
        
        public RtlSdrService(ILogger<RtlSdrService> logger, P25Decoder p25Decoder)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _p25Decoder = p25Decoder ?? throw new ArgumentNullException(nameof(p25Decoder));
        }
        
        #region Properties
        
        public bool IsRunning => _isRunning;
        
        public int SampleRate
        {
            get => _sampleRate;
            set
            {
                if (_sampleRate != value && value >= 225001 && value <= 3200000)
                {
                    _sampleRate = value;
                    if (_device != null && _device.IsOpen)
                    {
                        _device.SampleRate = (uint)_sampleRate;
                    }
                }
            }
        }
        
        public int Frequency
        {
            get => _frequency;
            set
            {
                if (_frequency != value && value >= 24000000 && value <= 1766000000)
                {
                    _frequency = value;
                    if (_device != null && _device.IsOpen)
                    {
                        _device.CenterFrequency = (uint)_frequency;
                    }
                }
            }
        }
        
        public int Gain
        {
            get => _gain;
            set
            {
                if (_gain != value)
                {
                    _gain = value;
                    if (_device != null && _device.IsOpen)
                    {
                        // A value of 0 means auto gain
                        if (value == 0)
                        {
                            _device.UseRtlAGC = true;
                            _device.UseTunerAGC = true;
                        }
                        else
                        {
                            _device.UseRtlAGC = false;
                            _device.UseTunerAGC = false;
                            _device.TunerGain = value;
                        }
                    }
                }
            }
        }
        
        public int PPM
        {
            get => _ppm;
            set
            {
                if (_ppm != value)
                {
                    _ppm = value;
                    if (_device != null && _device.IsOpen)
                    {
                        _device.FrequencyCorrection = value;
                    }
                }
            }
        }
        
        #endregion
        
        #region Device Management
        
        /// <summary>
        /// Gets a list of available RTL-SDR devices
        /// </summary>
        /// <returns>List of device information</returns>
        public List<DeviceInfo> GetAvailableDevices()
        {
            var devices = new List<DeviceInfo>();
            
            try
            {
                uint deviceCount = RtlSdrDevice.GetDeviceCount();
                
                for (uint i = 0; i < deviceCount; i++)
                {
                    string name = RtlSdrDevice.GetDeviceName(i);
                    string manufacturer = string.Empty;
                    string product = string.Empty;
                    string serial = string.Empty;
                    
                    try
                    {
                        RtlSdrDevice.GetDeviceUsbStrings(i, out manufacturer, out product, out serial);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Failed to get USB strings for device {Index}", i);
                    }
                    
                    devices.Add(new DeviceInfo
                    {
                        Index = (int)i,
                        Name = name,
                        Manufacturer = manufacturer,
                        Product = product,
                        SerialNumber = serial
                    });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error enumerating RTL-SDR devices");
            }
            
            return devices;
        }
        
        /// <summary>
        /// Initializes the RTL-SDR device with the specified index
        /// </summary>
        /// <param name="deviceIndex">Index of the device to initialize</param>
        /// <returns>True if initialization was successful</returns>
        public bool InitializeDevice(int deviceIndex)
        {
            try
            {
                // Close any existing device first
                CloseDevice();
                
                _device = new RtlSdrDevice(deviceIndex);
                _device.Open();
                
                // Configure device
                _device.SampleRate = (uint)_sampleRate;
                _device.CenterFrequency = (uint)_frequency;
                _device.FrequencyCorrection = _ppm;
                
                // Set gain mode
                if (_gain == 0)
                {
                    _device.UseRtlAGC = true;
                    _device.UseTunerAGC = true;
                }
                else
                {
                    _device.UseRtlAGC = false;
                    _device.UseTunerAGC = false;
                    _device.TunerGain = _gain;
                }
                
                // Get device information
                string manufacturer = string.Empty;
                string product = string.Empty;
                string serial = string.Empty;
                
                try
                {
                    RtlSdrDevice.GetDeviceUsbStrings((uint)deviceIndex, out manufacturer, out product, out serial);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Failed to get USB strings for device {Index}", deviceIndex);
                }
                
                var deviceInfo = new DeviceInfo
                {
                    Index = deviceIndex,
                    Name = RtlSdrDevice.GetDeviceName((uint)deviceIndex),
                    Manufacturer = manufacturer,
                    Product = product,
                    SerialNumber = serial,
                    IsConnected = true
                };
                
                DeviceStatusChanged?.Invoke(this, new DeviceStatusEventArgs
                {
                    IsConnected = true,
                    DeviceInfo = deviceInfo,
                    Message = "Device initialized successfully"
                });
                
                _logger.LogInformation("RTL-SDR device initialized successfully. Index: {Index}, Name: {Name}", 
                    deviceIndex, deviceInfo.Name);
                
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error initializing RTL-SDR device with index {Index}", deviceIndex);
                
                DeviceStatusChanged?.Invoke(this, new DeviceStatusEventArgs
                {
                    IsConnected = false,
                    Message = $"Failed to initialize device: {ex.Message}"
                });
                
                return false;
            }
        }
        
        /// <summary>
        /// Closes the currently open device
        /// </summary>
        public void CloseDevice()
        {
            StopReceiving();
            
            if (_device != null)
            {
                try
                {
                    if (_device.IsOpen)
                    {
                        _device.Close();
                    }
                    
                    _device.Dispose();
                    _device = null;
                    
                    DeviceStatusChanged?.Invoke(this, new DeviceStatusEventArgs
                    {
                        IsConnected = false,
                        Message = "Device disconnected"
                    });
                    
                    _logger.LogInformation("RTL-SDR device closed");
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error closing RTL-SDR device");
                }
            }
        }
        
        #endregion
        
        #region IQ Data Processing
        
        /// <summary>
        /// Starts receiving IQ data from the device
        /// </summary>
        /// <returns>True if receiving started successfully</returns>
        public bool StartReceiving()
        {
            if (_device == null || !_device.IsOpen)
            {
                _logger.LogWarning("Cannot start receiving: No device initialized or device not open");
                return false;
            }
            
            if (_isRunning)
            {
                _logger.LogWarning("Already receiving data");
                return true;
            }
            
            try
            {
                _cancellationTokenSource = new CancellationTokenSource();
                _isRunning = true;
                
                // Start the async read task
                Task.Run(() => ReceiveDataAsync(_cancellationTokenSource.Token));
                
                _logger.LogInformation("Started receiving data from RTL-SDR device");
                
                DeviceStatusChanged?.Invoke(this, new DeviceStatusEventArgs
                {
                    IsConnected = true,
                    IsReceiving = true,
                    Message = "Started receiving data"
                });
                
                return true;
            }
            catch (Exception ex)
            {
                _isRunning = false;
                _logger.LogError(ex, "Error starting RTL-SDR data reception");
                
                DeviceStatusChanged?.Invoke(this, new DeviceStatusEventArgs
                {
                    IsConnected = true,
                    IsReceiving = false,
                    Message = $"Failed to start receiving: {ex.Message}"
                });
                
                return false;
            }
        }
        
        /// <summary>
        /// Stops receiving IQ data
        /// </summary>
        public void StopReceiving()
        {
            if (!_isRunning)
            {
                return;
            }
            
            try
            {
                _cancellationTokenSource?.Cancel();
                _isRunning = false;
                
                _logger.LogInformation("Stopped receiving data from RTL-SDR device");
                
                DeviceStatusChanged?.Invoke(this, new DeviceStatusEventArgs
                {
                    IsConnected = _device != null && _device.IsOpen,
                    IsReceiving = false,
                    Message = "Stopped receiving data"
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error stopping RTL-SDR data reception");
            }
        }
        
        /// <summary>
        /// Asynchronously receives data from the RTL-SDR device
        /// </summary>
        private async Task ReceiveDataAsync(CancellationToken cancellationToken)
        {
            byte[] buffer = new byte[_bufferSize];
            
            // Pre-allocate the complex buffer to avoid constant reallocation
            Complex[] iqData = new Complex[_bufferSize / 2];
            
            while (!cancellationToken.IsCancellationRequested)
            {
                try
                {
                    if (_device == null || !_device.IsOpen)
                    {
                        _logger.LogWarning("Device disconnected during reception");
                        break;
                    }
                    
                    // Read asynchronously from the device
                    int bytesRead = await Task.Run(() => 
                    {
                        return _device.ReadAsync(buffer, 0, buffer.Length);
                    }, cancellationToken);
                    
                    if (bytesRead > 0)
                    {
                        // Convert bytes to IQ samples (complex numbers)
                        ConvertToIQ(buffer, bytesRead, iqData);
                        
                        // Send IQ data to P25 decoder for processing
                        ProcessIQData(iqData, bytesRead / 2);
                    }
                }
                catch (OperationCanceledException)
                {
                    // Normal cancellation, just exit the loop
                    break;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error reading data from RTL-SDR device");
                    
                    // Pause briefly before retrying to avoid tight error loops
                    try
                    {
                        await Task.Delay(1000, cancellationToken);
                    }
                    catch (OperationCanceledException)
                    {
                        break;
                    }
                    
                    // If we're still connected, continue; otherwise break
                    if (_device == null || !_device.IsOpen)
                    {
                        break;
                    }
                }
            }
            
            _isRunning = false;
            
            // Notify that we're no longer receiving
            DeviceStatusChanged?.Invoke(this, new DeviceStatusEventArgs
            {
                IsConnected = _device != null && _device.IsOpen,
                IsReceiving = false,
                Message = "Receiving stopped"
            });
        }
        
        /// <summary>
        /// Converts raw bytes from RTL-SDR to IQ data (complex numbers)
        /// </summary>
        private void ConvertToIQ(byte[] buffer, int bytesRead, Complex[] iqData)
        {
            // RTL-SDR provides data as interleaved unsigned 8-bit I/Q samples
            // Convert to normalized complex numbers
            int samples = Math.Min(bytesRead / 2, iqData.Length);
            
            for (int i = 0; i < samples; i++)
            {
                // Convert 8-bit unsigned (0-255) to float (-1 to 1)
                float real = (buffer[i * 2] - 127.5f) / 127.5f;
                float imag = (buffer[i * 2 + 1] - 127.5f) / 127.5f;
                
                iqData[i] = new Complex(real, imag);
            }
        }
        
        /// <summary>
        /// Processes the IQ data, sends it to P25Decoder, and raises events
        /// </summary>
        private void ProcessIQData(Complex[] iqData, int sampleCount)
        {
            // Create a copy of the data to avoid modification issues
            var processedSamples = iqData.Take(sampleCount).ToArray();
            

