using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Text.Json;
using System.IO;
using Microsoft.Extensions.Logging;
using P25Scanner.Configuration;

namespace P25Scanner.Services
{
    public class StatisticsTracker : IDisposable
    {
        private readonly ILogger<StatisticsTracker> _logger;
        private readonly AppConfig _config;
        private readonly string _statsPath;
        private readonly ConcurrentDictionary<long, FrequencyStats> _frequencyStats;
        private readonly ConcurrentDictionary<int, TalkgroupStats> _talkgroupStats;
        private DateTime _startTime;
        private bool _isDisposed;

        public class FrequencyStats
        {
            public long Frequency { get; set; }
            public int HitCount { get; set; }
            public float AverageSignalQuality { get; set; }
            public TimeSpan TotalActiveTime { get; set; }
            public DateTime LastActive { get; set; }
            public Dictionary<int, int> TalkgroupHits { get; set; }
            private float _signalQualitySum;
            private int _signalQualitySamples;

            public FrequencyStats()
            {
                TalkgroupHits = new Dictionary<int, int>();
            }

            public void AddSignalQuality(float quality)
            {
                _signalQualitySum += quality;
                _signalQualitySamples++;
                AverageSignalQuality = _signalQualitySum / _signalQualitySamples;
            }
        }

        public class TalkgroupStats
        {
            public int TalkgroupId { get; set; }
            public int TransmissionCount { get; set; }
            public TimeSpan TotalTransmissionTime { get; set; }
            public DateTime LastTransmission { get; set; }
            public Dictionary<long, int> FrequencyHits { get; set; }
            public Dictionary<string, int> SourceIds { get; set; }

            public TalkgroupStats()
            {
                FrequencyHits = new Dictionary<long, int>();
                SourceIds = new Dictionary<string, int>();
            }
        }

        public class SystemStats
        {
            public DateTime StartTime { get; set; }
            public TimeSpan TotalRunTime { get; set; }
            public int TotalTransmissions { get; set; }
            public int UniqueFrequencies { get; set; }
            public int UniqueTalkgroups { get; set; }
            public float AverageSignalQuality { get; set; }
            public Dictionary<string, int> ErrorCounts { get; set; }

            public SystemStats()
            {
                ErrorCounts = new Dictionary<string, int>();
            }
        }

        public StatisticsTracker(ILogger<StatisticsTracker> logger, AppConfig config)
        {
            _logger = logger;
            _config = config;
            _statsPath = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "Statistics");
            _frequencyStats = new ConcurrentDictionary<long, FrequencyStats>();
            _talkgroupStats = new ConcurrentDictionary<int, TalkgroupStats>();
            _startTime = DateTime.UtcNow;

            if (!Directory.Exists(_statsPath))
            {
                Directory.CreateDirectory(_statsPath);
            }
        }

        public void RecordFrequencyActivity(
            long frequency,
            float signalQuality,
            int? talkgroupId = null)
        {
            var stats = _frequencyStats.GetOrAdd(frequency, f => new FrequencyStats
            {
                Frequency = f,
                LastActive = DateTime.UtcNow
            });

            stats.HitCount++;
            stats.AddSignalQuality(signalQuality);
            stats.LastActive = DateTime.UtcNow;

            if (talkgroupId.HasValue)
            {
                stats.TalkgroupHits.TryGetValue(talkgroupId.Value, out int hits);
                stats.TalkgroupHits[talkgroupId.Value] = hits + 1;
            }
        }

        public void RecordTalkgroupActivity(
            int talkgroupId,
            long frequency,
            TimeSpan duration,
            string sourceId = null)
        {
            var stats = _talkgroupStats.GetOrAdd(talkgroupId, id => new TalkgroupStats
            {
                TalkgroupId = id,
                LastTransmission = DateTime.UtcNow
            });

            stats.TransmissionCount++;
            stats.TotalTransmissionTime += duration;
            stats.LastTransmission = DateTime.UtcNow;

            stats.FrequencyHits.TryGetValue(frequency, out int hits);
            stats.FrequencyHits[frequency] = hits + 1;

            if (!string.IsNullOrEmpty(sourceId))
            {
                stats.SourceIds.TryGetValue(sourceId, out int srcHits);
                stats.SourceIds[sourceId] = srcHits + 1;
            }
        }

        public SystemStats GetSystemStats()
        {
            var stats = new SystemStats
            {
                StartTime = _startTime,
                TotalRunTime = DateTime.UtcNow - _startTime,
                UniqueFrequencies = _frequencyStats.Count,
                UniqueTalkgroups = _talkgroupStats.Count
            };

            float totalQuality = 0;
            int totalTransmissions = 0;

            foreach (var freq in _frequencyStats.Values)
            {
                totalQuality += freq.AverageSignalQuality * freq.HitCount;
                totalTransmissions += freq.HitCount;
            }

            stats.TotalTransmissions = totalTransmissions;
            if (totalTransmissions > 0)
            {
                stats.AverageSignalQuality = totalQuality / totalTransmissions;
            }

            return stats;
        }

        public async Task SaveStatisticsAsync()
        {
            try
            {
                var systemStats = GetSystemStats();
                var data = new
                {
                    System = systemStats,
                    Frequencies = _frequencyStats,
                    Talkgroups = _talkgroupStats
                };

                string fileName = $"stats_{DateTime.UtcNow:yyyyMMdd_HHmmss}.json";
                string filePath = Path.Combine(_statsPath, fileName);

                var options = new JsonSerializerOptions
                {
                    WriteIndented = true
                };

                await File.WriteAllTextAsync(
                    filePath,
                    JsonSerializer.Serialize(data, options));

                _logger.LogInformation("Statistics saved to {FilePath}", filePath);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error saving statistics");
            }
        }

        public async Task LoadStatisticsAsync(string filePath)
        {
            try
            {
                var json = await File.ReadAllTextAsync(filePath);
                var data = JsonSerializer.Deserialize<dynamic>(json);

                // Reset current stats
                _frequencyStats.Clear();
                _talkgroupStats.Clear();

                // Load saved stats
                foreach (var freq in data.Frequencies.EnumerateObject())
                {
                    _frequencyStats[long.Parse(freq.Name)] = 
                        freq.Value.Deserialize<FrequencyStats>();
                }

                foreach (var tg in data.Talkgroups.EnumerateObject())
                {
                    _talkgroupStats[int.Parse(tg.Name)] = 
                        tg.Value.Deserialize<TalkgroupStats>();
                }

                _logger.LogInformation("Statistics loaded from {FilePath}", filePath);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading statistics");
            }
        }

        public FrequencyStats GetFrequencyStats(long frequency)
        {
            return _frequencyStats.TryGetValue(frequency, out var stats)
                ? stats
                : null;
        }

        public TalkgroupStats GetTalkgroupStats(int talkgroupId)
        {
            return _talkgroupStats.TryGetValue(talkgroupId, out var stats)
                ? stats
                : null;
        }

        public void Reset()
        {
            _frequencyStats.Clear();
            _talkgroupStats.Clear();
            _startTime = DateTime.UtcNow;
        }

        public void Dispose()
        {
            if (!_isDisposed)
            {
                SaveStatisticsAsync().Wait();
                _isDisposed = true;
            }
        }
    }
}

