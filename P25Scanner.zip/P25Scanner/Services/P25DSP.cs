using System;
using System.Numerics;

namespace P25Scanner.Services
{
    /// <summary>
    /// Digital Signal Processing functions for P25 decoding
    /// </summary>
    internal static class P25DSP
    {
        // Constants for P25 signal processing
        private const int P25_SYMBOL_RATE = 4800;
        private const double PULSE_SHAPING_ALPHA = 0.2;  // Root raised cosine filter roll-off factor
        private const int SYNC_PATTERN_LENGTH = 48;
        private const int RRC_FILTER_LENGTH = 81;  // Filter length for RRC (should be odd)

        /// <summary>
        /// Applies root raised cosine filtering to input samples
        /// </summary>
        public static Complex[] ApplyRRCFilter(Complex[] input, double sampleRate)
        {
            double samplesPerSymbol = sampleRate / P25_SYMBOL_RATE;
            var coeffs = GenerateRRCCoefficients(samplesPerSymbol);
            var output = new Complex[input.Length];

            // Apply filter using convolution
            for (int i = 0; i < input.Length; i++)
            {
                Complex sum = Complex.Zero;
                for (int j = 0; j < coeffs.Length; j++)
                {
                    if (i - j >= 0 && i - j < input.Length)
                    {
                        sum += input[i - j] * coeffs[j];
                    }
                }
                output[i] = sum;
            }

            return output;
        }

        /// <summary>
        /// Generates root raised cosine filter coefficients
        /// </summary>
        private static double[] GenerateRRCCoefficients(double samplesPerSymbol)
        {
            int halfLength = RRC_FILTER_LENGTH / 2;
            var coeffs = new double[RRC_FILTER_LENGTH];

            for (int i = -halfLength; i <= halfLength; i++)
            {
                double t = i / samplesPerSymbol;
                coeffs[i + halfLength] = ComputeRRCValue(t, PULSE_SHAPING_ALPHA);
            }

            // Normalize coefficients
            double sum = coeffs.Sum();
            for (int i = 0; i < coeffs.Length; i++)
            {
                coeffs[i] /= sum;
            }

            return coeffs;
        }

        /// <summary>
        /// Computes RRC filter value at given time point
        /// </summary>
        private static double ComputeRRCValue(double t, double alpha)
        {
            if (Math.Abs(t) < double.Epsilon)
            {
                return (1.0 - alpha + (4.0 * alpha / Math.PI));
            }

            double harmonicTime = Math.PI * t;
            double squaredTime = 4.0 * alpha * t;

            if (Math.Abs(Math.Abs(t) - 1.0 / (4.0 * alpha)) < double.Epsilon)
            {
                return (alpha / Math.Sqrt(2.0)) * (
                    ((1.0 + 2.0 / Math.PI) * Math.Sin(Math.PI / (4.0 * alpha))) +
                    ((1.0 - 2.0 / Math.PI) * Math.Cos(Math.PI / (4.0 * alpha)))
                );
            }

            return (Math.Sin((1.0 - alpha) * harmonicTime) +
                   4.0 * alpha * t * Math.Cos((1.0 + alpha) * harmonicTime)) /
                   (harmonicTime * (1.0 - squaredTime));
        }

        /// <summary>
        /// Deinterleaves a P25 frame according to the standard matrix
        /// </summary>
        public static byte[] DeinterleaveFrame(byte[] frame)
        {
            const int INTERLEAVE_ROWS = 8;
            const int INTERLEAVE_COLS = 32;
            
            if (frame.Length != INTERLEAVE_ROWS * INTERLEAVE_COLS)
                return frame;

            var deinterleaved = new byte[frame.Length];
            int index = 0;

            for (int col = 0; col < INTERLEAVE_COLS; col++)
            {
                for (int row = 0; row < INTERLEAVE_ROWS; row++)
                {
                    deinterleaved[index++] = frame[row * INTERLEAVE_COLS + col];
                }
            }

            return deinterleaved;
        }

        /// <summary>
        /// Performs frame synchronization using correlation
        /// </summary>
        public static int FindFrameSync(Complex[] samples, double threshold = 0.8)
        {
            // P25 frame sync pattern (normalized to -1, 1)
            double[] syncPattern = {
                1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, 1,
                1, 1, -1, -1, -1, 1, -1, -1, 1, -1, 1, -1,
                -1, 1, 1, -1, 1, -1, -1, -1, -1, 1, -1, 1,
                1, -1, 1, 1, 1, -1, -1, 1, 1, 1, 1, 1
            };

            int bestOffset = -1;
            double bestCorrelation = threshold;

            // Search for sync pattern
            for (int i = 0; i <= samples.Length - syncPattern.Length; i++)
            {
                double correlation = 0;
                for (int j = 0; j < syncPattern.Length; j++)
                {
                    Complex sample = samples[i + j];
                    // Use phase for correlation
                    double phase = Math.Atan2(sample.Imaginary, sample.Real) / Math.PI;
                    correlation += phase * syncPattern[j];
                }

                correlation = Math.Abs(correlation / syncPattern.Length);
                if (correlation > bestCorrelation)
                {
                    bestCorrelation = correlation;
                    bestOffset = i;
                }
            }

            return bestOffset;
        }

        /// <summary>
        /// Performs error correction using Golay(24,12) code
        /// </summary>
        public static byte[] ApplyGolayCorrection(byte[] data)
        {
            // TODO: Implement Golay(24,12) error correction
            // This is a placeholder for actual Golay implementation
            return data;
        }
    }
}

