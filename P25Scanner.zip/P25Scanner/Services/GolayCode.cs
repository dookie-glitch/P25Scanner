using System;
using System.Collections.Generic;

namespace P25Scanner.Services
{
    /// <summary>
    /// Implements Golay(24,12) error correction code
    /// </summary>
    internal static class GolayCode
    {
        // Generator matrix for Golay(24,12) code
        private static readonly int[] GENERATOR_MATRIX = {
            0xC75, 0x49F, 0x93E, 0xAB7, 0x557, 0xED9,
            0xDCB, 0x8E6, 0xF13, 0xB66, 0x1ED, 0xFCC
        };

        // Syndrome table for error correction
        private static readonly Dictionary<int, int> SYNDROME_TABLE;

        static GolayCode()
        {
            // Initialize syndrome table
            SYNDROME_TABLE = new Dictionary<int, int>();
            GenerateSyndromeTable();
        }

        /// <summary>
        /// Encodes 12 bits of data into a 24-bit Golay codeword
        /// </summary>
        public static int Encode(int data)
        {
            if ((data & 0xFFF000) != 0)
                throw new ArgumentException("Input data must be 12 bits", nameof(data));

            int codeword = data;
            int parity = 0;

            // Generate parity bits using generator matrix
            for (int i = 0; i < 12; i++)
            {
                if ((data & (1 << i)) != 0)
                {
                    parity ^= GENERATOR_MATRIX[i];
                }
            }

            // Combine data and parity to form 24-bit codeword
            return (codeword << 12) | parity;
        }

        /// <summary>
        /// Decodes a 24-bit Golay codeword and corrects up to 3 errors
        /// </summary>
        public static (int data, bool success) Decode(int codeword)
        {
            // Calculate syndrome
            int syndrome = CalculateSyndrome(codeword);

            if (syndrome == 0)
            {
                // No errors detected
                return (codeword >> 12, true);
            }

            // Look up error pattern in syndrome table
            if (SYNDROME_TABLE.TryGetValue(syndrome, out int errorPattern))
            {
                // Correct errors
                int corrected = codeword ^ errorPattern;
                return (corrected >> 12, true);
            }

            // Uncorrectable errors
            return (codeword >> 12, false);
        }

        /// <summary>
        /// Calculates syndrome for error detection
        /// </summary>
        private static int CalculateSyndrome(int codeword)
        {
            int syndrome = 0;
            for (int i = 0; i < 24; i++)
            {
                if ((codeword & (1 << i)) != 0)
                {
                    syndrome ^= (i < 12) ? GENERATOR_MATRIX[i] : (1 << (i - 12));
                }
            }
            return syndrome;
        }

        /// <summary>
        /// Generates syndrome table for all correctable error patterns
        /// </summary>
        private static void GenerateSyndromeTable()
        {
            // Add syndromes for all 1-bit errors
            for (int i = 0; i < 24; i++)
            {
                int errorPattern = 1 << i;
                int syndrome = CalculateSyndrome(errorPattern);
                SYNDROME_TABLE[syndrome] = errorPattern;
            }

            // Add syndromes for all 2-bit errors
            for (int i = 0; i < 23; i++)
            {
                for (int j = i + 1; j < 24; j++)
                {
                    int errorPattern = (1 << i) | (1 << j);
                    int syndrome = CalculateSyndrome(errorPattern);
                    SYNDROME_TABLE[syndrome] = errorPattern;
                }
            }

            // Add syndromes for all 3-bit errors
            for (int i = 0; i < 22; i++)
            {
                for (int j = i + 1; j < 23; j++)
                {
                    for (int k = j + 1; k < 24; k++)
                    {
                        int errorPattern = (1 << i) | (1 << j) | (1 << k);
                        int syndrome = CalculateSyndrome(errorPattern);
                        SYNDROME_TABLE[syndrome] = errorPattern;
                    }
                }
            }
        }

        /// <summary>
        /// Applies Golay error correction to a byte array
        /// </summary>
        public static byte[] ApplyErrorCorrection(byte[] data)
        {
            if (data == null || data.Length % 3 != 0)
                return data;

            var corrected = new byte[data.Length];
            
            // Process each 24-bit block
            for (int i = 0; i < data.Length; i += 3)
            {
                // Convert 3 bytes to 24-bit codeword
                int codeword = (data[i] << 16) | (data[i + 1] << 8) | data[i + 2];
                
                // Decode and correct errors
                var (decoded, success) = Decode(codeword);
                
                if (success)
                {
                    // Store corrected data
                    corrected[i] = (byte)(decoded >> 4);
                    corrected[i + 1] = (byte)((decoded & 0xFF0) >> 4);
                    corrected[i + 2] = (byte)(decoded & 0xF);
                }
                else
                {
                    // If correction failed, keep original data
                    Array.Copy(data, i, corrected, i, 3);
                }
            }

            return corrected;
        }
    }
}

