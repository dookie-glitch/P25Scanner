using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace P25Scanner.Services.Interfaces
{
    /// <summary>
    /// Interface for audio service that handles playback and recording of audio
    /// </summary>
    public interface IAudioService : IDisposable
    {
        /// <summary>
        /// Event triggered when audio playback status changes
        /// </summary>
        event EventHandler<AudioStatusEventArgs> AudioStatusChanged;

        /// <summary>
        /// Gets a value indicating whether audio is currently playing
        /// </summary>
        bool IsPlaying { get; }

        /// <summary>
        /// Gets a value indicating whether audio is currently being recorded
        /// </summary>
        bool IsRecording { get; }

        /// <summary>
        /// Gets or sets the current volume (0.0 to 1.0)
        /// </summary>
        float Volume { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether audio is muted
        /// </summary>
        bool IsMuted { get; set; }

        /// <summary>
        /// Gets the currently selected output device
        /// </summary>
        string CurrentOutputDevice { get; }

        /// <summary>
        /// Gets the recording file path if recording is active
        /// </summary>
        string RecordingFilePath { get; }

        /// <summary>
        /// Gets a list of available audio output devices
        /// </summary>
        /// <returns>List of device names</returns>
        Task<List<string>> GetAvailableOutputDevicesAsync();

        /// <summary>
        /// Initializes the audio playback with the specified device
        /// </summary>
        /// <param name="deviceName">Name of the output device, null for default</param>
        /// <returns>True if successful, false otherwise</returns>
        Task<bool> InitializeAudioAsync(string deviceName = null);

        /// <summary>
        /// Plays the provided audio samples
        /// </summary>
        /// <param name="samples">Audio samples to play</param>
        /// <param name="sampleRate">Sample rate of the audio</param>
        /// <returns>True if successful, false otherwise</returns>
        Task<bool> PlayAudioAsync(float[] samples, int sampleRate);

        /// <summary>
        /// Stops the audio playback
        /// </summary>
        Task StopAudioAsync();

        /// <summary>
        /// Starts recording audio to the specified file path
        /// </summary>
        /// <param name="filePath">Path to save the recorded audio</param>
        /// <returns>True if successful, false otherwise</returns>
        Task<bool> StartRecordingAsync(string filePath);

        /// <summary>
        /// Stops recording audio
        /// </summary>
        /// <returns>Path to the recorded file if successful, null otherwise</returns>
        Task<string> StopRecordingAsync();
    }

    /// <summary>
    /// Event arguments for audio status changes
    /// </summary>
    public class AudioStatusEventArgs : EventArgs
    {
        /// <summary>
        /// Gets a value indicating whether audio is playing
        /// </summary>
        public bool IsPlaying { get; }

        /// <summary>
        /// Gets a value indicating whether audio is being recorded
        /// </summary>
        public bool IsRecording { get; }

        /// <summary>
        /// Gets the status message
        /// </summary>
        public string Message { get; }

        /// <summary>
        /// Gets the error if any
        /// </summary>
        public Exception Error { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="AudioStatusEventArgs"/> class
        /// </summary>
        /// <param name="isPlaying">Whether audio is playing</param>
        /// <param name="isRecording">Whether audio is being recorded</param>
        /// <param name="message">Status message</param>
        /// <param name="error">Associated error if any</param>
        public AudioStatusEventArgs(bool isPlaying, bool isRecording, string message, Exception error = null)
        {
            IsPlaying = isPlaying;
            IsRecording = isRecording;
            Message = message;
            Error = error;
        }
    }
}

