using System;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;

namespace P25Scanner.Services.Interfaces
{
    public class DecoderStatusEventArgs : EventArgs
    {
        public DecoderStatus Status { get; }
        public string Message { get; }

        public DecoderStatusEventArgs(DecoderStatus status, string message = null)
        {
            Status = status;
            Message = message;
        }
    }

    public class DecodedAudioEventArgs : EventArgs
    {
        public float[] AudioSamples { get; }
        public DateTime Timestamp { get; }

        public DecodedAudioEventArgs(float[] audioSamples)
        {
            AudioSamples = audioSamples;
            Timestamp = DateTime.UtcNow;
        }
    }

    public class TalkgroupEventArgs : EventArgs
    {
        public int TalkgroupId { get; }
        public int NAC { get; }
        public DateTime Timestamp { get; }

        public TalkgroupEventArgs(int talkgroupId, int nac)
        {
            TalkgroupId = talkgroupId;
            NAC = nac;
            Timestamp = DateTime.UtcNow;
        }
    }

    public enum DecoderStatus
    {
        Stopped,
        Starting,
        Running,
        Stopping,
        Error
    }

    public interface IP25Decoder : IDisposable
    {
        bool IsActive { get; }
        float SquelchThreshold { get; set; }
        float SignalQuality { get; }
        int CurrentTalkgroupId { get; }
        int CurrentNAC { get; }

        Task<bool> InitializeAsync(uint sampleRate);
        Task<bool> StartAsync(CancellationToken cancellationToken);
        Task StopAsync();
        Task<bool> ProcessIQDataAsync(Complex[] iqData);

        // Events
        event EventHandler<DecodedAudioEventArgs> DecodedAudioAvailable;
        event EventHandler<TalkgroupEventArgs> TalkgroupDetected;
        event EventHandler<DecoderStatusEventArgs> DecoderStatusChanged;
    }
}

using System;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;

namespace P25Scanner.Services.Interfaces
{
    /// <summary>
    /// Interface for P25 digital voice decoder
    /// </summary>
    public interface IP25Decoder : IDisposable
    {
        /// <summary>
        /// Event triggered when decoded audio is available
        /// </summary>
        event EventHandler<DecodedAudioEventArgs> DecodedAudioAvailable;

        /// <summary>
        /// Event triggered when a new talkgroup is detected
        /// </summary>
        event EventHandler<TalkgroupEventArgs> TalkgroupDetected;

        /// <summary>
        /// Event triggered when decoder status changes
        /// </summary>
        event EventHandler<DecoderStatusEventArgs> DecoderStatusChanged;

        /// <summary>
        /// Gets a value indicating whether the decoder is active
        /// </summary>
        bool IsActive { get; }

        /// <summary>
        /// Gets or sets the squelch threshold in dB
        /// </summary>
        float SquelchThreshold { get; set; }

        /// <summary>
        /// Gets the current signal quality in dB
        /// </summary>
        float SignalQuality { get; }

        /// <summary>
        /// Gets the current talkgroup ID
        /// </summary>
        int CurrentTalkgroupId { get; }

        /// <summary>
        /// Gets the current Network Access Code (NAC)
        /// </summary>
        int CurrentNAC { get; }

        /// <summary>
        /// Initializes the P25 decoder
        /// </summary>
        /// <param name="sampleRate">Sample rate of the input IQ data</param>
        /// <returns>True if initialization was successful, false otherwise</returns>
        Task<bool> InitializeAsync(uint sampleRate);

        /// <summary>
        /// Starts the P25 decoder
        /// </summary>
        /// <param name="cancellationToken">Cancellation token to stop decoding</param>
        /// <returns>True if successfully started, false otherwise</returns>
        Task<bool> StartAsync(CancellationToken cancellationToken);

        /// <summary>
        /// Stops the P25 decoder
        /// </summary>
        Task StopAsync();

        /// <summary>
        /// Processes IQ data for decoding
        /// </summary>
        /// <param name="iqData">Complex IQ data samples</param>
        /// <returns>True if processing was successful, false otherwise</returns>
        Task<bool> ProcessIQDataAsync(Complex[] iqData);

        /// <summary>
        /// Adds a talkgroup to the filter list
        /// </summary>
        /// <param name="talkgroupId">Talkgroup ID to add</param>
        void AddTalkgroupFilter(int talkgroupId);

        /// <summary>
        /// Removes a talkgroup from the filter list
        /// </summary>
        /// <param name="talkgroupId">Talkgroup ID to remove</param>
        void RemoveTalkgroupFilter(int talkgroupId);

        /// <summary>
        /// Clears all talkgroup filters
        /// </summary>
        void ClearTalkgroupFilters();
    }

    /// <summary>
    /// Event arguments for decoded audio data
    /// </summary>
    public class DecodedAudioEventArgs : EventArgs
    {
        /// <summary>
        /// Gets the decoded audio samples
        /// </summary>
        public float[] AudioSamples { get; }

        /// <summary>
        /// Gets the sample rate of the audio
        /// </summary>
        public int SampleRate { get; }

        /// <summary>
        /// Gets the talkgroup ID associated with the audio
        /// </summary>
        public int TalkgroupId { get; }

        /// <summary>
        /// Gets the Network Access Code (NAC)
        /// </summary>
        public int NAC { get; }

        /// <summary>
        /// Gets the timestamp when the audio was decoded
        /// </summary>
        public DateTime Timestamp { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="DecodedAudioEventArgs"/> class
        /// </summary>
        /// <param name="audioSamples">Decoded audio samples</param>
        /// <param name="sampleRate">Sample rate of the audio</param>
        /// <param name="talkgroupId">Talkgroup ID</param>
        /// <param name="nac">Network Access Code</param>
        /// <param name="timestamp">Timestamp when the audio was decoded</param>
        public DecodedAudioEventArgs(float[] audioSamples, int sampleRate, int talkgroupId, int nac, DateTime timestamp)
        {
            AudioSamples = audioSamples;
            SampleRate = sampleRate;
            TalkgroupId = talkgroupId;
            NAC = nac;
            Timestamp = timestamp;
        }
    }

    /// <summary>
    /// Event arguments for talkgroup detection
    /// </summary>
    public class TalkgroupEventArgs : EventArgs
    {
        /// <summary>
        /// Gets the talkgroup ID
        /// </summary>
        public int TalkgroupId { get; }

        /// <summary>
        /// Gets the Network Access Code (NAC)
        /// </summary>
        public int NAC { get; }

        /// <summary>
        /// Gets a value indicating whether the talkgroup is active
        /// </summary>
        public bool IsActive { get; }

        /// <summary>
        /// Gets the source radio ID
        /// </summary>
        public int SourceId { get; }

        /// <summary>
        /// Gets the

