using System;
using System.Collections.Generic;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;

namespace P25Scanner.Services.Interfaces
{
    /// <summary>
    /// Interface for RTL-SDR service that handles device operations
    /// </summary>
    public interface IRtlSdrService : IDisposable
    {
        /// <summary>
        /// Event triggered when IQ data is received from the device
        /// </summary>
        event EventHandler<IQDataEventArgs> IQDataReceived;

        /// <summary>
        /// Event triggered when device status changes
        /// </summary>
        event EventHandler<DeviceStatusEventArgs> DeviceStatusChanged;

        /// <summary>
        /// Gets a value indicating whether a device is connected
        /// </summary>
        bool IsDeviceConnected { get; }

        /// <summary>
        /// Gets the current center frequency in Hz
        /// </summary>
        uint CenterFrequency { get; }

        /// <summary>
        /// Gets the current sample rate in Hz
        /// </summary>
        uint SampleRate { get; }

        /// <summary>
        /// Gets the current gain in dB
        /// </summary>
        double Gain { get; }

        /// <summary>
        /// Gets a list of available devices
        /// </summary>
        /// <returns>List of device names and indices</returns>
        Task<List<(int Index, string Name)>> GetAvailableDevicesAsync();

        /// <summary>
        /// Initializes the device with the specified index
        /// </summary>
        /// <param name="deviceIndex">Index of the device to initialize</param>
        /// <returns>True if initialization was successful, false otherwise</returns>
        Task<bool> InitializeDeviceAsync(int deviceIndex);

        /// <summary>
        /// Sets the center frequency of the device
        /// </summary>
        /// <param name="frequency">Frequency in Hz</param>
        /// <returns>True if successful, false otherwise</returns>
        Task<bool> SetCenterFrequencyAsync(uint frequency);

        /// <summary>
        /// Sets the sample rate of the device
        /// </summary>
        /// <param name="sampleRate">Sample rate in Hz</param>
        /// <returns>True if successful, false otherwise</returns>
        Task<bool> SetSampleRateAsync(uint sampleRate);

        /// <summary>
        /// Sets the gain of the device
        /// </summary>
        /// <param name="gain">Gain in dB</param>
        /// <returns>True if successful, false otherwise</returns>
        Task<bool> SetGainAsync(double gain);

        /// <summary>
        /// Gets the available gain values supported by the device
        /// </summary>
        /// <returns>List of gain values in dB</returns>
        Task<List<double>> GetAvailableGainsAsync();

        /// <summary>
        /// Gets the available sample rates supported by the device
        /// </summary>
        /// <returns>List of sample rates in Hz</returns>
        Task<List<uint>> GetAvailableSampleRatesAsync();

        /// <summary>
        /// Starts streaming data from the device
        /// </summary>
        /// <param name="cancellationToken">Cancellation token to stop streaming</param>
        /// <returns>Task representing the streaming operation</returns>
        Task StartStreamingAsync(CancellationToken cancellationToken);

        /// <summary>
        /// Stops streaming data from the device
        /// </summary>
        Task StopStreamingAsync();
    }

    /// <summary>
    /// Event arguments for IQ data received from RTL-SDR device
    /// </summary>
    public class IQDataEventArgs : EventArgs
    {
        /// <summary>
        /// Gets the complex IQ samples
        /// </summary>
        public Complex[] Samples { get; }

        /// <summary>
        /// Gets the timestamp when the samples were received
        /// </summary>
        public DateTime Timestamp { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="IQDataEventArgs"/> class
        /// </summary>
        /// <param name="samples">Complex IQ samples</param>
        /// <param name="timestamp">Timestamp when samples were received</param>
        public IQDataEventArgs(Complex[] samples, DateTime timestamp)
        {
            Samples = samples;
            Timestamp = timestamp;
        }
    }

    /// <summary>
    /// Event arguments for device status changes
    /// </summary>
    public class DeviceStatusEventArgs : EventArgs
    {
        /// <summary>
        /// Gets a value indicating whether the device is connected
        /// </summary>
        public bool IsConnected { get; }

        /// <summary>
        /// Gets the device message
        /// </summary>
        public string Message { get; }

        /// <summary>
        /// Gets the error if any
        /// </summary>
        public Exception Error { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="DeviceStatusEventArgs"/> class
        /// </summary>
        /// <param name="isConnected">Whether the device is connected</param>
        /// <param name="message">Status message</param>
        /// <param name="error">Associated error if any</param>
        public DeviceStatusEventArgs(bool isConnected, string message, Exception error = null)
        {
            IsConnected = isConnected;
            Message = message;
            Error = error;
        }
    }
}

