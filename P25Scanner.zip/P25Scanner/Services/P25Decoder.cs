using Microsoft.Extensions.Logging;
using P25Scanner.Configuration;
using P25Scanner.Services.Interfaces;
using System;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;

namespace P25Scanner.Services
{
    public class P25Decoder : IP25Decoder
    {
        private readonly ILogger<P25Decoder> _logger;
        private readonly AppConfig _config;
        private readonly TalkgroupManager _talkgroupManager;
        private CancellationTokenSource _processingCts;
        private Task _processingTask;
        private DecoderStatus _status;
        private uint _sampleRate;
        private bool _isDisposed;

        public bool IsActive => _status == DecoderStatus.Running;
        public float SquelchThreshold { get; set; }
        public float SignalQuality { get; private set; }
        public int CurrentTalkgroupId { get; private set; }
        public int CurrentNAC { get; private set; }

        public event EventHandler<DecodedAudioEventArgs> DecodedAudioAvailable;
        public event EventHandler<TalkgroupEventArgs> TalkgroupDetected;
        public event EventHandler<DecoderStatusEventArgs> DecoderStatusChanged;

        public P25Decoder(
            ILogger<P25Decoder> logger,
            AppConfig config,
            TalkgroupManager talkgroupManager)
        {
            _logger = logger;
            _config = config;
            _talkgroupManager = talkgroupManager;
            SquelchThreshold = _config.Sdr.SquelchThreshold;
        }

        public async Task<bool> InitializeAsync(uint sampleRate)
        {
            try
            {
                _sampleRate = sampleRate;
                UpdateStatus(DecoderStatus.Starting, "Initializing decoder");

                // TODO: Initialize DSP components
                // - Create filters
                // - Setup demodulator
                // - Initialize symbol synchronizer
                // - Setup frame sync detector

                UpdateStatus(DecoderStatus.Stopped, "Decoder initialized");
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to initialize decoder");
                UpdateStatus(DecoderStatus.Error, ex.Message);
                return false;
            }
        }

        public async Task<bool> StartAsync(CancellationToken cancellationToken)
        {
            try
            {
                if (_status == DecoderStatus.Running)
                    return true;

                UpdateStatus(DecoderStatus.Starting, "Starting decoder");

                _processingCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
                _processingTask = Task.Run(ProcessingLoopAsync);

                UpdateStatus(DecoderStatus.Running, "Decoder started");
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to start decoder");
                UpdateStatus(DecoderStatus.Error, ex.Message);
                return false;
            }
        }

        public async Task StopAsync()
        {
            try
            {
                if (_status != DecoderStatus.Running)
                    return;

                UpdateStatus(DecoderStatus.Stopping, "Stopping decoder");

                _processingCts?.Cancel();
                if (_processingTask != null)
                {
                    await _processingTask;
                    _processingTask = null;
                }

                UpdateStatus(DecoderStatus.Stopped, "Decoder stopped");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error stopping decoder");
                UpdateStatus(DecoderStatus.Error, ex.Message);
            }
        }

        public async Task<bool> ProcessIQDataAsync(Complex[] iqData)
        {
            if (_status != DecoderStatus.Running || iqData == null)
                return false;

            try
            {
                // TODO: Implement signal processing chain
                // 1. Apply frequency correction
                // 2. Filter the signal
                // 3. Demodulate
                // 4. Recover symbols
                // 5. Detect frame sync
                // 6. Decode P25 data
                // 7. Extract audio and metadata

                // This is a placeholder implementation
                SignalQuality = CalculateSignalQuality(iqData);
                
                if (SignalQuality > SquelchThreshold)
                {
                    // Simulate some audio output
                    var audioSamples = new float[1024];
                    OnDecodedAudioAvailable(new DecodedAudioEventArgs(audioSamples));
                }

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing IQ data");
                return false;
            }
        }

        private async Task ProcessingLoopAsync()
        {
            try
            {
                while (!_processingCts.Token.IsCancellationRequested)
                {
                    // TODO: Implement main processing loop
                    await Task.Delay(10, _processingCts.Token);
                }
            }
            catch (OperationCanceledException)
            {
                // Normal cancellation
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in processing loop");
                UpdateStatus(DecoderStatus.Error, ex.Message);
            }
        }

        private float CalculateSignalQuality(Complex[] iqData)
        {
            // TODO: Implement proper signal quality measurement
            // This is a placeholder implementation
            float sumPower = 0;
            for (int i = 0; i < iqData.Length; i++)
            {
                sumPower += (float)(Math.Pow(iqData[i].Real, 2) + Math.Pow(iqData[i].Imaginary, 2));
            }
            return 10 * (float)Math.Log10(sumPower / iqData.Length);
        }

        private void UpdateStatus(DecoderStatus status, string message = null)
        {
            _status = status;
            OnDecoderStatusChanged(new DecoderStatusEventArgs(status, message));
        }

        protected virtual void OnDecodedAudioAvailable(DecodedAudioEventArgs e)
        {
            DecodedAudioAvailable?.Invoke(this, e);
        }

        protected virtual void OnTalkgroupDetected(TalkgroupEventArgs e)
        {
            TalkgroupDetected?.Invoke(this, e);
        }

        protected virtual void OnDecoderStatusChanged(DecoderStatusEventArgs e)
        {
            DecoderStatusChanged?.Invoke(this, e);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_isDisposed)
            {
                if (disposing)
                {
                    StopAsync().Wait();
                    _processingCts?.Dispose();
                }

                _isDisposed = true;
            }
        }
    }
}

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using P25Scanner.Services.Interfaces;

namespace P25Scanner.Services
{
    /// <summary>
    /// Implementation of the P25 digital voice decoder
    /// </summary>
    public class P25Decoder : IP25Decoder
    {
        private readonly ILogger<P25Decoder> _logger;
        private readonly ConcurrentDictionary<int, bool> _talkgroupFilters;
        private CancellationTokenSource _decodingCts;
        private Task _decodingTask;
        private double _sampleRate;  // Use double for filter calculations
        private bool _isActive;
        private readonly object _lockObject = new object();
        
        // Buffer for storing IQ samples for processing
        private readonly ConcurrentQueue<Complex[]> _iqBufferQueue;
        
        // Signal processing parameters
        private float _signalQuality;
        private int _currentTalkgroupId;
        private int _currentNAC;
        private const int AUDIO_SAMPLE_RATE = 8000; // Standard sample rate for P25 decoded audio
        
        // P25 specific constants
        private const int P25_SYMBOL_RATE = 4800;  // P25 symbol rate in symbols per second
        private const float MIN_SIGNAL_QUALITY_DB = -45.0f; // Minimum signal quality in dB for valid decode
        private const int SYMBOL_RATE = 4800;
        private const int SAMPLES_PER_SYMBOL = 10; // Depends on sample rate
        private const int SYNC_PATTERN_LENGTH = 48; // Bits in NID
        
        // P25 Common Air Interface (CAI) constants
        private static readonly byte[] FRAME_SYNC_PATTERN = { 
            0x5F, 0x7F, 0x7D, 0x5D, 0xD7, 0xFD, 0xDF, 0x7F, 0x5F, 0x7D
        };
        private int _symbolTimingOffset = 0;

        /// <summary>
        /// Event triggered when decoded audio is available
        /// </summary>
        public event EventHandler<DecodedAudioEventArgs> DecodedAudioAvailable;
        
        /// <summary>
        /// Event triggered when a new talkgroup is detected
        /// </summary>
        public event EventHandler<TalkgroupEventArgs> TalkgroupDetected;
        
        /// <summary>
        /// Event triggered when decoder status changes
        /// </summary>
        public event EventHandler<DecoderStatusEventArgs> DecoderStatusChanged;

        /// <summary>
        /// Gets a value indicating whether the decoder is active
        /// </summary>
        public bool IsActive => _isActive;

        /// <summary>
        /// Gets or sets the squelch threshold in dB
        /// </summary>
        public float SquelchThreshold { get; set; } = -30.0f;

        /// <summary>
        /// Gets the current signal quality in dB
        /// </summary>
        public float SignalQuality => _signalQuality;

        /// <summary>
        /// Gets the current talkgroup ID
        /// </summary>
        public int CurrentTalkgroupId => _currentTalkgroupId;

        /// <summary>
        /// Gets the current Network Access Code (NAC)
        /// </summary>
        public int CurrentNAC => _currentNAC;

        /// <summary>
        /// Initializes a new instance of the <see cref="P25Decoder"/> class
        /// </summary>
        /// <param name="logger">Logger instance</param>
        public P25Decoder(ILogger<P25Decoder> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _talkgroupFilters = new ConcurrentDictionary<int, bool>();
            _iqBufferQueue = new ConcurrentQueue<Complex[]>();
            _signalQuality = float.MinValue;
            _currentTalkgroupId = 0;
            _currentNAC = 0;
            _isActive = false;
        }

        /// <summary>
        /// Initializes the P25 decoder
        /// </summary>
        /// <param name="sampleRate">Sample rate of the input IQ data</param>
        /// <returns>True if initialization was successful, false otherwise</returns>
        public async Task<bool> InitializeAsync(uint sampleRate)
        {
            try
            {
                _sampleRate = sampleRate;
                
                // Calculate samples per symbol based on sample rate and P25 symbol rate
                double samplesPerSymbol = (double)_sampleRate / P25_SYMBOL_RATE;
                
                _logger.LogInformation($"P25 decoder initialized with sample rate {sampleRate} Hz, samples per symbol: {samplesPerSymbol:F2}");
                
                // Clear any existing buffers
                while (_iqBufferQueue.TryDequeue(out _)) { }
                
                await RaiseDecoderStatusChangedAsync(DecoderStatus.Initialized);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to initialize P25 decoder");
                await RaiseDecoderStatusChangedAsync(DecoderStatus.Error, ex.Message);
                return false;
            }
        }

        /// <summary>
        /// Starts the P25 decoder
        /// </summary>
        /// <param name="cancellationToken">Cancellation token to stop decoding</param>
        /// <returns>True if successfully started, false otherwise</returns>
        public async Task<bool> StartAsync(CancellationToken cancellationToken)
        {
            if (_isActive)
            {
                _logger.LogWarning("P25 decoder is already active");
                return true;
            }

            try
            {
                _decodingCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
                
                // Start the decoding task
                _decodingTask = Task.Run(() => DecodingLoopAsync(_decodingCts.Token), _decodingCts.Token);
                
                _isActive = true;
                _logger.LogInformation("P25 decoder started");
                
                await RaiseDecoderStatusChangedAsync(DecoderStatus.Running);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to start P25 decoder");
                await RaiseDecoderStatusChangedAsync(DecoderStatus.Error, ex.Message);
                return false;
            }
        }

        /// <summary>
        /// Stops the P25 decoder
        /// </summary>
        public async Task StopAsync()
        {
            if (!_isActive)
            {
                _logger.LogWarning("P25 decoder is not active");
                return;
            }

            try
            {
                // Cancel the decoding task
                if (_decodingCts != null)
                {
                    _decodingCts.Cancel();
                    
                    // Wait for the task to complete with a timeout
                    if (_decodingTask != null)
                    {
                        await Task.WhenAny(_decodingTask, Task.Delay(1000));
                    }
                    
                    _decodingCts.Dispose();
                    _decodingCts = null;
                }
                
                _isActive = false;
                _signalQuality = float.MinValue;
                _currentTalkgroupId = 0;
                _currentNAC = 0;
                
                _logger.LogInformation("P25 decoder stopped");
                
                await RaiseDecoderStatusChangedAsync(DecoderStatus.Stopped);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while stopping P25 decoder");
                await RaiseDecoderStatusChangedAsync(DecoderStatus.Error, ex.Message);
            }
        }

        /// <summary>
        /// Processes IQ data for decoding
        /// </summary>
        /// <param name="iqData">Complex IQ data samples</param>
        /// <returns>True if processing was successful, false otherwise</returns>
        public async Task<bool> ProcessIQDataAsync(Complex[] iqData)
        {
            if (iqData == null || iqData.Length == 0)
            {
                return false;
            }

            try
            {
                // Calculate signal quality (simple power calculation)
                float signalPower = CalculateSignalPower(iqData);
                _signalQuality = 10 * (float)Math.Log10(signalPower);
                
                // Queue the IQ data for processing if decoder is active
                if (_isActive)
                {
                    _iqBufferQueue.Enqueue(iqData);
                }
                
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing IQ data");
                return false;
            }
        }

        /// <summary>
        /// Adds a talkgroup to the filter list
        /// </summary>
        /// <param name="talkgroupId">Talkgroup ID to add</param>
        public void AddTalkgroupFilter(int talkgroupId)
        {
            if (talkgroupId <= 0)
            {
                _logger.LogWarning($"Invalid talkgroup ID: {talkgroupId}");
                return;
            }
            
            _talkgroupFilters.AddOrUpdate(talkgroupId, true, (_, _) => true);
            _logger.LogInformation($"Added talkgroup filter: {talkgroupId}");
        }

        /// <summary>
        /// Removes a talkgroup from the filter list
        /// </summary>
        /// <param name="talkgroupId">Talkgroup ID to remove</param>
        public void RemoveTalkgroupFilter(int talkgroupId)
        {
            if (_talkgroupFilters.TryRemove(talkgroupId, out _))
            {
                _logger.LogInformation($"Removed talkgroup filter: {talkgroupId}");
            }
        }

        /// <summary>
        /// Clears all talkgroup filters
        /// </summary>
        public void ClearTalkgroupFilters()
        {
            _talkgroupFilters.Clear();
            _logger.LogInformation("Cleared all talkgroup filters");
        }

        /// <summary>
        /// Disposes managed and unmanaged resources
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Disposes managed and unmanaged resources
        /// </summary>
        /// <param name="disposing">True to dispose managed resources</param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                StopAsync().GetAwaiter().GetResult();
                
                _decodingCts?.Dispose();
                _decodingCts = null;
            }
        }

        #region Private Methods

        /// <summary>
        /// Asynchronously raises the DecoderStatusChanged event
        /// </summary>
        /// <param name="status">The new decoder status</param>
        /// <param name="message">Optional status message</param>
        private async Task RaiseDecoderStatusChangedAsync(DecoderStatus status, string message = null)
        {
            try
            {
                var args = new DecoderStatusEventArgs(status, message);
                await Task.Run(() => DecoderStatusChanged?.Invoke(this, args));
                _logger.LogDebug("Decoder status changed to {Status}: {Message}", status, message ?? "");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error raising DecoderStatusChanged event");
            }
        }
        private async Task DecodingLoopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("P25 decoding loop started");
            
            try
            {
                while (!cancellationToken.IsCancellationRequested)
                {
                    // Process all available IQ buffers in the queue
                    while (_iqBufferQueue.TryDequeue(out Complex[] iqBuffer) && !cancellationToken.IsCancellationRequested)
                    {
                        // Skip processing if signal quality is below threshold
                        if (_signalQuality < SquelchThreshold)
                        {
                            continue;
                        }
                        
                        // Decode P25 signal
                        await DecodeP25SignalAsync(iqBuffer, cancellationToken);
                    }
                    
                    // Prevent tight loop when no data is available
                    await Task.Delay(10, cancellationToken);
                }
            }
            catch (OperationCanceledException)
            {
                _logger.LogInformation("P25 decoding loop cancelled");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in P25 decoding loop");
                await RaiseDecoderStatusChangedAsync(DecoderStatus.Error, ex.Message);
            }
            
            _logger.LogInformation("P25 decoding loop ended");
        }

        private async Task DecodeP25SignalAsync(Complex[] iqData, CancellationToken cancellationToken)
        {
            try
            {
                // 1. Apply baseband filtering
                var filteredData = ApplyBasebandFilter(iqData);
                
                // 2. Detect frame sync
                if (DetectFrameSync(filteredData))
                {
                    _logger.LogDebug("Frame sync detected at offset {Offset}", _symbolTimingOffset);
                    
                    // 3. Extract and process frame data using timing offset
                    byte[] frameData = ExtractFrameData(filteredData, _symbolTimingOffset);
                    
                    if (frameData != null && frameData.Length > 0)
                    {
                        // 4. Deinterleave the frame
                        var deinterleaved = DeinterleaveFrame(frameData);
                        
                        // 5. Apply error correction
                        var corrected = ApplyErrorCorrection(deinterleaved);
                        
                        // 6. Find Network Access Code (NAC)
                        int detectedNAC = ExtractNAC(filteredData);
                        
                        if (detectedNAC > 0)
                        {
                            _currentNAC = detectedNAC;
                            
                            // 7. Extract talkgroup ID
                            int talkgroupId = ExtractTalkgroupId(corrected);
                            bool isNewTalkgroup = (_currentTalkgroupId != talkgroupId);
                            _currentTalkgroupId = talkgroupId;
                            
                            // Check if we should process this talkgroup
                            bool shouldProcess = _talkgroupFilters.Count == 0 || 
                                               _talkgroupFilters.ContainsKey(talkgroupId);
                            
                            if (shouldProcess)
                            {
                                // 8. Extract IMBE voice frames
                                var voiceFrames = ExtractVoiceFrames(corrected);
                                
                                foreach (var imbeFrame in voiceFrames)
                                {
                                    if (cancellationToken.IsCancellationRequested)
                                        break;
                                        
                                    // 9. Decode IMBE to PCM audio
                                    var audioSamples = ProcessIMBEFrame(imbeFrame);
                                    
                                    if (audioSamples.Length > 0)
                                    {
                                        // 10. Raise event with decoded audio
                                        await RaiseDecodedAudioAvailableAsync(audioSamples, talkgroupId);
                                    }
                                }
                                
                                // If this is a new talkgroup, raise the event
                                if (isNewTalkgroup)
                                {
                                    await RaiseTalkgroupDetectedAsync(talkgroupId);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error decoding P25 signal");
                await RaiseDecoderStatusChangedAsync(DecoderStatus.Error, ex.Message);
            }
        }

        /// <summary>
        /// Deinterleaves a P25 frame according to the P25 standard
        /// </summary>
        private byte[] DeinterleaveFrame(byte[] frame)
        {
            if (frame == null || frame.Length == 0)
                return Array.Empty<byte>();

            try
            {
                // P25 frame interleaving matrix (simplified version)
                const int MATRIX_ROWS = 8;
                const int MATRIX_COLS = 32;
                
                var deinterleaved = new byte[frame.Length];
                var matrix = new byte[MATRIX_ROWS, MATRIX_COLS];
                
                // Fill the matrix
                int k = 0;
                for (int col = 0; col < MATRIX_COLS; col++)
                {
                    for (int row = 0; row < MATRIX_ROWS; row++)
                    {
                        if (k < frame.Length)
                            matrix[row, col] = frame[k++];
                    }
                }
                
                // Read out by rows
                k = 0;
                for (int row = 0; row < MATRIX_ROWS; row++)
                {
                    for (int col = 0; col < MATRIX_COLS; col++)
                    {
                        if (k < deinterleaved.Length)
                            deinterleaved[k++] = matrix[row, col];
                    }
                }
                
                return deinterleaved;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during frame deinterleaving");
                return Array.Empty<byte>();
            }
        }

        /// <summary>
        /// Applies Golay error correction to P25 frame data
        /// </summary>
        private byte[] ApplyErrorCorrection(byte[] frameData)
        {
            if (frameData == null || frameData.Length == 0)
                return Array.Empty<byte>();

            try
            {
                // Golay(23,12) error correction parameters
                const int CODEWORD_LENGTH = 23;
                const int MESSAGE_LENGTH = 12;
                
                var corrected = new byte[frameData.Length];
                Array.Copy(frameData, corrected, frameData.Length);
                
                // Process each Golay codeword in the frame
                for (int i = 0; i < frameData.Length - CODEWORD_LENGTH; i += CODEWORD_LENGTH)
                {
                    // Extract the codeword
                    var codeword = new byte[CODEWORD_LENGTH];
                    Array.Copy(frameData, i, codeword, 0, CODEWORD_LENGTH);
                    
                    // Apply Golay decoding (simplified)
                    var decoded = DecodeGolayCodeword(codeword);
                    
                    // Copy corrected data back
                    Array.Copy(decoded, 0, corrected, i, MESSAGE_LENGTH);
                }
                
                return corrected;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during error correction");
                return Array.Empty<byte>();
            }
        }

        /// <summary>
        /// Decodes a single Golay(23,12) codeword
        /// </summary>
        private byte[] DecodeGolayCodeword(byte[] codeword)
        {
            // Golay generator polynomial: x^11 + x^10 + x^6 + x^5 + x^4 + x^2 + 1
            const int GENERATOR = 0xAE3;
            
            // Extract message and parity bits
            int message = 0;
            int parity = 0;
            
            for (int i = 0; i < 12; i++)
                message |= ((codeword[i] & 1) << (11 - i));
                
            for (int i = 12; i < 23; i++)
                parity |= ((codeword[i] & 1) << (22 - i));
                
            // Compute syndrome
            int syndrome = message ^ (parity << 12);
            
            // Error correction (simplified)
            if (syndrome != 0)
            {
                // Single bit error correction
                message ^= (syndrome & 0xFFF);
            }
            
            // Return corrected message bits
            var result = new byte[12];
            for (int i = 0; i < 12; i++)
                result[i] = (byte)((message >> (11 - i)) & 1);
                
            return result;
        }

        /// <summary>
        /// Processes an IMBE voice frame and converts it to PCM audio
        /// </summary>
        private byte[] ProcessIMBEFrame(byte[] imbeFrame)
        {
            const int PCM_FRAME_SIZE = 160; // 20ms at 8kHz
            if (imbeFrame == null || imbeFrame.Length < 88) // IMBE frame should be 88 bits
                return new byte[PCM_FRAME_SIZE]; // Return silence if invalid

            try
            {
                // IMBE frame parameters
                int[] fundamentalFreq = new int[1];
                bool[] voicingDecisions = new bool[8];
                int[] spectralAmplitudes = new int[56];
                
                // Extract IMBE parameters from frame
                ExtractIMBEParameters(imbeFrame, fundamentalFreq, voicingDecisions, spectralAmplitudes);
                
                // Convert parameters to PCM samples
                return SynthesizeIMBEFrame(fundamentalFreq[0], voicingDecisions, spectralAmplitudes);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing IMBE frame");
                return new byte[PCM_FRAME_SIZE]; // Return silence on error
            }
        }

        /// <summary>
        /// Extracts IMBE voice parameters from a frame
        /// </summary>
        private void ExtractIMBEParameters(byte[] frame, int[] fundamentalFreq, bool[] voicingDecisions, int[] spectralAmplitudes)
        {
            // Extract fundamental frequency (7 bits)
            fundamentalFreq[0] = 0;
            for (int i = 0; i < 7; i++)
                fundamentalFreq[0] |= (frame[i] << (6 - i));
                
            // Extract voicing decisions (8 bits)
            for (int i = 0; i < 8; i++)
                voicingDecisions[i] = (frame[i + 7] != 0);
                
            // Extract spectral amplitudes (remaining bits)
            for (int i = 0; i < 56; i++)
            {
                int bitIndex = i + 15;
                if (bitIndex < frame.Length)
                    spectralAmplitudes[i] = frame[bitIndex];
            }
        }

        /// <summary>
        /// Synthesizes PCM audio from IMBE parameters
        /// </summary>
        private byte[] SynthesizeIMBEFrame(int fundamentalFreq, bool[] voicingDecisions, int[] spectralAmplitudes)
        {
            const int PCM_FRAME_SIZE = 160; // 20ms at 8kHz
            var pcmData = new byte[PCM_FRAME_SIZE];
            
            try
            {
                // Convert fundamental frequency to actual frequency in Hz
                float f0 = 100.0f + fundamentalFreq * 3.0f; // Typical IMBE range 100-400 Hz
                
                // Generate synthetic speech frame
                for (int i = 0; i < PCM_FRAME_SIZE / 2; i++)
                {
                    float sample = 0.0f;
                    
                    // Sum harmonics based on spectral amplitudes
                    for (int harmonic = 0; harmonic < spectralAmplitudes.Length; harmonic++)
                    {
                        if (voicingDecisions[harmonic / 7]) // Use voicing decision for this region
                        {
                            float freq = f0 * (harmonic + 1);
                            float amp = spectralAmplitudes[harmonic] / 256.0f;
                            float phase = (2 * (float)Math.PI * freq * i) / 8000.0f;
                            sample += amp * (float)Math.Sin(phase);
                        }
                    }
                    
                    // Convert to 16-bit PCM
                    short pcmSample = (short)(sample * 32767.0f);
                    pcmData[i * 2] = (byte)(pcmSample & 0xFF);
                    pcmData[i * 2 + 1] = (byte)((pcmSample >> 8) & 0xFF);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error synthesizing IMBE frame");
            }
            
            return pcmData;
        }

        /// <summary>
        /// Applies baseband filtering to IQ samples for P25 signal processing
        /// </summary>
        private Complex[] ApplyBasebandFilter(Complex[] iqData)
        {
            if (iqData == null || iqData.Length == 0)
                return Array.Empty<Complex>();

            try
            {
                // Root-raised cosine filter parameters
                const double BETA = 0.2; // Roll-off factor for P25
                const int TAPS = 51;  // Filter length
                
                var filtered = new Complex[iqData.Length];
                var coeffs = CalculateRRCFilterCoefficients(TAPS, BETA, SYMBOL_RATE, _sampleRate);
                
                // Apply the filter
                for (int i = 0; i < iqData.Length; i++)
                {
                    Complex sum = Complex.Zero;
                    
                    for (int j = 0; j < TAPS; j++)
                    {
                        if (i - j >= 0)
                            sum += iqData[i - j] * coeffs[j];
                    }
                    
                    filtered[i] = sum;
                }
                
                return filtered;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error applying baseband filter");
                return iqData; // Return original data on error
            }
        }

        /// <summary>
        /// Calculates Root-Raised Cosine filter coefficients
        /// </summary>
        private double[] CalculateRRCFilterCoefficients(int taps, double beta, double symbolRate, double sampleRate)
        {
            var coeffs = new double[taps];
            double T = sampleRate / symbolRate;
            int halfTaps = taps / 2;
            
            for (int i = 0; i < taps; i++)
            {
                int index = i - halfTaps;
                double t = index / T;
                
                if (Math.Abs(t) == 0)
                {
                    coeffs[i] = (1 - beta + (4 * beta / Math.PI)) / T;
                }
                else if (Math.Abs(t) == 1.0 / (4 * beta))
                {
                    double pi4bt = Math.PI * 4 * beta * t;
                    coeffs[i] = (beta / (T * Math.Sqrt(2))) * 
                        ((1 + 2/Math.PI) * Math.Sin(pi4bt) + 
                         (1 - 2/Math.PI) * Math.Cos(pi4bt));
                }
                else
                {
                    double numerator = Math.Sin(Math.PI * t * (1 - beta)) + 
                                     4 * beta * t * Math.Cos(Math.PI * t * (1 + beta));
                    double denominator = Math.PI * t * (1 - (4 * beta * t) * (4 * beta * t));
                    coeffs[i] = numerator / (T * denominator);
                }
            }
            
            // Normalize coefficients
            double sum = coeffs.Sum();
            for (int i = 0; i < taps; i++)
                coeffs[i] /= sum;
                
            return coeffs;
        }

        /// <summary>
        /// Improved frame synchronization detection using correlation
        /// </summary>
        private bool DetectFrameSync(Complex[] filteredData)
        {
            if (filteredData == null || filteredData.Length < SYNC_PATTERN_LENGTH * SAMPLES_PER_SYMBOL)
                return false;

            try
            {
                // Known P25 sync pattern (as complex symbols)
                var syncPattern = ConvertSyncPatternToSymbols(FRAME_SYNC_PATTERN);
                double maxCorrelation = 0;
                int bestOffset = 0;
                
                // Sliding correlation
                for (int offset = 0; offset < SAMPLES_PER_SYMBOL; offset++)
                {
                    double correlation = 0;
                    
                    for (int i = 0; i < syncPattern.Length; i++)
                    {
                        int sampleIdx = offset + i * SAMPLES_PER_SYMBOL;
                        if (sampleIdx < filteredData.Length)
                        {
                            correlation += Complex.Abs(
                                Complex.Conjugate(filteredData[sampleIdx]) * syncPattern[i]);
                        }
                    }
                    
                    if (correlation > maxCorrelation)
                    {
                        maxCorrelation = correlation;
                        bestOffset = offset;
                    }
                }
                
                // Calculate correlation threshold based on signal power
                double signalPower = filteredData.Take(SYNC_PATTERN_LENGTH * SAMPLES_PER_SYMBOL)
                    .Select(c => Complex.Abs(c))
                    .Average();
                    
                double threshold = signalPower * SYNC_PATTERN_LENGTH * 0.7; // 70% correlation threshold
                
                if (maxCorrelation > threshold)
                {
                    _symbolTimingOffset = bestOffset;
                    return true;
                }
                
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in frame sync detection");
                return false;
            }
        }

        /// <summary>
        /// Converts sync pattern bytes to complex symbols
        /// </summary>
        private Complex[] ConvertSyncPatternToSymbols(byte[] pattern)
        {
            // P25 uses 4-point constellation
            var symbols = new Complex[pattern.Length * 4];
            int symbolIdx = 0;
            
            foreach (byte b in pattern)
            {
                for (int i = 6; i >= 0; i -= 2)
                {
                    int dibits = (b >> i) & 0x03;
                    double phase = Math.PI * dibits / 2.0;
                    symbols[symbolIdx++] = Complex.FromPolarCoordinates(1.0, phase);
                }
            }
            
            return symbols;
        }

        private int ExtractNAC(Complex[] filteredData)
        {
            // Placeholder implementation of NAC extraction
            // In a real implementation, this would extract the 12-bit NAC from the frame
            
            // For this example, generate a random NAC in valid range (0x000 to 0xFFF)
            return new Random().Next(0, 0x1000);
        }

        private int ExtractTalkgroupId(Complex[] filteredData)
        {
            // Placeholder implementation of talkgroup ID extraction
            // In a real implementation, this would extract the talkgroup ID from the frame
            
            // For this example, generate a random talkgroup ID in common range
            return new Random().Next(1, 65535);
        }

        /// <summary>
        /// Extracts frame data from filtered IQ samples using symbol timing
        /// </summary>
        private byte[] ExtractFrameData(Complex[] filteredData, int timingOffset)
        {
            try
            {
                // Calculate number of symbols we can extract
                int numSymbols = (filteredData.Length - timingOffset) / SAMPLES_PER_SYMBOL;
                var frameData = new byte[numSymbols];
                
                // Extract symbols at the correct timing offset
                for (int i = 0; i < numSymbols; i++)
                {
                    int sampleIdx = timingOffset + (i * SAMPLES_PER_SYMBOL);
                    if (sampleIdx < filteredData.Length)
                    {
                        // Convert complex sample to symbol (4-point constellation)
                        Complex sample = filteredData[sampleIdx];
                        double phase = Math.Atan2(sample.Imaginary, sample.Real);
                        
                        // Normalize phase to 0-4 range and convert to symbol
                        phase = (phase + 2 * Math.PI) % (2 * Math.PI);
                        int symbol = (int)Math.Round(phase / (Math.PI / 2)) % 4;
                        frameData[i] = (byte)symbol;
                    }
                }
                
                return frameData;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error extracting frame data");
                return Array.Empty<byte>();
            }
        }

        /// <summary>
        /// Extracts IMBE voice frames from decoded P25 frame data
        /// </summary>
        private IEnumerable<byte[]> ExtractVoiceFrames(byte[] frameData)
        {
            const int IMBE_FRAME_SIZE = 88; // 88 bits per IMBE frame
            var voiceFrames = new List<byte[]>();
            
            try
            {
                // Skip header/metadata
                int offset = 72; // Typical offset to first voice frame
                
                // Extract each IMBE frame
                while (offset + IMBE_FRAME_SIZE <= frameData.Length)
                {
                    var imbeFrame = new byte[IMBE_FRAME_SIZE];
                    Array.Copy(frameData, offset, imbeFrame, 0, IMBE_FRAME_SIZE);
                    voiceFrames.Add(imbeFrame);
                    offset += IMBE_FRAME_SIZE;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error extracting voice frames");
            }
            
            return voiceFrames;
        }

using System;
using System.Collections.Generic;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;
using NAudio.Wave;
using Microsoft.Extensions.Logging;
using P25Scanner.Models;
using System.Linq;
using System.IO;
using System.Runtime.InteropServices;

namespace P25Scanner.Services
{
    /// <summary>
    /// Decoder service for Project 25 (P25) digital radio signals.
    /// Handles frame synchronization, symbol recovery, IMBE voice decoding,
    /// error correction, and audio output generation.
    /// </summary>
    public class P25Decoder : IDisposable
    {
        private readonly ILogger<P25Decoder> _logger;
        private readonly RtlSdrService _rtlSdrService;
        private readonly AudioService _audioService;
        
        private readonly Queue<Complex> _sampleBuffer = new();
        private readonly Queue<float> _audioBuffer = new();
        
        private const int SYMBOL_RATE = 4800; // P25 symbol rate
        private const int SAMPLES_PER_SYMBOL = 10; // Depends on sample rate
        private const int FRAME_SIZE = 1728; // P25 frame size in bits
        private const int SYNC_PATTERN_LENGTH = 48; // Bits in NID
        
        // P25 Common Air Interface (CAI) constants
        private static readonly byte[] FRAME_SYNC_PATTERN = { 
            0x5F, 0x7F, 0x7D, 0x5D, 0xD7, 0xFD, 0xDF, 0x7F, 0x5F, 0x7D
        };
        
        private bool _isRunning;
        private bool _isInitialized;
        private bool _disposedValue;
        private CancellationTokenSource _cancellationTokenSource;
        
        // IMBE vocoder parameters
        private const int IMBE_FRAME_SIZE = 88; // 88 bits per IMBE frame
        private const int AUDIO_SAMPLE_RATE = 8000; // Output sample rate

        /// <summary>
        /// Event raised when audio data is available after successful decoding
        /// </summary>
        public event EventHandler<AudioDataEventArgs> DecodedAudioAvailable;

        /// <summary>
        /// Event raised when a P25 message is decoded
        /// </summary>
        public event EventHandler<P25MessageEventArgs> MessageDecoded;

        /// <summary>
        /// Creates a new instance of the P25Decoder service
        /// </summary>
        /// <param name="logger">Logger for diagnostic information</param>
        /// <param name="rtlSdrService">RTL-SDR service for receiving IQ data</param>
        /// <param name="audioService">Audio service for playback</param>
        public P25Decoder(
            ILogger<P25Decoder> logger,
            RtlSdrService rtlSdrService,
            AudioService audioService)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _rtlSdrService = rtlSdrService ?? throw new ArgumentNullException(nameof(rtlSdrService));
            _audioService = audioService ?? throw new ArgumentNullException(nameof(audioService));
            
            _logger.LogInformation("P25Decoder service created");
        }

        /// <summary>
        /// Initializes the P25 decoder and sets up event handlers
        /// </summary>
        public void Initialize()
        {
            if (_isInitialized)
            {
                _logger.LogWarning("P25Decoder is already initialized");
                return;
            }

            try
            {
                _rtlSdrService.IQDataAvailable += OnIQDataAvailable;
                _rtlSdrService.DeviceStatusChanged += OnDeviceStatusChanged;
                
                _isInitialized = true;
                _logger.LogInformation("P25Decoder initialized successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to initialize P25Decoder");
                throw;
            }
        }

        /// <summary>
        /// Starts the P25 decoding process
        /// </summary>
        public async Task StartAsync()
        {
            if (!_isInitialized)
            {
                _logger.LogError("P25Decoder must be initialized before starting");
                throw new InvalidOperationException("P25Decoder not initialized");
            }

            if (_isRunning)
            {
                _logger.LogWarning("P25Decoder is already running");
                return;
            }

            _isRunning = true;
            _cancellationTokenSource = new CancellationTokenSource();
            
            try
            {
                _logger.LogInformation("Starting P25 decoder processing");
                
                // Run the processing loop in a background task
                await Task.Factory.StartNew(
                    ProcessingLoop, 
                    _cancellationTokenSource.Token,
                    TaskCreationOptions.LongRunning, 
                    TaskScheduler.Default);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error starting P25Decoder");
                _isRunning = false;
                throw;
            }
        }

        /// <summary>
        /// Stops the P25 decoding process
        /// </summary>
        public async Task StopAsync()
        {
            if (!_isRunning)
            {
                return;
            }

            try
            {
                _logger.LogInformation("Stopping P25 decoder processing");
                
                _cancellationTokenSource?.Cancel();
                _isRunning = false;
                
                // Clear buffers
                lock (_sampleBuffer)
                {
                    _sampleBuffer.Clear();
                }
                
                lock (_audioBuffer)
                {
                    _audioBuffer.Clear();
                }
                
                await Task.CompletedTask;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error stopping P25Decoder");
                throw;
            }
        }

        /// <summary>
        /// Handles IQ data from the RTL-SDR device
        /// </summary>
        private void OnIQDataAvailable(object sender, IQDataEventArgs e)
        {
            if (!_isRunning)
            {
                return;
            }

            try
            {
                // Add samples to the buffer for processing
                lock (_sampleBuffer)
                {
                    foreach (var sample in e.Samples)
                    {
                        _sampleBuffer.Enqueue(sample);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing IQ data in P25Decoder");
            }
        }

        /// <summary>
        /// Handles device status changes from the RTL-SDR device
        /// </summary>
        private void OnDeviceStatusChanged(object sender, DeviceStatusEventArgs e)
        {
            _logger.LogInformation("RTL-SDR device status changed: {Status}", e.Status);
            
            if (e.Status == DeviceStatus.Disconnected || e.Status == DeviceStatus.Error)
            {
                // Stop decoding if device is disconnected or has error
                _ = StopAsync();
            }
        }

        /// <summary>
        /// Main processing loop for P25 signal decoding
        /// </summary>
        private async Task ProcessingLoop()
        {
            _logger.LogDebug("P25 decoder processing loop started");
            
            try
            {
                while (!_cancellationTokenSource.Token.IsCancellationRequested)
                {
                    // Process available samples in buffer
                    if (_sampleBuffer.Count >= SAMPLES_PER_SYMBOL * SYNC_PATTERN_LENGTH)
                    {
                        // 1. Frame synchronization
                        var foundSync = FindFrameSync();
                        
                        if (foundSync)
                        {
                            // 2. Symbol timing recovery
                            var symbols = RecoverSymbols();
                            
                            // 3. IMBE voice frame decoding with error correction
                            var voiceFrames = DecodeVoiceFrames(symbols);
                            
                            if (voiceFrames != null && voiceFrames.Any())
                            {
                                // 4. Audio output generation
                                var audioSamples = GenerateAudio(voiceFrames);
                                
                                // 5. Add to audio buffer
                                lock (_audioBuffer)
                                {
                                    foreach (var sample in audioSamples)
                                    {
                                        _audioBuffer.Enqueue(sample);
                                    }
                                }
                                
                                // Raise event with decoded audio
                                OnDecodedAudioAvailable(audioSamples);
                            }
                        }
                    }
                    
                    // Avoid tight CPU loop
                    await Task.Delay(5, _cancellationTokenSource.Token);
                }
            }
            catch (OperationCanceledException)
            {
                _logger.LogInformation("P25 decoder processing loop was cancelled");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in P25 decoder processing loop");
            }
            
            _logger.LogDebug("P25 decoder processing loop ended");
        }

        /// <summary>
        /// Finds P25 frame synchronization pattern in the sample buffer
        /// </summary>
        /// <returns>True if sync pattern was found</returns>
        private bool FindFrameSync()
        {
            try
            {
                // Create a buffer for correlation
                var correlationBuffer = new double[FRAME_SYNC_PATTERN.Length * 8];
                var samples = new List<Complex>();
                
                // Get samples for correlation
                lock (_sampleBuffer)
                {
                    if (_sampleBuffer.Count < correlationBuffer.Length)
                    {
                        return false;
                    }
                    
                    for (int i = 0; i < correlationBuffer.Length; i++)
                    {
                        if (_sampleBuffer.Count > 0)
                        {
                            samples.Add(_sampleBuffer.Dequeue());
                        }
                    }
                }
                
                // Convert sync pattern bytes to expected signal values for correlation
                var syncPatternSignal = ConvertSyncPatternToSignal(FRAME_SYNC_PATTERN);
                
                // Perform correlation to find the sync pattern
                double maxCorrelation = 0;
                int maxCorrelationIndex = -1;
                
                for (int i = 0; i < samples.Count - syncPatternSignal.Length; i++)
                {
                    double correlation = 0;
                    
                    for (int j = 0; j < syncPatternSignal.Length; j++)
                    {
                        // Correlation using complex values
                        correlation += samples[i + j].Real * syncPatternSignal[j];
                    }
                    
                    if (correlation > maxCorrelation)
                    {
                        maxCorrelation = correlation;
                        maxCorrelationIndex = i;
                    }
                }
                
                // If correlation exceeds threshold, we found a sync
                bool foundSync = maxCorrelation > (syncPatternSignal.Length * 0.7); // 70% correlation threshold
                
                if (foundSync)
                {
                    _logger.LogDebug("P25 frame sync found at index {Index} with correlation {Correlation}", 
                        maxCorrelationIndex, maxCorrelation / syncPatternSignal.Length);
                    
                    // Remove samples up to the sync point
                    RemoveSamplesFromBuffer(maxCorrelationIndex);
                }
                
                return foundSync;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in FindFrameSync");
                return false;
            }
        }

        /// <summary>
        /// Converts the sync pattern bytes to expected signal values for correlation
        /// </summary>
        private double[] ConvertSyncPatternToSignal(byte[] syncPattern)
        {
            var result = new List<double>();
            
            foreach (byte b in syncPattern)
            {
                for (int i = 7; i >= 0; i--)
                {
                    bool bit = ((b >> i) & 0x01) == 1;
                    // Convert bit to signal value (1 -> 1.0, 0 -> -1.0)
                    result.Add(bit ? 1.0 : -1.0);
                }
            }
            
            return result.ToArray();
        }

        /// <summary>
        /// Removes samples from the beginning of the buffer
        /// </summary>
        private void RemoveSamplesFromBuffer(int count)
        {
            lock (_sampleBuffer)
            {
                for (int i = 0; i < count; i++)
                {
                    if (_sampleBuffer.Count > 0)
                    {
                        _sampleBuffer.Dequeue();
                    }
                }
            }
        }

        /// <summary>
        /// Recovers symbols from the sample buffer using symbol timing recovery
        /// </summary>
        /// <returns>List of recovered symbols</returns>
        private List<byte> RecoverSymbols()
        {
            var symbols = new List<byte>();
            
            try
            {
                // Get enough samples for a frame
                var samples = new List<Complex>();
                int requiredSamples = FRAME_SIZE * SAMPLES_PER_SYMBOL;
                
                lock (_sampleBuffer)
                {
                    if (_sampleBuffer.Count < requiredSamples)
                    {
                        return symbols;
                    }
                    
                    for (int i = 0; i < requiredSamples; i++)
                    {
                        if (_sampleBuffer.Count > 0)
                        {
                            samples.Add(_sampleBuffer.Dequeue());
                        }
                    }
                }
                
                // Gardner timing recovery algorithm
                for (int i = 0; i < samples.Count - SAMPLES_PER_SYMBOL; i += SAMPLES_PER_SYMBOL)
                {
                    // Take samples at middle of symbol period for best decision
                    int middleIndex = i + (SAMPLES_PER_SYMBOL / 2);
                    
                    if (middleIndex < samples.Count)
                    {
                        Complex sample = samples[middleIndex];
                        
                        // Simple QPSK demodulation
                        double phase = Math.Atan2(sample.Imaginary, sample.Real);
                        
                        // Convert phase to symbols (4 phases for QPSK)
                        byte symbol = PhaseToSymbol(phase);
                        symbols.Add(symbol);
                    }
                }
                
                _logger.LogTrace("Recovered {Count} symbols", symbols.Count);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in RecoverSymbols");
            }
            
            return symbols;
        }

        /// <summary>
        /// Converts phase angle to QPSK symbol
        /// </summary>
        private byte PhaseToSymbol(double phase)
        {
            // Normalize phase to 0-2π range
            phase = (phase + 2 * Math.PI) % (2 * Math.PI);
            
            //

using System;
using System.Collections.Generic;
using System.Numerics;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NAudio.Wave;
using P25Scanner.Models;

namespace P25Scanner.Services
{
    /// <summary>
    /// Represents the current status of the P25 decoder
    /// </summary>
    public enum DecoderStatus
    {
        /// <summary>
        /// Decoder is not initialized
        /// </summary>
        Uninitialized,

        /// <summary>
        /// Decoder is initialized but not running
        /// </summary>
        Initialized,

        /// <summary>
        /// Decoder is actively running and decoding
        /// </summary>
        Running,

        /// <summary>
        /// Decoder has been stopped
        /// </summary>
        Stopped,

        /// <summary>
        /// An error has occurred in the decoder
        /// </summary>
        Error,

        /// <summary>
        /// Decoder is receiving a signal
        /// </summary>
        ReceivingSignal,

        /// <summary>
        /// Decoder is processing audio
        /// </summary>
        ProcessingAudio
    }

    /// <summary>
    /// Event arguments for decoder status change events
    /// </summary>
    public class DecoderStatusEventArgs : EventArgs
    {
        /// <summary>
        /// Gets the new decoder status
        /// </summary>
        public DecoderStatus Status { get; }

        /// <summary>
        /// Gets additional status message (if any)
        /// </summary>
        public string Message { get; }

        /// <summary>
        /// Creates a new instance of DecoderStatusEventArgs
        /// </summary>
        /// <param name="status">The new decoder status</param>
        /// <param name="message">Optional status message</param>
        public DecoderStatusEventArgs(DecoderStatus status, string message = null)
        {
            Status = status;
            Message = message;
        }
    }

    /// <summary>
    /// Event arguments for talkgroup detection events
    /// </summary>
    public class TalkgroupEventArgs : EventArgs
    {
        /// <summary>
        /// Gets the detected talkgroup ID
        /// </summary>
        public int TalkgroupId { get; }

        /// <summary>
        /// Gets the timestamp when the talkgroup was detected
        /// </summary>
        public DateTime Timestamp { get; }

        /// <summary>
        /// Gets the system ID
        /// </summary>
        public int SystemId { get; }

        /// <summary>
        /// Gets the priority level of the talkgroup
        /// </summary>
        public int Priority { get; }

        /// <summary>
        /// Gets a value indicating whether the transmission is encrypted
        /// </summary>
        public bool IsEncrypted { get; }

        /// <summary>
        /// Gets the encryption type (if encrypted)
        /// </summary>
        public string EncryptionType { get; }

        /// <summary>
        /// Gets the signal quality in dB
        /// </summary>
        public float SignalQuality { get; }

        /// <summary>
        /// Creates a new instance of TalkgroupEventArgs
        /// </summary>
        /// <param name="talkgroupId">The detected talkgroup ID</param>
        /// <param name="timestamp">The timestamp of detection</param>
        /// <param name="systemId">The system ID</param>
        /// <param name="priority">The priority level</param>
        /// <param name="isEncrypted">Whether the transmission is encrypted</param>
        /// <param name="encryptionType">The encryption type (if applicable)</param>
        /// <param name="signalQuality">The signal quality in dB</param>
        public TalkgroupEventArgs(
            int talkgroupId, 
            DateTime timestamp, 
            int systemId = 0, 
            int priority = 0, 
            bool isEncrypted = false, 
            string encryptionType = null, 
            float signalQuality = 0.0f)
        {
            TalkgroupId = talkgroupId;
            Timestamp = timestamp;
            SystemId = systemId;
            Priority = priority;
            IsEncrypted = isEncrypted;
            EncryptionType = encryptionType;
            SignalQuality = signalQuality;
        }
    }
    /// <summary>
    /// Provides functionality for decoding P25 digital radio protocol signals from IQ data.
    /// </summary>
    public class P25Decoder : IDisposable
    {
        private readonly ILogger<P25Decoder> _logger;
        private bool _isInitialized = false;
        private bool _disposedValue;

        /// <summary>
        /// Initializes a new instance of the <see cref="P25Decoder"/> class.
        /// </summary>
        /// <param name="logger">The logger instance for this class.</param>
        public P25Decoder(ILogger<P25Decoder> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _logger.LogDebug("P25Decoder service constructed");
        }

        /// <summary>
        /// Event triggered when new audio data has been decoded from P25 signals.
        /// </summary>
        public event EventHandler<DecodedAudioEventArgs> DecodedAudioAvailable;

        /// <summary>
        /// Gets a value indicating whether the decoder is currently initialized and running.
        /// </summary>
        public bool IsInitialized => _isInitialized;

        /// <summary>
        /// Initializes the P25 decoder with necessary resources and settings.
        /// </summary>
        /// <param name="sampleRate">The sample rate of the incoming IQ data.</param>
        /// <param name="centerFrequency">The center frequency in Hz of the RTL-SDR tuner.</param>
        /// <returns>True if initialization was successful, otherwise false.</returns>
        public async Task<bool> Initialize(int sampleRate = 48000, long centerFrequency = 0)
        {
            if (_isInitialized)
            {
                _logger.LogWarning("P25Decoder already initialized");
                return true;
            }

            try
            {
                _logger.LogInformation("Initializing P25Decoder with sample rate: {SampleRate} Hz and center frequency: {CenterFrequency} Hz",
                    sampleRate, centerFrequency);

                // TODO: Initialize P25 decoding libraries, filters, and buffers
                await Task.Delay(100); // Simulating async initialization

                _isInitialized = true;
                _logger.LogInformation("P25Decoder initialized successfully");
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to initialize P25Decoder");
                _isInitialized = false;
                return false;
            }
        }

        /// <summary>
        /// Processes IQ data from RTL-SDR and attempts to decode P25 voice data.
        /// </summary>
        /// <param name="iqData">Array of complex IQ data samples.</param>
        /// <param name="length">The number of samples to process.</param>
        /// <returns>True if processing was successful, otherwise false.</returns>
        public bool ProcessIQData(Complex[] iqData, int length)
        {
            if (!_isInitialized)
            {
                _logger.LogWarning("Cannot process IQ data: P25Decoder not initialized");
                return false;
            }

            if (iqData == null)
            {
                _logger.LogError("IQ data array is null");
                return false;
            }

            try
            {
                _logger.LogDebug("Processing {Length} IQ samples", length);

                // TODO: Implement actual P25 decoding algorithm:
                // 1. Demodulate FM signal
                // 2. Extract P25 frame sync
                // 3. Perform symbol timing recovery
                // 4. Decode IMBE voice frames
                // 5. Convert to audio

                // Simulate decoded audio (for testing)
                if (DecodedAudioAvailable != null)
                {
                    var audioData = new byte[1024]; // Simulated decoded audio data
                    var waveFormat = new WaveFormat(8000, 16, 1); // Typical P25 audio format (8kHz, 16-bit, mono)
                    
                    DecodedAudioAvailable.Invoke(this, new DecodedAudioEventArgs(
                        audioData,
                        waveFormat,
                        DateTime.UtcNow,
                        false  // Not encrypted
                    ));
                }

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing IQ data");
                return false;
            }
        }

        /// <summary>
        /// Shuts down the P25 decoder and releases resources.
        /// </summary>
        public void Shutdown()
        {
            if (!_isInitialized)
            {
                _logger.LogWarning("P25Decoder already shut down");
                return;
            }

            try
            {
                _logger.LogInformation("Shutting down P25Decoder");
                
                // TODO: Release any resources, close filters, etc.
                
                _isInitialized = false;
                _logger.LogInformation("P25Decoder shut down successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during P25Decoder shutdown");
            }
        }

        /// <summary>
        /// Sets the frequency offset from the center frequency.
        /// </summary>
        /// <param name="offset">The offset in Hz.</param>
        /// <returns>True if successful, otherwise false.</returns>
        /// <summary>
        /// Sets the frequency offset from the center frequency.
        /// </summary>
        /// <param name="offset">The offset in Hz.</param>
        /// <returns>True if successful, otherwise false.</returns>
        public bool SetFrequencyOffset(int offset)
        {
            if (!_isInitialized)
            {
                _logger.LogWarning("Cannot set frequency offset: P25Decoder not initialized");
                return false;
            }

            try
            {
                _logger.LogInformation("Setting frequency offset to {Offset} Hz", offset);
                
                // TODO: Implement frequency offset in the decoding process
                
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error setting frequency offset");
                return false;
            }
        }

        /// <summary>
        /// Extracts a talkgroup ID from P25 frame data
        /// </summary>
        /// <param name="frameData">The P25 frame data containing talkgroup information</param>
        /// <returns>The extracted talkgroup ID, or 0 if none found</returns>
        private int ExtractTalkgroupId(byte[] frameData)
        {
            if (frameData == null || frameData.Length < 20)
            {
                _logger.LogWarning("Invalid frame data for talkgroup extraction");
                return 0;
            }

            try
            {
                // In real P25 frames, talkgroup ID is typically located in the header
                // This is a simplified implementation - real implementation would:
                // 1. Identify the frame type (HDU, LDU1, etc.)
                // 2. Extract the appropriate bits based on frame type
                // 3. Apply any necessary descrambling/error correction
                
                // For HDU (Header Data Unit) frames:
                // Talkgroup ID is typically 16 bits that need to be extracted from specific positions
                
                // Determine if this is a header frame (simplified check)
                bool isHeaderFrame = (frameData[0] & 0x3F) == 0x0F;
                
                if (isHeaderFrame)
                {
                    // Extract talkgroup ID from bytes 11-12 (hypothetical position)
                    // Real implementation would use proper bit extraction with error correction
                    if (frameData.Length >= 13)
                    {
                        int talkgroupId = (frameData[11] << 8) | frameData[12];
                        _logger.LogDebug("Extracted talkgroup ID: {TalkgroupId} from header frame", talkgroupId);
                        return talkgroupId;
                    }
                }
                else
                {
                    // For LDU (Logical Data Unit) frames:
                    // Extract from different position
                    if (frameData.Length >= 10)
                    {
                        int talkgroupId = (frameData[8] << 8) | frameData[9];
                        _logger.LogDebug("Extracted talkgroup ID: {TalkgroupId} from LDU frame", talkgroupId);
                        return talkgroupId;
                    }
                }
                
                return 0;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error extracting talkgroup ID");
                return 0;
            }
        }

        /// <summary>
        /// Extracts audio from P25 IMBE voice frames
        /// </summary>
        /// <param name="voiceFrameData">The P25 voice frame data containing IMBE encoded audio</param>
        /// <returns>Decoded audio samples as PCM data</returns>
        private byte[] ExtractAudio(byte[] voiceFrameData)
        {
            if (voiceFrameData == null || voiceFrameData.Length < 20)
            {
                _logger.LogWarning("Invalid voice frame data for audio extraction");
                return Array.Empty<byte>();
            }

            try
            {
                // In a real implementation, this would:
                // 1. Extract the IMBE parameters from the frame
                // 2. Use an IMBE vocoder to convert these parameters to PCM audio
                // 3. Apply error correction as needed
                
                // IMBE encoding uses specific parameters (pitch, voicing, gain, spectral amplitudes)
                // Each parameter is encoded in specific bit positions within the frame
                
                // This is a simplified placeholder implementation
                // In a real implementation, you would use a library like libimbe or equivalent
                
                // Create a dummy buffer of silence (for demo purposes)
                var audioBuffer = new byte[160]; // 20ms of 8kHz audio
                
                // In a real implementation, IMBE decoding would happen here
                _logger.LogTrace("Extracted {Length} bytes of audio from IMBE frame", audioBuffer.Length);
                
                return audioBuffer;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error extracting audio from IMBE frame");
                return Array.Empty<byte>();
            }
        }

        /// <summary>
        /// Calculates the signal power from IQ samples
        /// </summary>
        /// <param name="iqSamples">Complex IQ samples</param>
        /// <returns>Average signal power</returns>
        private float CalculateSignalPower(Complex[] iqSamples)
        {
            if (iqSamples == null || iqSamples.Length == 0)
            {
                return 0.0f;
            }

            try
            {
                float totalPower = 0.0f;
                
                // Calculate power for each sample and average
                for (int i = 0; i < iqSamples.Length; i++)
                    // Power = I^2 + Q^2 (magnitude squared)
                    float real = (float)iqSamples[i].Real;
                    float imag = (float)iqSamples[i].Imaginary;
                    totalPower += (real * real) + (imag * imag);
                    totalPower += (real * real) + (imag * imag);
                }
                
                // Return average power
                return totalPower / iqSamples.Length;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error calculating signal power");
                return 0.0f;
            }
        }

        /// <summary>
        /// Asynchronously raises the DecodedAudioAvailable event
        /// </summary>
        /// <param name="audioData">The decoded audio data</param>
        /// <param name="talkgroupId">The talkgroup ID associated with the audio</param>
        /// <returns>Task representing the asynchronous operation</returns>
        private async Task RaiseDecodedAudioAvailableAsync(byte[] audioData, int talkgroupId)
        {
            if (DecodedAudioAvailable == null)
            {
                return;
            }

            try
            {
                // Create wave format for standard P25 audio (8kHz, 16-bit, mono)
                var waveFormat = new WaveFormat(8000, 16, 1);
                
                // Create event args
                var args = new DecodedAudioEventArgs(
                    audioData,
                    waveFormat,
                    DateTime.UtcNow,
                    false // Not encrypted
                );
                
                // Raise event on ThreadPool to avoid blocking
                await Task.Run(() => DecodedAudioAvailable?.Invoke(this, args));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error raising DecodedAudioAvailable event");
            }
        }

        /// <summary>
        /// Asynchronously raises the TalkgroupDetected event
        /// </summary>
        /// <param name="talkgroupId">The detected talkgroup ID</param>
        /// <param name="systemId">The system ID (optional)</param>
        /// <param name="isEncrypted">Whether the transmission is encrypted (optional)</param>
        /// <returns>Task representing the asynchronous operation</returns>
        private async Task RaiseTalkgroupDetectedAsync(int talkgroupId, int systemId = 0, bool isEncrypted = false)
        {
            try
            {
                // Create event args
                var args = new TalkgroupEventArgs(
                    talkgroupId,
                    DateTime.UtcNow,
                    systemId,
                    0, // Default priority
                    isEncrypted,
                    isEncrypted ? "AES256" : null, // Example encryption type
                    CalculateSignalQuality() // Calculate current signal quality
                );
                
                // Raise event asynchronously
                await Task.Run(() => OnTalkgroupDetected(args));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error raising TalkgroupDetected event");
            }
        }

        /// <summary>
        /// Raises the TalkgroupDetected event
        /// </summary>
        /// <param name="e">Event arguments</param>
        protected virtual void OnTalkgroupDetected(TalkgroupEventArgs e)
        {
            EventHandler<TalkgroupEventArgs> handler = TalkgroupDetected;
            handler?.Invoke(this, e);
            
            _logger.LogInformation("Talkgroup detected: {TalkgroupId}, System: {SystemId}, Encrypted: {IsEncrypted}", 
                e.TalkgroupId, e.SystemId, e.IsEncrypted);
        }

        /// <summary>
        /// Calculates the current signal quality in dB
        /// </summary>
        /// <returns>Signal quality in dB</returns>
        private float CalculateSignalQuality()
        {
            // Simple placeholder implementation
            // In a real implementation, this would be based on actual signal measurements
            return -30.0f + (float)(new Random().NextDouble() * 20.0f);
        }

        /// <summary>
        /// Disposes the decoder resources
        /// </summary>
        /// <param name="disposing">True if disposing managed resources</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    if (_isInitialized)
                    {
                        Shutdown();
                    }
                    // Dispose managed state (managed objects)
                }

                // Free unmanaged resources (unmanaged objects) and override finalizer
                _disposedValue = true;
            }
        }

        /// <summary>
        /// Releases all resources used by the <see cref="P25Decoder"/>.
        /// </summary>
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }

    /// <summary>
    /// Event arguments containing decoded audio data from P25 signals.
    /// </summary>
    public class DecodedAudioEventArgs : EventArgs
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DecodedAudioEventArgs"/> class.
        /// </summary>
        /// <param name="audioData">The decoded audio data.</param>
        /// <param name="waveFormat">The wave format of the audio data.</param>
        /// <param name="timestamp">The timestamp when the audio was decoded.</param>
        /// <param name="isEncrypted">Whether the audio was encrypted.</param>
        public DecodedAudioEventArgs(byte[] audioData, WaveFormat waveFormat, DateTime timestamp, bool isEncrypted)
        {
            AudioData = audioData ?? throw new ArgumentNullException(nameof(audioData));
            WaveFormat = waveFormat ?? throw new ArgumentNullException(nameof(waveFormat));
            Timestamp = timestamp;
            IsEncrypted = isEncrypted;
        }

        /// <summary>
        /// Gets the decoded audio data.
        /// </summary>
        public byte[] AudioData { get; }

        /// <summary>
        /// Gets the wave format of the audio data.
        /// </summary>
        public WaveFormat WaveFormat { get; }

        /// <summary>
        /// Gets the timestamp when the audio was decoded.
        /// </summary>
        public DateTime Timestamp { get; }

        /// <summary>
        /// Gets a value indicating whether the audio was encrypted.
        /// </summary>
        public bool IsEncrypted { get; }
    }

}

