using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using P25Scanner.Configuration;

namespace P25Scanner.Services
{
    public class TalkgroupManager
    {
        private readonly ILogger<TalkgroupManager> _logger;
        private readonly AppConfig _config;
        private readonly Dictionary<int, TalkgroupInfo> _talkgroups;

        public class TalkgroupInfo
        {
            public int Id { get; set; }
            public string Description { get; set; }
            public bool Enabled { get; set; }
            public DateTime LastSeen { get; set; }
            public int Priority { get; set; }
            public string Agency { get; set; }
            public string Category { get; set; }
            public string Tag { get; set; }
        }

        public TalkgroupManager(ILogger<TalkgroupManager> logger, AppConfig config)
        {
            _logger = logger;
            _config = config;
            _talkgroups = new Dictionary<int, TalkgroupInfo>();
        }

        public async Task LoadTalkgroupsAsync()
        {
            var filePath = _config.Talkgroups.FiltersPath;
            if (!File.Exists(filePath))
                return;

            try
            {
                var json = await File.ReadAllTextAsync(filePath);
                var loadedTalkgroups = JsonSerializer.Deserialize<Dictionary<int, TalkgroupInfo>>(json);
                if (loadedTalkgroups != null)
                {
                    _talkgroups.Clear();
                    foreach (var tg in loadedTalkgroups)
                    {
                        _talkgroups[tg.Key] = tg.Value;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading talkgroups from {FilePath}", filePath);
            }
        }

        public async Task SaveTalkgroupsAsync()
        {
            if (!_config.Talkgroups.SaveFilters)
                return;

            try
            {
                var options = new JsonSerializerOptions
                {
                    WriteIndented = true
                };

                var json = JsonSerializer.Serialize(_talkgroups, options);
                await File.WriteAllTextAsync(_config.Talkgroups.FiltersPath, json);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error saving talkgroups to {FilePath}", _config.Talkgroups.FiltersPath);
            }
        }

        public void UpdateTalkgroup(int id, Action<TalkgroupInfo> updateAction)
        {
            if (!_talkgroups.TryGetValue(id, out var talkgroup))
            {
                talkgroup = new TalkgroupInfo
                {
                    Id = id,
                    Enabled = _config.Talkgroups.DefaultEnabled
                };
                _talkgroups[id] = talkgroup;
            }

            updateAction(talkgroup);
            talkgroup.LastSeen = DateTime.UtcNow;
        }

        public bool IsTalkgroupEnabled(int id)
        {
            return _talkgroups.TryGetValue(id, out var talkgroup) && talkgroup.Enabled;
        }

        public IEnumerable<TalkgroupInfo> GetAllTalkgroups()
        {
            return _talkgroups.Values;
        }

        public TalkgroupInfo GetTalkgroup(int id)
        {
            return _talkgroups.TryGetValue(id, out var talkgroup) ? talkgroup : null;
        }

        public void SetTalkgroupEnabled(int id, bool enabled)
        {
            UpdateTalkgroup(id, tg => tg.Enabled = enabled);
        }

        public void ImportTalkgroups(string csvPath)
        {
            try
            {
                using var reader = new StreamReader(csvPath);
                string line;
                // Skip header
                reader.ReadLine();

                while ((line = reader.ReadLine()) != null)
                {
                    var parts = line.Split(',');
                    if (parts.Length >= 4 && int.TryParse(parts[0], out int id))
                    {
                        UpdateTalkgroup(id, tg =>
                        {
                            tg.Description = parts[1].Trim();
                            tg.Agency = parts[2].Trim();
                            tg.Category = parts[3].Trim();
                            if (parts.Length > 4)
                                tg.Tag = parts[4].Trim();
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error importing talkgroups from CSV {FilePath}", csvPath);
                throw;
            }
        }
    }
}

