using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using P25Scanner.Exceptions;
using P25Scanner.Native;

namespace P25Scanner.Services
{
    /// <summary>
    /// Delegate for handling sample data from the RTL-SDR device
    /// </summary>
    /// <param name="samples">Array of I/Q samples</param>
    /// <param name="length">Length of the sample data</param>
    public delegate void SamplesAvailableEventHandler(byte[] samples, int length);

    /// <summary>
    /// Safe handle for RTL-SDR device pointers
    /// </summary>
    public class RtlSdrSafeHandle : SafeHandle
    {
        public RtlSdrSafeHandle() : base(IntPtr.Zero, true)
        {
        }

        public override bool IsInvalid => handle == IntPtr.Zero;

        protected override bool ReleaseHandle()
        {
            if (!IsInvalid)
            {
                RtlSdr.rtlsdr_close(handle);
                return true;
            }
            return false;
        }
    }

    /// <summary>
    /// Managed wrapper for RTL-SDR device
    /// </summary>
    public class RtlSdrDevice : IDisposable
    {
        private RtlSdrSafeHandle _deviceHandle;
        private bool _disposed;
        private bool _isStreaming;
        private CancellationTokenSource _cts;
        private Task _streamTask;
        private readonly object _lockObj = new object();
        private readonly byte[] _transferBuffer;
        
        /// <summary>
        /// Event fired when new samples are available from the device
        /// </summary>
        public event SamplesAvailableEventHandler SamplesAvailable;

        /// <summary>
        /// Gets a value indicating whether the device is currently streaming
        /// </summary>
        public bool IsStreaming 
        { 
            get 
            {
                lock (_lockObj)
                {
                    return _isStreaming;
                }
            }
            private set
            {
                lock (_lockObj)
                {
                    _isStreaming = value;
                }
            }
        }

        /// <summary>
        /// Gets the currently set sample rate in Hz
        /// </summary>
        public uint SampleRate { get; private set; }

        /// <summary>
        /// Gets the currently set frequency in Hz
        /// </summary>
        public uint Frequency { get; private set; }

        /// <summary>
        /// Gets the currently set gain in tenths of dB (0 for automatic)
        /// </summary>
        public int Gain { get; private set; }

        /// <summary>
        /// Gets the currently set PPM correction value
        /// </summary>
        public int PpmCorrection { get; private set; }

        /// <summary>
        /// Gets the number of devices connected to the system
        /// </summary>
        public static int DeviceCount
        {
            get
            {
                return RtlSdr.rtlsdr_get_device_count();
            }
        }

        /// <summary>
        /// Gets a list of all available RTL-SDR devices
        /// </summary>
        /// <returns>List of device names</returns>
        public static List<string> GetDeviceNames()
        {
            var count = DeviceCount;
            var names = new List<string>(count);
            
            for (var i = 0; i < count; i++)
            {
                names.Add(GetDeviceName(i));
            }
            
            return names;
        }

        /// <summary>
        /// Gets the name of the device at the specified index
        /// </summary>
        /// <param name="index">Device index</param>
        /// <returns>Device name</returns>
        public static string GetDeviceName(int index)
        {
            return Marshal.PtrToStringAnsi(RtlSdr.rtlsdr_get_device_name((uint)index));
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RtlSdrDevice"/> class
        /// </summary>
        /// <param name="deviceIndex">Index of the device to open (0-based)</param>
        /// <param name="bufferSize">Size of the transfer buffer in bytes</param>
        public RtlSdrDevice(int deviceIndex = 0, int bufferSize = 16 * 16384)
        {
            if (deviceIndex < 0 || deviceIndex >= DeviceCount)
            {
                throw new ArgumentOutOfRangeException(nameof(deviceIndex), "Device index is out of range");
            }

            _transferBuffer = new byte[bufferSize];
            _deviceHandle = new RtlSdrSafeHandle();
            
            var result = RtlSdr.rtlsdr_open(out var devicePtr, (uint)deviceIndex);
            _deviceHandle.SetHandle(devicePtr);
            
            if (result != 0)
            {
                throw new RtlSdrException("Failed to open RTL-SDR device", result);
            }

            // Initialize with default values
            SampleRate = 2048000;
            Frequency = 100000000;
            Gain = 0;
            PpmCorrection = 0;
            
            // Set default parameters
            SetSampleRate(SampleRate);
            SetCenterFrequency(Frequency);
            SetTunerGain(Gain);
            SetFrequencyCorrection(PpmCorrection);
        }

        /// <summary>
        /// Sets the sample rate for the device
        /// </summary>
        /// <param name="sampleRate">Sample rate in Hz (typically 2.4 MHz)</param>
        public void SetSampleRate(uint sampleRate)
        {
            ThrowIfDisposed();
            
            var result = RtlSdr.rtlsdr_set_sample_rate(_deviceHandle, sampleRate);
            if (result != 0)
            {
                throw new RtlSdrException("Failed to set sample rate", result);
            }
            
            SampleRate = sampleRate;
        }

        /// <summary>
        /// Sets the center frequency for the device
        /// </summary>
        /// <param name="frequency">Frequency in Hz</param>
        public void SetCenterFrequency(uint frequency)
        {
            ThrowIfDisposed();
            
            var result = RtlSdr.rtlsdr_set_center_freq(_deviceHandle, frequency);
            if (result != 0)
            {
                throw new RtlSdrException("Failed to set center frequency", result);
            }
            
            Frequency = frequency;
        }

        /// <summary>
        /// Sets the frequency correction value in PPM
        /// </summary>
        /// <param name="ppm">Frequency correction value in PPM</param>
        public void SetFrequencyCorrection(int ppm)
        {
            ThrowIfDisposed();
            
            var result = RtlSdr.rtlsdr_set_freq_correction(_deviceHandle, ppm);
            if (result != 0)
            {
                throw new RtlSdrException("Failed to set frequency correction", result);
            }
            
            PpmCorrection = ppm;
        }

        /// <summary>
        /// Gets a list of supported tuner gain values
        /// </summary>
        /// <returns>Array of supported gain values in tenths of dB</returns>
        public int[] GetTunerGains()
        {
            ThrowIfDisposed();
            
            var count = RtlSdr.rtlsdr_get_tuner_gains(_deviceHandle, null);
            if (count <= 0)
            {
                return Array.Empty<int>();
            }
            
            var gains = new int[count];
            RtlSdr.rtlsdr_get_tuner_gains(_deviceHandle, gains);
            return gains;
        }

        /// <summary>
        /// Enables or disables the automatic gain control
        /// </summary>
        /// <param name="enable">True to enable AGC, false to disable</param>
        public void SetAutoGain(bool enable)
        {
            ThrowIfDisposed();
            
            var result = RtlSdr.rtlsdr_set_tuner_gain_mode(_deviceHandle, enable ? 0 : 1);
            if (result != 0)
            {
                throw new RtlSdrException("Failed to set automatic gain control", result);
            }
            
            if (enable)
            {
                Gain = 0;
            }
        }

        /// <summary>
        /// Sets the tuner gain value
        /// </summary>
        /// <param name="gain">Gain value in tenths of dB</param>
        public void SetTunerGain(int gain)
        {
            ThrowIfDisposed();
            
            // First disable AGC
            SetAutoGain(false);
            
            var result = RtlSdr.rtlsdr_set_tuner_gain(_deviceHandle, gain);
            if (result != 0)
            {
                throw new RtlSdrException("Failed to set tuner gain", result);
            }
            
            Gain = gain;
        }

        /// <summary>
        /// Resets the device buffer
        /// </summary>
        public void ResetBuffer()
        {
            ThrowIfDisposed();
            
            var result = RtlSdr.rtlsdr_reset_buffer(_deviceHandle);
            if (result != 0)
            {
                throw new RtlSdrException("Failed to reset buffer", result);
            }
        }

        /// <summary>
        /// Starts asynchronous reading from the device
        /// </summary>
        /// <param name="cancellationToken">Cancellation token to stop reading</param>
        /// <returns>Task representing the asynchronous operation</returns>
        public Task StartReadingAsync(CancellationToken cancellationToken = default)
        {
            ThrowIfDisposed();
            
            if (IsStreaming)
            {
                throw new InvalidOperationException("Device is already streaming");
            }
            
            ResetBuffer();
            
            _cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            IsStreaming = true;
            
            _streamTask = Task.Run(() => ReadWorker(_cts.Token), _cts.Token);
            return Task.CompletedTask;
        }

        /// <summary>
        /// Stops asynchronous reading from the device
        /// </summary>
        /// <returns>Task representing the asynchronous operation</returns>
        public async Task StopReadingAsync()
        {
            if (!IsStreaming || _cts == null)
            {
                return;
            }
            
            try
            {
                _cts.Cancel();
                
                if (_streamTask != null)
                {
                    await _streamTask.ConfigureAwait(false);
                }
            }
            catch (OperationCanceledException)
            {
                // Expected when cancelling
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error stopping RTL-SDR stream: {ex.Message}");
            }
            finally
            {
                IsStreaming = false;
                _cts?.Dispose();
                _cts = null;
                _streamTask = null;
            }
        }

        /// <summary>
        /// Worker method for reading data from the device
        /// </summary>
        /// <param name="cancellationToken">Token to monitor for cancellation</param>
        private void ReadWorker(CancellationToken cancellationToken)
        {
            try
            {
                while (!cancellationToken.IsCancellationRequested)
                {
                    var result = RtlSdr.rtlsdr_read_sync(_deviceHandle, _transferBuffer, (uint)_transferBuffer.Length, out var samplesRead);
                    
                    if (result != 0)
                    {
                        throw new RtlSdrException("Error reading from RTL-SDR device", result);
                    }
                    
                    if (samplesRead > 0)
                    {
                        // Make a copy of the data to prevent it from being overwritten
                        var samples = new byte[samplesRead];
                        Array.Copy(_transferBuffer, samples, samplesRead);
                        
                        SamplesAvailable?.Invoke(samples, (int)samplesRead);
                    }
                    
                    // Check for cancellation after each read
                    cancellationToken.ThrowIfCancellationRequested();
                }
            }
            catch (OperationCanceledException)
            {
                // Expected when cancelling
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in RTL-SDR read worker: {ex.Message}");
            }
            finally
            {
                IsStreaming = false;
            }
        }

        /// <summary>
        /// Throws if the device has been disposed
        /// </summary>
        private void ThrowIfDisposed()
        {
            if (_disposed)
            {
                throw new ObjectDisposedException(nameof(RtlSdrDevice));
            }
        }

        #region IDisposable Implementation

        /// <summary>
        /// Disposes the device resources
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Disposes the device resources
        /// </summary>
        /// <param name="disposing">True if called from Dispose(), false if called from finalizer</param>
        protected virtual void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                // Stop any ongoing reading
                if (IsStreaming)
                {
                    StopReadingAsync().GetAwaiter().GetResult();
                }

                // Dispose managed resources
                _cts?.Dispose();
            }

            // Dispose unmanaged resources
            if (_deviceHandle != null && !_deviceHandle.IsInvalid)
            {
                _deviceHandle.Dispose();
                _deviceHandle = null;
            }

            _disposed = true;
        }

        /// <summary>
        /// Finalizer
        /// </summary>
        ~RtlSdrDevice()
        {
            Dispose(false);
        }

        #endregion
    }
}

