using System;
using System.Numerics;
using Microsoft.Extensions.Logging;

namespace P25Scanner.Services
{
    /// <summary>
    /// Provides signal quality metrics and optimization for P25 decoding
    /// </summary>
    internal class P25Metrics
    {
        private readonly ILogger _logger;
        
        // Signal quality thresholds
        private const float MIN_SNR_DB = 12.0f;
        private const float GOOD_SNR_DB = 20.0f;
        private const float MIN_SYNC_CORRELATION = 0.7f;
        private const float GOOD_SYNC_CORRELATION = 0.9f;
        
        // Metrics tracking
        private float _currentSNR;
        private float _avgSyncCorrelation;
        private int _syncLossCount;
        private int _biterrorRate;
        private int _frameCount;
        private DateTime _lastMetricsReset;
        
        // Frequency tracking
        private double _frequencyOffset;
        private float _clockError;
        
        public P25Metrics(ILogger logger)
        {
            _logger = logger;
            _lastMetricsReset = DateTime.UtcNow;
        }
        
        /// <summary>
        /// Calculates signal-to-noise ratio from complex samples
        /// </summary>
        public float CalculateSNR(Complex[] samples)
        {
            if (samples == null || samples.Length < 100)
                return float.MinValue;

            try
            {
                // Calculate signal and noise power
                float signalPower = 0;
                float noisePower = 0;
                
                // Use moving average to separate signal from noise
                int windowSize = 10;
                var movingAvg = new Complex[samples.Length];
                
                // Calculate moving average
                for (int i = 0; i < samples.Length; i++)
                {
                    Complex sum = Complex.Zero;
                    int count = 0;
                    
                    for (int j = Math.Max(0, i - windowSize); j < Math.Min(samples.Length, i + windowSize); j++)
                    {
                        sum += samples[j];
                        count++;
                    }
                    
                    movingAvg[i] = sum / count;
                    signalPower += (float)(movingAvg[i].Real * movingAvg[i].Real + 
                                         movingAvg[i].Imaginary * movingAvg[i].Imaginary);
                }
                
                // Calculate noise as difference from moving average
                for (int i = 0; i < samples.Length; i++)
                {
                    Complex noise = samples[i] - movingAvg[i];
                    noisePower += (float)(noise.Real * noise.Real + noise.Imaginary * noise.Imaginary);
                }
                
                signalPower /= samples.Length;
                noisePower /= samples.Length;
                
                // Calculate SNR in dB
                _currentSNR = 10.0f * (float)Math.Log10(signalPower / (noisePower + 1e-10));
                return _currentSNR;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error calculating SNR");
                return float.MinValue;
            }
        }
        
        /// <summary>
        /// Updates sync correlation metric
        /// </summary>
        public void UpdateSyncCorrelation(float correlation)
        {
            _avgSyncCorrelation = 0.9f * _avgSyncCorrelation + 0.1f * correlation;
            if (correlation < MIN_SYNC_CORRELATION)
            {
                _syncLossCount++;
            }
        }
        
        /// <summary>
        /// Updates bit error rate metric based on error correction results
        /// </summary>
        public void UpdateBitErrorRate(int correctedErrors, int totalBits)
        {
            if (totalBits > 0)
            {
                float instantBER = (float)correctedErrors / totalBits;
                _biterrorRate = (int)(100 * (0.9f * (_biterrorRate / 100.0f) + 0.1f * instantBER));
            }
            _frameCount++;
        }
        
        /// <summary>
        /// Estimates frequency offset from complex samples
        /// </summary>
        public double EstimateFrequencyOffset(Complex[] samples, double sampleRate)
        {
            try
            {
                // Use autocorrelation to estimate frequency offset
                int delay = 1;
                Complex correlation = Complex.Zero;
                
                for (int i = 0; i < samples.Length - delay; i++)
                {
                    correlation += Complex.Conjugate(samples[i]) * samples[i + delay];
                }
                
                _frequencyOffset = Math.Atan2(correlation.Imaginary, correlation.Real) * 
                                 sampleRate / (2 * Math.PI * delay);
                return _frequencyOffset;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error estimating frequency offset");
                return 0;
            }
        }
        
        /// <summary>
        /// Estimates clock error from symbol timing
        /// </summary>
        public float EstimateClockError(int symbolTimingOffset, int samplesPerSymbol)
        {
            float normalizedOffset = (float)symbolTimingOffset / samplesPerSymbol;
            _clockError = 0.9f * _clockError + 0.1f * normalizedOffset;
            return _clockError;
        }
        
        /// <summary>
        /// Gets current signal quality metrics
        /// </summary>
        public (float snr, float syncQuality, int ber, int syncLoss) GetMetrics()
        {
            return (_currentSNR, _avgSyncCorrelation, _biterrorRate, _syncLossCount);
        }
        
        /// <summary>
        /// Determines if signal quality is adequate for decoding
        /// </summary>
        public bool IsSignalQualityGood()
        {
            return _currentSNR >= MIN_SNR_DB && 
                   _avgSyncCorrelation >= MIN_SYNC_CORRELATION &&
                   _biterrorRate < 5;  // Less than 5% BER
        }
        
        /// <summary>
        /// Gets recommended radio parameters based on current metrics
        /// </summary>
        public (int gainAdjustment, int freqAdjustment) GetOptimizationParams()
        {
            int gainAdjust = 0;
            int freqAdjust = 0;
            
            // Adjust gain based on SNR
            if (_currentSNR < MIN_SNR_DB)
                gainAdjust = 2;  // Increase gain
            else if (_currentSNR > GOOD_SNR_DB + 5)
                gainAdjust = -1;  // Decrease gain
                
            // Adjust frequency based on offset
            if (Math.Abs(_frequencyOffset) > 100)
                freqAdjust = (int)Math.Round(_frequencyOffset);
                
            return (gainAdjust, freqAdjust);
        }
        
        /// <summary>
        /// Resets metrics
        /// </summary>
        public void Reset()
        {
            _currentSNR = 0;
            _avgSyncCorrelation = 0;
            _syncLossCount = 0;
            _biterrorRate = 0;
            _frameCount = 0;
            _frequencyOffset = 0;
            _clockError = 0;
            _lastMetricsReset = DateTime.UtcNow;
        }
        
        /// <summary>
        /// Logs current metrics
        /// </summary>
        public void LogMetrics()
        {
            var timeSinceReset = DateTime.UtcNow - _lastMetricsReset;
            _logger.LogInformation(
                "P25 Metrics - SNR: {SNR:F1}dB, Sync: {Sync:F2}, BER: {BER}%, " +
                "Sync Loss: {SyncLoss}, Frames: {Frames}, " +
                "Freq Offset: {FreqOffset:F0}Hz, Clock Error: {ClockError:F3}, " +
                "Duration: {Duration:hh\\:mm\\:ss}",
                _currentSNR,
                _avgSyncCorrelation,
                _biterrorRate,
                _syncLossCount,
                _frameCount,
                _frequencyOffset,
                _clockError,
                timeSinceReset);
        }
    }
}

