using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NAudio.Wave;
using NAudio.Wave.SampleProviders;

namespace P25Scanner.Services
{
    /// <summary>
    /// Service responsible for managing audio output from decoded P25 signals
    /// </summary>
    public class AudioService : IDisposable
    {
        private readonly ILogger<AudioService> _logger;
        private IWavePlayer _waveOut;
        private BufferedWaveProvider _bufferedWaveProvider;
        private SampleRateConverter _sampleRateConverter;
        private VolumeSampleProvider _volumeProvider;
        private int _outputSampleRate = 48000; // Default sample rate
        private int _inputSampleRate = 8000;   // Default P25 sample rate
        private float _volume = 1.0f;
        private bool _isMuted;
        private readonly object _lockObject = new object();
        private bool _isDisposed;
        private CancellationTokenSource _bufferUnderrunCts;

        /// <summary>
        /// Gets or sets the output sample rate in Hz (default: 48000)
        /// </summary>
        public int OutputSampleRate
        {
            get => _outputSampleRate;
            set
            {
                if (value != _outputSampleRate)
                {
                    _outputSampleRate = value;
                    ResetAudioChain();
                }
            }
        }

        /// <summary>
        /// Gets or sets the input sample rate in Hz (default: 8000)
        /// </summary>
        public int InputSampleRate
        {
            get => _inputSampleRate;
            set
            {
                if (value != _inputSampleRate)
                {
                    _inputSampleRate = value;
                    UpdateSampleRateConverter();
                }
            }
        }

        /// <summary>
        /// Gets or sets the audio playback volume (0.0 to 1.0)
        /// </summary>
        public float Volume
        {
            get => _volume;
            set
            {
                _volume = Math.Clamp(value, 0.0f, 1.0f);
                if (_volumeProvider != null)
                {
                    _volumeProvider.Volume = _isMuted ? 0.0f : _volume;
                }
            }
        }

        /// <summary>
        /// Gets or sets whether audio is muted
        /// </summary>
        public bool IsMuted
        {
            get => _isMuted;
            set
            {
                _isMuted = value;
                if (_volumeProvider != null)
                {
                    _volumeProvider.Volume = _isMuted ? 0.0f : _volume;
                }
            }
        }

        /// <summary>
        /// Gets a list of available audio output devices
        /// </summary>
        public List<AudioDeviceInfo> AvailableOutputDevices
        {
            get
            {
                var devices = new List<AudioDeviceInfo>();
                for (int i = -1; i < WaveOut.DeviceCount; i++)
                {
                    var capabilities = i == -1 ? new WaveOutCapabilities() : WaveOut.GetCapabilities(i);
                    string name = i == -1 ? "Default Output Device" : capabilities.ProductName;
                    devices.Add(new AudioDeviceInfo(i, name));
                }
                return devices;
            }
        }

        /// <summary>
        /// Event triggered when buffer underrun occurs
        /// </summary>
        public event EventHandler BufferUnderrun;

        /// <summary>
        /// Event triggered when playback stops
        /// </summary>
        public event EventHandler PlaybackStopped;

        /// <summary>
        /// Creates a new instance of the AudioService
        /// </summary>
        /// <param name="logger">The logger instance</param>
        public AudioService(ILogger<AudioService> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _logger.LogInformation("Initializing AudioService");
        }

        /// <summary>
        /// Initializes the audio output device
        /// </summary>
        /// <param name="deviceNumber">The device number to use (-1 for default)</param>
        /// <returns>True if initialization succeeded, false otherwise</returns>
        public bool Initialize(int deviceNumber = -1)
        {
            try
            {
                // Clean up any existing resources
                DisposeWaveOut();

                _logger.LogInformation("Initializing audio output device {DeviceNumber}", deviceNumber);
                
                // Create a new WaveOut instance
                _waveOut = new WaveOutEvent
                {
                    DeviceNumber = deviceNumber,
                    DesiredLatency = 100 // Lower latency for real-time audio
                };
                _waveOut.PlaybackStopped += WaveOut_PlaybackStopped;

                // Create the audio chain with the buffer
                ResetAudioChain();
                
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to initialize audio output device {DeviceNumber}", deviceNumber);
                return false;
            }
        }

        /// <summary>
        /// Adds audio samples to the buffer for playback
        /// </summary>
        /// <param name="samples">The PCM audio samples to play</param>
        /// <param name="offset">The offset in the samples array</param>
        /// <param name="count">The number of samples to add</param>
        public void AddSamples(byte[] samples, int offset, int count)
        {
            if (_isDisposed || _bufferedWaveProvider == null)
            {
                return;
            }

            try
            {
                lock (_lockObject)
                {
                    // Add samples to buffer
                    _bufferedWaveProvider.AddSamples(samples, offset, count);
                    
                    // Start playback if not already playing
                    if (_waveOut.PlaybackState != PlaybackState.Playing)
                    {
                        _logger.LogDebug("Starting audio playback");
                        _waveOut.Play();
                    }

                    // Monitor for buffer underruns
                    MonitorBufferUnderrun();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding samples to audio buffer");
            }
        }

        /// <summary>
        /// Stops audio playback
        /// </summary>
        public void Stop()
        {
            if (_isDisposed || _waveOut == null)
            {
                return;
            }

            try
            {
                _logger.LogDebug("Stopping audio playback");
                _waveOut.Stop();
                
                if (_bufferedWaveProvider != null)
                {
                    _bufferedWaveProvider.ClearBuffer();
                }

                // Cancel any underrun monitoring
                _bufferUnderrunCts?.Cancel();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error stopping audio playback");
            }
        }

        /// <summary>
        /// Pauses audio playback
        /// </summary>
        public void Pause()
        {
            if (_isDisposed || _waveOut == null)
            {
                return;
            }

            try
            {
                if (_waveOut.PlaybackState == PlaybackState.Playing)
                {
                    _logger.LogDebug("Pausing audio playback");
                    _waveOut.Pause();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error pausing audio playback");
            }
        }

        /// <summary>
        /// Resumes audio playback after pausing
        /// </summary>
        public void Resume()
        {
            if (_isDisposed || _waveOut == null)
            {
                return;
            }

            try
            {
                if (_waveOut.PlaybackState == PlaybackState.Paused)
                {
                    _logger.LogDebug("Resuming audio playback");
                    _waveOut.Play();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error resuming audio playback");
            }
        }

        /// <summary>
        /// Clears all audio samples from the buffer
        /// </summary>
        public void ClearBuffer()
        {
            if (_isDisposed || _bufferedWaveProvider == null)
            {
                return;
            }

            try
            {
                _bufferedWaveProvider.ClearBuffer();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error clearing audio buffer");
            }
        }

        /// <summary>
        /// Disposes the AudioService and frees all resources
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Protected implementation of Dispose pattern
        /// </summary>
        /// <param name="disposing">True if called from Dispose(), false if called from finalizer</param>
        protected virtual void Dispose(bool disposing)
        {
            if (_isDisposed)
                return;

            if (disposing)
            {
                _logger.LogInformation("Disposing AudioService");
                
                // Stop playback and release managed resources
                DisposeWaveOut();
                _bufferUnderrunCts?.Cancel();
                _bufferUnderrunCts?.Dispose();
                _bufferUnderrunCts = null;
            }

            _isDisposed = true;
        }

        private void ResetAudioChain()
        {
            try
            {
                lock (_lockObject)
                {
                    bool wasPlaying = _waveOut?.PlaybackState == PlaybackState.Playing;
                    
                    if (wasPlaying)
                    {
                        _waveOut.Stop();
                    }

                    // Create buffered wave provider with appropriate format
                    _bufferedWaveProvider = new BufferedWaveProvider(new WaveFormat(_inputSampleRate, 16, 1))
                    {
                        DiscardOnBufferOverflow = true,
                        BufferDuration = TimeSpan.FromSeconds(1) // Buffer up to 1 second of audio
                    };

                    // Set up sample rate conversion if needed
                    UpdateSampleRateConverter();

                    if (wasPlaying)
                    {
                        _waveOut.Play();
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error resetting audio chain");
            }
        }

        private void UpdateSampleRateConverter()
        {
            if (_bufferedWaveProvider == null)
                return;

            try
            {
                IWaveProvider provider = _bufferedWaveProvider;

                // Apply sample rate conversion if needed
                if (_inputSampleRate != _outputSampleRate)
                {
                    _logger.LogDebug("Setting up sample rate conversion from {InputRate}Hz to {OutputRate}Hz",
                        _inputSampleRate, _outputSampleRate);
                    
                    var inputFormat = _bufferedWaveProvider.WaveFormat;
                    
                    // Convert to sample provider for processing
                    var inputProvider = new SampleProviderConverterBase(provider);
                    
                    // Apply sample rate conversion
                    _sampleRateConverter = new SampleRateConverter(
                        inputProvider,
                        _outputSampleRate);
                    
                    // Set up volume control after rate conversion
                    _volumeProvider = new VolumeSampleProvider(_sampleRateConverter)
                    {
                        Volume = _isMuted ? 0.0f : _volume
                    };
                    
                    // Convert back to wave provider for output
                    provider = _volumeProvider.ToWaveProvider();
                }
                else
                {
                    // No sample rate conversion needed, just add volume control
                    var inputProvider = new SampleProviderConverterBase(provider);
                    _volumeProvider = new VolumeSampleProvider(inputProvider)
                    {
                        Volume = _isMuted ? 0.0f : _volume
                    };
                    provider = _volumeProvider.ToWaveProvider();
                }

                // Initialize WaveOut with the final provider
                if (_waveOut != null)
                {
                    _waveOut.Init(provider);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating sample rate converter");
            }
        }

        private void WaveOut_PlaybackStopped(object sender, StoppedEventArgs e)
        {
            try
            {
                if (e.Exception != null)
                {
                    _logger.LogError(e.Exception, "Audio playback stopped due to error");
                }
                else
                {
                    _logger.LogDebug("Audio playback stopped");
                }

                PlaybackStopped?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in PlaybackStopped event handler");
            }
        }

        private void DisposeWaveOut()
        {
            if (_waveOut != null)
            {
                try
                {
                    _waveOut.PlaybackStopped -= WaveOut_PlaybackStopped;
                    
                    if (_waveOut.PlaybackState != PlaybackState.Stopped)
                    {
                        _waveOut.Stop();
                    }
                    
                    _waveOut.Dispose();
                    _waveOut = null;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error disposing WaveOut");
                }
            }
        }

        private async void MonitorBufferUnderrun()
        {
            // Cancel any existing monitoring task
            _bufferUnderrunCts?.Cancel();
            _bufferUnderrunCts?.Dispose();
            _bufferUnderrunCts = new CancellationTokenSource();
            
            var token = _bufferUnderrunCts.Token;
            
            try
            {
                // Wait a bit to ensure buffer has time to fill
                await Task.Delay(50, token);
                
                // If buffer is critically low and playback is active, trigger underrun event
                if (!token.IsCancellationRequested && 
                    _bufferedWaveProvider != null && 
                    _waveOut?.PlaybackState == PlaybackState.Playing &&
                    _bufferedWaveProvider.BufferedBytes < _bufferedWaveProvider.WaveFormat.AverageBytesPerSecond / 20)
                {
                    _logger.LogWarning("Audio buffer underrun detected");
                    BufferUnderrun?.Invoke(this, EventArgs.Empty);
                }
            }
            catch (OperationCanceledException)
            {
                // Task was canceled, which is normal
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error monitoring buffer underrun");
            }
        }
    }

    /// <summary>
    /// Represents an audio output device
    /// </summary>
    public class AudioDeviceInfo
    {
        /// <summary>
        /// Gets the device ID
        /// </summary>
        public int DeviceNumber { get; }
        
        /// <summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using NAudio.Wave;
using NAudio.CoreAudioApi;
using System.IO;
using System.Collections.Concurrent;
using System.Diagnostics;

namespace P25Scanner.Services
{
    /// <summary>
    /// Service for handling audio output, buffering, device selection, and integration with P25Decoder
    /// </summary>
    public class AudioService : IDisposable
    {
        #region Fields

        private readonly ConcurrentDictionary<string, AudioOutputDevice> _audioOutputs = new();
        private readonly ConcurrentDictionary<string, BufferedWaveProvider> _audioBuffers = new();
        private readonly int _defaultSampleRate = 8000; // Standard sample rate for voice
        private readonly int _defaultChannels = 1; // Mono
        private readonly int _defaultBitDepth = 16; // 16-bit PCM
        private float _masterVolume = 1.0f;
        private string _defaultDeviceId;
        private bool _muted;
        private readonly SemaphoreSlim _bufferSemaphore = new(1, 1);
        private bool _disposed;

        #endregion

        #region Events

        /// <summary>
        /// Raised when audio playback starts
        /// </summary>
        public event EventHandler<AudioPlaybackEventArgs> PlaybackStarted;

        /// <summary>
        /// Raised when audio playback stops
        /// </summary>
        public event EventHandler<AudioPlaybackEventArgs> PlaybackStopped;

        /// <summary>
        /// Raised when an audio error occurs
        /// </summary>
        public event EventHandler<AudioErrorEventArgs> AudioError;

        /// <summary>
        /// Raised when the buffer level changes significantly
        /// </summary>
        public event EventHandler<BufferLevelEventArgs> BufferLevelChanged;

        /// <summary>
        /// Raised when audio devices change
        /// </summary>
        public event EventHandler<AudioDeviceChangeEventArgs> AudioDevicesChanged;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the master volume level (0.0 to 1.0)
        /// </summary>
        public float MasterVolume
        {
            get => _masterVolume;
            set
            {
                if (value < 0.0f || value > 1.0f)
                    throw new ArgumentOutOfRangeException(nameof(value), "Volume must be between 0.0 and 1.0");

                _masterVolume = value;
                
                // Update volume for all active outputs
                foreach (var output in _audioOutputs.Values)
                {
                    if (output.VolumeProvider != null)
                    {
                        output.VolumeProvider.Volume = _muted ? 0.0f : _masterVolume;
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets whether audio is muted
        /// </summary>
        public bool Muted
        {
            get => _muted;
            set
            {
                _muted = value;
                
                // Update volume for all active outputs
                foreach (var output in _audioOutputs.Values)
                {
                    if (output.VolumeProvider != null)
                    {
                        output.VolumeProvider.Volume = _muted ? 0.0f : _masterVolume;
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets the default audio device ID
        /// </summary>
        public string DefaultDeviceId
        {
            get => _defaultDeviceId;
            set
            {
                if (_defaultDeviceId == value) return;
                
                _defaultDeviceId = value;
                
                // If there are active streams, consider restarting them on the new device
                RestartDefaultDeviceStreams();
            }
        }

        /// <summary>
        /// Gets all available audio output devices
        /// </summary>
        public List<AudioDeviceInfo> AvailableDevices => GetAudioDevices();

        #endregion

        #region Constructor and Initialization

        /// <summary>
        /// Initializes a new instance of the AudioService class
        /// </summary>
        public AudioService()
        {
            // Set default device
            var devices = GetAudioDevices();
            if (devices.Count > 0)
            {
                _defaultDeviceId = devices.FirstOrDefault(d => d.IsDefault)?.Id ?? devices[0].Id;
            }

            // Register for device notification events
            RegisterForDeviceNotifications();
        }

        private void RegisterForDeviceNotifications()
        {
            // NAudio doesn't provide a direct event for device changes
            // In a real implementation, you might want to poll or use MMDeviceNotificationClient
            // This is a simplified approach
            Task.Run(async () =>
            {
                var lastDeviceCount = GetAudioDevices().Count;
                
                while (!_disposed)
                {
                    await Task.Delay(5000); // Check every 5 seconds
                    
                    if (_disposed) break;
                    
                    var currentDevices = GetAudioDevices();
                    if (currentDevices.Count != lastDeviceCount)
                    {
                        lastDeviceCount = currentDevices.Count;
                        AudioDevicesChanged?.Invoke(this, new AudioDeviceChangeEventArgs(currentDevices));
                    }
                }
            });
        }

        #endregion

        #region Audio Device Management

        /// <summary>
        /// Gets a list of available audio output devices
        /// </summary>
        /// <returns>List of audio device information</returns>
        public List<AudioDeviceInfo> GetAudioDevices()
        {
            var devices = new List<AudioDeviceInfo>();
            
            try
            {
                using var enumerator = new MMDeviceEnumerator();
                var defaultDevice = enumerator.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia);
                
                foreach (var device in enumerator.EnumerateAudioEndPoints(DataFlow.Render, DeviceState.Active))
                {
                    devices.Add(new AudioDeviceInfo
                    {
                        Id = device.ID,
                        Name = device.FriendlyName,
                        IsDefault = device.ID == defaultDevice.ID
                    });
                }
            }
            catch (Exception ex)
            {
                RaiseAudioError($"Error enumerating audio devices: {ex.Message}", ex);
            }
            
            return devices;
        }

        /// <summary>
        /// Gets information about a specific audio device
        /// </summary>
        /// <param name="deviceId">Device ID to get information for</param>
        /// <returns>Audio device information or null if not found</returns>
        public AudioDeviceInfo GetDeviceInfo(string deviceId)
        {
            try
            {
                using var enumerator = new MMDeviceEnumerator();
                using var defaultDevice = enumerator.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia);
                
                using var device = enumerator.GetDevice(deviceId);
                return new AudioDeviceInfo
                {
                    Id = device.ID,
                    Name = device.FriendlyName,
                    IsDefault = device.ID == defaultDevice.ID
                };
            }
            catch (Exception ex)
            {
                RaiseAudioError($"Error getting device info: {ex.Message}", ex);
                return null;
            }
        }

        #endregion

        #region Audio Output Management

        /// <summary>
        /// Creates a new audio output stream for a specified stream ID
        /// </summary>
        /// <param name="streamId">Unique identifier for the audio stream</param>
        /// <param name="deviceId">ID of the device to use, or null for default</param>
        /// <param name="sampleRate">Sample rate (default 8000Hz)</param>
        /// <param name="channels">Number of channels (default 1 - mono)</param>
        /// <returns>True if successful, false otherwise</returns>
        public bool CreateAudioStream(string streamId, string deviceId = null, int sampleRate = 0, int channels = 0)
        {
            if (string.IsNullOrEmpty(streamId))
                throw new ArgumentNullException(nameof(streamId));

            try
            {
                // Use provided values or defaults
                sampleRate = sampleRate > 0 ? sampleRate : _defaultSampleRate;
                channels = channels > 0 ? channels : _defaultChannels;
                deviceId = deviceId ?? _defaultDeviceId;

                // Check if we already have this stream
                if (_audioOutputs.ContainsKey(streamId))
                {
                    // Already exists, just return success
                    return true;
                }

                // Create a new wave format
                var waveFormat = new WaveFormat(sampleRate, _defaultBitDepth, channels);

                // Create buffer provider
                var bufferProvider = new BufferedWaveProvider(waveFormat);
                bufferProvider.DiscardOnBufferOverflow = true;
                bufferProvider.BufferDuration = TimeSpan.FromSeconds(5); // 5 seconds buffer
                
                _audioBuffers[streamId] = bufferProvider;

                // Create volume provider
                var volumeProvider = new VolumeWaveProvider16(bufferProvider);
                volumeProvider.Volume = _muted ? 0.0f : _masterVolume;

                // Create output device
                var device = new WaveOutEvent();
                device.DeviceNumber = GetDeviceNumber(deviceId);
                
                // Subscribe to playback ended
                device.PlaybackStopped += (s, e) => 
                {
                    PlaybackStopped?.Invoke(this, new AudioPlaybackEventArgs 
                    { 
                        StreamId = streamId, 
                        DeviceId = deviceId 
                    });
                };

                // Initialize playback
                device.Init(volumeProvider);
                device.Play();

                // Create output device tracking
                var outputDevice = new AudioOutputDevice
                {
                    DeviceId = deviceId,
                    WaveOut = device,
                    WaveFormat = waveFormat,
                    VolumeProvider = volumeProvider,
                    StreamId = streamId
                };

                // Store the output
                _audioOutputs[streamId] = outputDevice;

                // Raise event
                PlaybackStarted?.Invoke(this, new AudioPlaybackEventArgs
                {
                    StreamId = streamId,
                    DeviceId = deviceId
                });

                // Start buffer level monitoring
                StartBufferMonitoring(streamId);

                return true;
            }
            catch (Exception ex)
            {
                RaiseAudioError($"Error creating audio stream {streamId}: {ex.Message}", ex);
                return false;
            }
        }

        /// <summary>
        /// Closes an active audio stream
        /// </summary>
        /// <param name="streamId">ID of the stream to close</param>
        public void CloseAudioStream(string streamId)
        {
            if (string.IsNullOrEmpty(streamId))
                return;

            try
            {
                if (_audioOutputs.TryRemove(streamId, out var device))
                {
                    device.WaveOut.Stop();
                    device.WaveOut.Dispose();
                }

                _audioBuffers.TryRemove(streamId, out _);
            }
            catch (Exception ex)
            {
                RaiseAudioError($"Error closing audio stream {streamId}: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Writes audio data to the specified stream's buffer
        /// </summary>
        /// <param name="streamId">ID of the stream to write to</param>
        /// <param name="buffer">Audio data buffer</param>
        /// <param name="offset">Offset in the buffer to start from</param>
        /// <param name="count">Number of bytes to write</param>
        /// <returns>True if successful, false otherwise</returns>
        public async Task<bool> WriteAudioDataAsync(string streamId, byte[] buffer, int offset, int count)
        {
            if (string.IsNullOrEmpty(streamId) || buffer == null || count <= 0)
                return false;

            try
            {
                // Ensure we don't have multiple threads writing to buffers simultaneously
                await _bufferSemaphore.WaitAsync();
                
                try
                {
                    if (!_audioBuffers.TryGetValue(streamId, out var bufferProvider))
                    {
                        // Create stream if it doesn't exist
                        if (!CreateAudioStream(streamId))
                            return false;
                            
                        if (!_audioBuffers.TryGetValue(streamId, out bufferProvider))
                            return false;
                    }

                    // Add data to buffer
                    bufferProvider.AddSamples(buffer, offset, count);
                    return true;
                }
                finally
                {
                    _bufferSemaphore.Release();
                }
            }
            catch (Exception ex)
            {
                RaiseAudioError($"Error writing audio data to stream {streamId}: {ex.Message}", ex);
                return false;
            }
        }

        /// <summary>
        /// Sets the volume for a specific audio stream
        /// </summary>
        /// <param name="streamId">ID of the stream</param>
        /// <param name="volume">Volume level (0.0 to 1.0)</param>
        public void SetStreamVolume(string streamId, float volume)
        {
            if (string.IsNullOrEmpty(streamId))
                return;

            if (volume < 0.0f || volume > 1.0f)
                throw new ArgumentOutOfRangeException(nameof(volume), "Volume must be between 0.0 and 1.0");

            try
            {
                if (_audioOutputs.TryGetValue(streamId, out var device) && device.VolumeProvider != null)
                {
                    device.VolumeProvider.Volume = _muted ? 0.0f : volume;
                }
            }
            catch (Exception ex)
            {
                RaiseAudioError($"Error setting volume for stream {streamId}: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Clears the buffer for a specific audio stream
        /// </summary>
        /// <param name="streamId">ID of the stream to clear</param>
        public void ClearBuffer(string streamId)
        {
            if (string.IsNullOrEmpty(streamId))
                return;

            try
            {
                if (_audioBuffers.TryGetValue(streamId, out var bufferProvider))
                {
                    bufferProvider.ClearBuffer();
                }
            }
            catch (Exception ex)
            {
                RaiseAudioError($"Error clearing buffer for stream {streamId}: {ex.Message}", ex);
            }
        }

        #endregion

        #region Integration with P25Decoder

        /// <summary>
        /// Processes P25 decoded audio and sends it to the audio output
        /// </summary>
        /// <param name="audioData">Audio data from P25 decoder</param>
        /// <param name="talkgroupId">Talkgroup ID for the audio</param>
        /// <param name="systemId">System ID for the audio</param>
        /// <param name="audioQuality">Audio quality indicator (0-100)</param>
        /// <returns>True if successful, false otherwise</returns>
        public async Task<bool> ProcessP25AudioAsync(byte[] audioData, int talkgroupId, string systemId, int audioQuality = 100)
        {
            if (audioData == null || audioData.Length == 0)
                return false;

            try
            {
                // Create a unique stream ID for the talkgroup
                string streamId = GetTalkgroupStreamId(talkgroupId, systemId);

                // Check if we need to apply audio quality enhancements based on the quality indicator
                byte[] processedAudio = audioQuality < 80 
                    ? ApplyAudioEnhancements(audioData, audioQuality) 
                    : audioData;

                // Send audio to the appropriate stream
                return await WriteAudioDataAsync(streamId, processedAudio, 0, processedAudio.Length);
            }
            catch (Exception ex)
            {
                RaiseAudioError($"Error processing P25 audio for talkgroup {talkgroupId}: {ex.Message}", ex);
                return false;
            }
        }

        /// <summary>
        /// Processes P25 audio data with metadata for a specific call
        /// </summary>
        /// <param name="audioData">Audio data from P25 decoder</param>
        /// <param name="callMetadata">Metadata about the call</param>
        /// <returns>True if successful, false otherwise</returns>
        public async Task<bool> ProcessP25CallAsync(byte[] audioData, P25CallMetadata callMetadata)
        {
            if (audioData == null || audioData.Length == 0 || callMetadata == null)
                return false;

            try
            {
                // Get stream ID
                string streamId = GetTalkgroupStreamId(callMetadata.TalkgroupId, callMetadata.SystemId);

                // If this is a new call, configure the stream appropriately
                bool isNewCall = !_audioOutputs.ContainsKey(streamId);
                if (isNewCall)
                {
                    // Determine optimal audio device based on routing rules
                    string deviceId = GetDeviceForTalkgroup(callMetadata.TalkgroupId, callMetadata.SystemId);

                    // Create a new audio stream for this talkgroup
                    if (!CreateAudioStream(streamId, deviceId))
                        return false;

                    // Set appropriate volume based on priority
                    float volume = GetVolumeForTalkgroup(callMetadata.TalkgroupId, callMetadata.Priority);
                    SetStreamVolume(streamId, volume);
                }

                // Apply any audio enhancements based on signal quality
                byte[] processedAudio = callMetadata.SignalQuality < 80 
                    ? ApplyAudioEnhancements(audioData, callMetadata.SignalQuality) 
                    : audioData;

                // Send the audio to the stream
                return await WriteAudioDataAsync(streamId, processedAudio, 0, processedAudio.Length);
            }
            catch (Exception ex)
            {
                RaiseAudioError($"Error processing P25 call for talkgroup {callMetadata.TalkgroupId}: {ex.Message}", ex);
                return false;
            }
        }

        /// <summary>
        /// Ends a P25 call and performs cleanup
        /// </summary>
        /// <param name="talkgroupId">Talkgroup ID</param>
        /// <param name="systemId">System ID</param>
        public void EndP25Call(int talkgroupId, string systemId)
        {
            string streamId = GetTalkgroupStreamId(talkgroupId, systemId);
            
            try
            {
                // Optionally keep the stream open for a brief period to catch late audio packets
                // or close immediately depending on configuration
                Task.Run(async () =>
                {
                    // Wait a moment before closing to allow for any trailing audio
                    await Task.Delay(1000);
                    
                    // Close the stream
                    CloseAudioStream(streamId);
                });
            }
            catch (Exception ex)
            {
                RaiseAudioError($"Error ending P25 call for talkgroup {talkgroupId}: {ex.Message}", ex);
            }
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// Gets the NAudio device number from a device ID
        /// </summary>
        private int GetDeviceNumber(string deviceId)
        {
            try
            {
                using var enumerator = new MMDeviceEnumerator();
                int deviceNumber = -1; // -1 is the default device
                
                if (string.IsNullOrEmpty(deviceId))
                    return deviceNumber;
                
                // Iterate through all devices to find the matching one
                int index = 0;
                foreach (var device in enumerator.EnumerateAudioEndPoints(DataFlow.Render, DeviceState.Active))
                {
                    if (device.ID == deviceId)
                    {
                        deviceNumber = index;
                        break;
                    }
                    index++;
                }
                
                return deviceNumber;
            }
            catch (Exception ex)
            {
                RaiseAudioError($"Error getting device number: {ex.Message}", ex);
                return -1; // Default device
            }
        }

        /// <summary>
        /// Creates a unique stream ID for a talkgroup
        /// </summary>
        private string GetTalkgroupStreamId(int talkgroupId, string systemId)
        {
            return $"p25_{systemId}_{talkgroupId}";
        }

        /// <summary>
        /// Determines the appropriate audio device for a talkgroup based on routing rules
        /// </summary>
        private string GetDeviceForTalkgroup(int talkgroupId, string systemId)
        {
            // This would typically use configuration settings or a routing table
            // For now, we'll use the default device
            return _defaultDeviceId;
        }

        /// <summary>
        /// Determines the appropriate volume level for a talkgroup based on priority
        /// </summary>
        private float GetVolumeForTalkgroup(int talkgroupId, int priority = 5)
        {
            // Scale priority (typically 1-10) to a volume level (0.1-1.0)
            float priorityFactor = Math.Min(10, Math.Max(1, priority)) / 10.0f;
            return _masterVolume * (0.5f + (0.5f * priorityFactor));
        }

        /// <summary>
        /// Applies audio quality enhancements to poor quality audio
        /// </summary>
        private byte[] ApplyAudioEnhancements(byte[] audioData, int quality)
        {
            // This would implement actual audio processing like noise reduction,
            // equalization, etc. based on the quality indicator
            
            // For low quality signals, we might apply noise reduction
            if (quality < 50)
            {
                return ApplySimpleNoiseReduction(audioData);
            }
            
            return audioData;
        }

        /// <summary>
        /// Applies a simple noise reduction algorithm to audio data
        /// </summary>
        private byte[] ApplySimpleNoiseReduction(byte[] audioData)
        {
            // This is a placeholder for a real noise reduction algorithm
            // In a real implementation, this would use signal processing techniques
            
            if (audioData.Length < 4)
                return audioData;
                
            // Simple noise gate for demonstration purposes
            byte[] result = new byte[audioData.Length];
            Buffer.BlockCopy(audioData, 0, result, 0, audioData.Length);
            
            // Process 16-bit PCM samples
            for (int i = 0; i < result.Length - 1; i += 2)
            {
                // Convert bytes to short (16-bit sample)
                short sample = (short)(result[i] | (result[i + 1] << 8));
                
                // Simple noise gate - eliminate very quiet sounds that are likely noise
                if (Math.Abs(sample) < 500)
                {
                    sample = 0;
                }
                
                // Convert back to bytes
                result[i] = (byte)(sample & 0xFF);
                result[i + 1] = (byte)((sample >> 8) & 0xFF);
            }
            
            return result;
        }

        /// <summary>
        /// Restarts audio streams that are using the default device
        /// </summary>
        private void RestartDefaultDeviceStreams()
        {
            try
            {
                var streamsToRestart = _audioOutputs
                    .Where(kv => kv.Value.DeviceId == _defaultDeviceId || kv.Value.DeviceId == null)
                    .Select(kv => kv.Key)
                    .ToList();
                
                foreach (var streamId in streamsToRestart)
                {
                    if (_audioOutputs.TryGetValue(streamId, out var device))
                    {
                        // Get current volume
                        float volume = device.VolumeProvider.Volume;
                        
                        // Close and recreate
                        CloseAudioStream(streamId);
                        CreateAudioStream(streamId, _defaultDeviceId, device.WaveFormat.SampleRate, device.WaveFormat.Channels);
                        
                        // Restore volume
                        SetStreamVolume(streamId, volume);
                    }
                }
            }
            catch (Exception ex)
            {
                RaiseAudioError($"Error restarting audio streams: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Raises an audio error event
        /// </summary>
        private void RaiseAudioError(string message, Exception exception = null)
        {
            AudioError?.Invoke(this, new AudioErrorEventArgs(message, exception));
        }

        #endregion

        #region Buffer Monitoring

        /// <summary>
        /// Starts monitoring the buffer level for a stream
        /// </summary>
        private void StartBufferMonitoring(string streamId)
        {
            Task.Run(async () =>
            {
                try
                {
                    int previousLevel = 0;
                    
                    while (!_disposed && _audioBuffers.ContainsKey(streamId))
                    {
                        // Check every 100ms
                        await Task.Delay(100);
                        
                        if (_disposed || !_audioBuffers.ContainsKey(streamId))
                            break;
                            
                        if (_audioBuffers.TryGetValue(streamId, out var buffer))
                        {
                            // Calculate buffer level as percentage
                            int currentLevel = (int)(100.0 * buffer.BufferedBytes / buffer.BufferLength);
                            
                            // Only report significant changes (> 10%)
                            if (Math.Abs(currentLevel - previousLevel) > 10)
                            {
                                previousLevel = currentLevel;
                                
                                BufferLevelChanged?.Invoke(this, new BufferLevelEventArgs
                                {
                                    StreamId = streamId,
                                    BufferLevelPercent = currentLevel,
                                    BufferedBytes = buffer.BufferedBytes,
                                    BufferCapacity = buffer.BufferLength
                                });
                                
                                // If buffer is getting very low (< 15%), slow down monitoring to give it time to fill
                                if (currentLevel < 15)
                                {
                                    await Task.Delay(200);
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Buffer monitoring error: {ex.Message}");
                }
            });
        }

        #endregion

        #region IDisposable Implementation

        /// <summary>
        /// Disposes the audio service
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Disposes the audio service
        /// </summary>
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    // Close all active audio streams
                    foreach (var streamId in _audioOutputs.Keys.ToList())
                    {
                        CloseAudioStream(streamId);
                    }
                    
                    // Clear buffers
                    _audioBuffers.Clear();
                    _audioOutputs.Clear();
                    
                    // Release semaphore
                    _bufferSemaphore.Dispose();
                }
                
                _disposed = true;
            }
        }
        
        /// <summary>
        /// Finalizer
        /// </summary>
        ~AudioService()
        {
            Dispose(false);
        }
        
        #endregion
        
        #region Event Argument Classes
        
        /// <summary>
        /// Event arguments for audio playback events
        /// </summary>
        public class AudioPlaybackEventArgs : EventArgs
        {
            /// <summary>
            /// Gets or sets the stream ID
            /// </summary>
            public string StreamId { get; set; }
            
            /// <summary>
            /// Gets or sets the device ID
            /// </summary>
            public string DeviceId { get; set; }
        }
        
        /// <summary>
        /// Event arguments for audio error events
        /// </summary>
        public class AudioErrorEventArgs : EventArgs
        {
            /// <summary>
            /// Gets or sets the error message
            /// </summary>
            public string ErrorMessage { get; }
            
            /// <summary>
            /// Gets or sets the exception that caused the error
            /// </summary>
            public Exception Exception { get; }
            
            /// <summary>
            /// Initializes a new instance of the AudioErrorEventArgs class
            /// </summary>
            public AudioErrorEventArgs(string errorMessage, Exception exception = null)
            {
                ErrorMessage = errorMessage;
                Exception = exception;
            }
        }
        
        /// <summary>
        /// Event arguments for buffer level changed events
        /// </summary>
        public class BufferLevelEventArgs : EventArgs
        {
            /// <summary>
            /// Gets or sets the stream ID
            /// </summary>
            public string StreamId { get; set; }
            
            /// <summary>
            /// Gets or sets the buffer level as a percentage (0-100)
            /// </summary>
            public int BufferLevelPercent { get; set; }
            
            /// <summary>
            /// Gets or sets the number of buffered bytes
            /// </summary>
            public int BufferedBytes { get; set; }
            
            /// <summary>
            /// Gets or sets the buffer capacity in bytes
            /// </summary>
            public int BufferCapacity { get; set; }
        }
        
        /// <summary>
        /// Event arguments for audio device change events
        /// </summary>
        public class AudioDeviceChangeEventArgs : EventArgs
        {
            /// <summary>
            /// Gets or sets the list of available audio devices
            /// </summary>
            public List<AudioDeviceInfo> AvailableDevices { get; }
            
            /// <summary>
            /// Initializes a new instance of the AudioDeviceChangeEventArgs class
            /// </summary>
            public AudioDeviceChangeEventArgs(List<AudioDeviceInfo> availableDevices)
            {
                AvailableDevices = availableDevices;
            }
        }
        
        /// <summary>
        /// Contains information about an audio device
        /// </summary>
        public class AudioDeviceInfo
        {
            /// <summary>
            /// Gets or sets the device ID
            /// </summary>
            public string Id { get; set; }
            
            /// <summary>
            /// Gets or sets the device name
            /// </summary>
            public string Name { get; set; }
            
            /// <summary>
            /// Gets or sets whether this is the default device
            /// </summary>
            public bool IsDefault { get; set; }
        }
        
        #endregion
        
        #region Audio Classes
        
        /// <summary>
        /// Represents an audio output device and associated resources
        /// </summary>
        private class AudioOutputDevice
        {
            /// <summary>
            /// Gets or sets the NAudio output device
            /// </summary>
            public IWavePlayer WaveOut { get; set; }
            
            /// <summary>
            /// Gets or sets the unique identifier for this stream
            /// </summary>
            public string StreamId { get; set; }
            
            /// <summary>
            /// Gets or sets the device ID associated with this output
            /// </summary>
            public string DeviceId { get; set; }
            
            /// <summary>
            /// Gets or sets the wave format for this output
            /// </summary>
            public WaveFormat WaveFormat { get; set; }
            
            /// <summary>
            /// Gets or sets the volume provider for this output
            /// </summary>
            public VolumeWaveProvider16 VolumeProvider { get; set; }
            
            /// <summary>
            /// Gets or sets the creation timestamp of this output
            /// </summary>
            public DateTime CreatedAt { get; set; } = DateTime.Now;
            
            /// <summary>
            /// Gets or sets the last activity timestamp
            /// </summary>
            public DateTime LastActivity { get; set; } = DateTime.Now;
            
            /// <summary>
            /// Gets or sets whether this output is actively playing audio
            /// </summary>
            public bool IsActive { get; set; } = true;
        }
        
        /// <summary>
        /// Contains metadata about a P25 call
        /// </summary>
        public class P25CallMetadata
        {
            /// <summary>
            /// Gets or sets the talkgroup ID
            /// </summary>
            public int TalkgroupId { get; set; }
            
            /// <summary>
            /// Gets or sets the system ID
            /// </summary>
            public string SystemId { get; set; }
            
            /// <summary>
            /// Gets or sets the radio ID of the transmitting unit
            /// </summary>
            public int RadioId { get; set; }
            
            /// <summary>
            /// Gets or sets the priority of the call (1-10, where 10 is highest)
            /// </summary>
            public int Priority { get; set; } = 5;
            
            /// <summary>
            /// Gets or sets the signal quality (0-100)
            /// </summary>
            public int SignalQuality { get; set; } = 100;
            
            /// <summary>
            /// Gets or sets the timestamp when the call started
            /// </summary>
            public DateTime StartTime { get; set; } = DateTime.Now;
            
            /// <summary>
            /// Gets or sets the phase type (1 or 2)
            /// </summary>
            public int PhaseType { get; set; } = 1;
            
            /// <summary>
            /// Gets or sets the call type
            /// </summary>
            public string CallType { get; set; } = "Group";
            
            /// <summary>
            /// Gets or sets the frequency in Hz
            /// </summary>
            public double Frequency { get; set; }
            
            /// <summary>
            /// Gets or sets emergency flag
            /// </summary>
            public bool IsEmergency { get; set; }
            
            /// <summary>
            /// Gets or sets encrypted flag
            /// </summary>
            public bool IsEncrypted { get; set; }
            
            /// <summary>
            /// Gets or sets additional metadata as key-value pairs
            /// </summary>
            public Dictionary<string, string> AdditionalData { get; set; } = new Dictionary<string, string>();
        }
        
        #endregion
    }
}
