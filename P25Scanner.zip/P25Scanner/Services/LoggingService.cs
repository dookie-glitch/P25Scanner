using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using P25Scanner.Configuration;

namespace P25Scanner.Services
{
    public class LoggingService : ILogger
    {
        private readonly string _logDirectory;
        private readonly ConcurrentQueue<LogEntry> _logBuffer;
        private readonly FileLogWriter _fileWriter;
        private readonly LogLevel _minimumLevel;
        private readonly object _lockObject = new object();
        private bool _isDisposed;

        public class LogEntry
        {
            public DateTime Timestamp { get; set; }
            public LogLevel Level { get; set; }
            public string Category { get; set; }
            public string Message { get; set; }
            public Exception Exception { get; set; }
            public object Metadata { get; set; }
        }

        private class FileLogWriter : IDisposable
        {
            private readonly string _baseFilePath;
            private StreamWriter _writer;
            private DateTime _currentFileDate;
            private readonly object _lockObject = new object();
            private bool _isDisposed;

            public FileLogWriter(string baseFilePath)
            {
                _baseFilePath = baseFilePath;
                EnsureWriter();
            }

            public void WriteLog(LogEntry entry)
            {
                lock (_lockObject)
                {
                    EnsureWriter();
                    var json = JsonSerializer.Serialize(entry);
                    _writer.WriteLine(json);
                    _writer.Flush();
                }
            }

            private void EnsureWriter()
            {
                var today = DateTime.Today;
                if (_writer == null || today != _currentFileDate)
                {
                    _writer?.Dispose();
                    _currentFileDate = today;
                    string fileName = $"p25scanner_{today:yyyyMMdd}.log";
                    string filePath = Path.Combine(_baseFilePath, fileName);
                    _writer = new StreamWriter(filePath, true);
                }
            }

            public void Dispose()
            {
                if (!_isDisposed)
                {
                    _writer?.Dispose();
                    _isDisposed = true;
                }
            }
        }

        public LoggingService(AppConfig config)
        {
            _logDirectory = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "Logs");

            if (!Directory.Exists(_logDirectory))
            {
                Directory.CreateDirectory(_logDirectory);
            }

            _logBuffer = new ConcurrentQueue<LogEntry>();
            _fileWriter = new FileLogWriter(_logDirectory);
            _minimumLevel = ParseLogLevel(config?.LogLevel ?? "Information");
        }

        private LogLevel ParseLogLevel(string level)
        {
            return level?.ToLower() switch
            {
                "trace" => LogLevel.Trace,
                "debug" => LogLevel.Debug,
                "information" => LogLevel.Information,
                "warning" => LogLevel.Warning,
                "error" => LogLevel.Error,
                "critical" => LogLevel.Critical,
                _ => LogLevel.Information
            };
        }

        public void Log<TState>(
            LogLevel logLevel,
            EventId eventId,
            TState state,
            Exception exception,
            Func<TState, Exception, string> formatter)
        {
            if (!IsEnabled(logLevel))
                return;

            if (formatter == null)
                throw new ArgumentNullException(nameof(formatter));

            var message = formatter(state, exception);
            var entry = new LogEntry
            {
                Timestamp = DateTime.UtcNow,
                Level = logLevel,
                Category = typeof(TState).Name,
                Message = message,
                Exception = exception
            };

            // Add metadata if state implements ILogMetadata
            if (state is ILogMetadata metadata)
            {
                entry.Metadata = metadata.GetMetadata();
            }

            _logBuffer.Enqueue(entry);
            _fileWriter.WriteLog(entry);
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            return logLevel >= _minimumLevel;
        }

        public IDisposable BeginScope<TState>(TState state)
        {
            return null;
        }

        public async Task<LogEntry[]> GetRecentLogsAsync(
            DateTime? since = null,
            LogLevel? minLevel = null,
            string category = null,
            int maxEntries = 100)
        {
            var logs = new List<LogEntry>();
            var filesToSearch = Directory.GetFiles(_logDirectory, "p25scanner_*.log")
                .OrderByDescending(f => f);

            foreach (var file in filesToSearch)
            {
                try
                {
                    var fileLines = await File.ReadAllLinesAsync(file);
                    foreach (var line in fileLines.Reverse())
                    {
                        var entry = JsonSerializer.Deserialize<LogEntry>(line);
                        if (ShouldIncludeLog(entry, since, minLevel, category))
                        {
                            logs.Add(entry);
                            if (logs.Count >= maxEntries)
                                return logs.ToArray();
                        }
                    }
                }
                catch (Exception)
                {
                    // Skip corrupted log files
                    continue;
                }
            }

            return logs.ToArray();
        }

        private bool ShouldIncludeLog(
            LogEntry entry,
            DateTime? since,
            LogLevel? minLevel,
            string category)
        {
            if (since.HasValue && entry.Timestamp < since.Value)
                return false;

            if (minLevel.HasValue && entry.Level < minLevel.Value)
                return false;

            if (!string.IsNullOrEmpty(category) && entry.Category != category)
                return false;

            return true;
        }

        public void Dispose()
        {
            if (!_isDisposed)
            {
                _fileWriter.Dispose();
                _isDisposed = true;
            }
        }
    }

    public interface ILogMetadata
    {
        object GetMetadata();
    }

    public class LogMetadata
    {
        public long Frequency { get; set; }
        public int TalkgroupId { get; set; }
        public float SignalQuality { get; set; }
        public string Status { get; set; }
        public Dictionary<string, string> AdditionalData { get; set; }
    }
}

