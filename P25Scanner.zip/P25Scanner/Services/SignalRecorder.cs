using System;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NAudio.Wave;
using P25Scanner.Configuration;

namespace P25Scanner.Services
{
    public class SignalRecorder : IDisposable
    {
        private readonly ILogger<SignalRecorder> _logger;
        private readonly AppConfig _config;
        private readonly string _recordingsPath;
        private WaveFileWriter _waveWriter;
        private StreamWriter _metadataWriter;
        private bool _isRecording;
        private string _currentFileName;
        private bool _isDisposed;

        public class RecordingMetadata
        {
            public DateTime StartTime { get; set; }
            public DateTime EndTime { get; set; }
            public int TalkgroupId { get; set; }
            public int NAC { get; set; }
            public float SignalQuality { get; set; }
            public float Frequency { get; set; }
            public string Description { get; set; }
        }

        public SignalRecorder(ILogger<SignalRecorder> logger, AppConfig config)
        {
            _logger = logger;
            _config = config;
            _recordingsPath = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "Recordings");

            // Ensure recordings directory exists
            if (!Directory.Exists(_recordingsPath))
            {
                Directory.CreateDirectory(_recordingsPath);
            }
        }

        public async Task StartRecordingAsync(int talkgroupId, float frequency)
        {
            if (_isRecording)
                return;

            try
            {
                string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                _currentFileName = $"TG{talkgroupId}_{timestamp}";
                string audioPath = Path.Combine(_recordingsPath, $"{_currentFileName}.wav");
                string metadataPath = Path.Combine(_recordingsPath, $"{_currentFileName}.json");

                // Initialize wave file writer
                var waveFormat = new WaveFormat(8000, 16, 1);
                _waveWriter = new WaveFileWriter(audioPath, waveFormat);

                // Initialize metadata file
                _metadataWriter = new StreamWriter(metadataPath);
                var metadata = new RecordingMetadata
                {
                    StartTime = DateTime.UtcNow,
                    TalkgroupId = talkgroupId,
                    Frequency = frequency
                };

                await WriteMetadataAsync(metadata);
                _isRecording = true;

                _logger.LogInformation(
                    "Started recording talkgroup {TalkgroupId} at {Frequency}Hz",
                    talkgroupId, frequency);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error starting recording");
                throw;
            }
        }

        public async Task StopRecordingAsync(RecordingMetadata finalMetadata)
        {
            if (!_isRecording)
                return;

            try
            {
                finalMetadata.EndTime = DateTime.UtcNow;
                await WriteMetadataAsync(finalMetadata);

                _waveWriter?.Dispose();
                _waveWriter = null;

                _metadataWriter?.Dispose();
                _metadataWriter = null;

                _isRecording = false;

                _logger.LogInformation(
                    "Stopped recording talkgroup {TalkgroupId}",
                    finalMetadata.TalkgroupId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error stopping recording");
                throw;
            }
        }

        public void WriteAudioSamples(float[] samples)
        {
            if (!_isRecording || samples == null)
                return;

            try
            {
                // Convert float samples to 16-bit PCM
                var pcmSamples = new short[samples.Length];
                for (int i = 0; i < samples.Length; i++)
                {
                    pcmSamples[i] = (short)(samples[i] * short.MaxValue);
                }

                // Write to WAV file
                var bytes = new byte[pcmSamples.Length * 2];
                Buffer.BlockCopy(pcmSamples, 0, bytes, 0, bytes.Length);
                _waveWriter?.Write(bytes, 0, bytes.Length);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error writing audio samples");
            }
        }

        public async Task UpdateMetadataAsync(Action<RecordingMetadata> updateAction)
        {
            if (!_isRecording)
                return;

            try
            {
                var metadata = new RecordingMetadata();
                updateAction(metadata);
                await WriteMetadataAsync(metadata);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating metadata");
            }
        }

        private async Task WriteMetadataAsync(RecordingMetadata metadata)
        {
            if (_metadataWriter == null)
                return;

            try
            {
                var options = new JsonSerializerOptions
                {
                    WriteIndented = true
                };

                string json = JsonSerializer.Serialize(metadata, options);
                await _metadataWriter.WriteLineAsync(json);
                await _metadataWriter.FlushAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error writing metadata");
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_isDisposed)
            {
                if (disposing)
                {
                    if (_isRecording)
                    {
                        StopRecordingAsync(new RecordingMetadata
                        {
                            EndTime = DateTime.UtcNow
                        }).Wait();
                    }

                    _waveWriter?.Dispose();
                    _metadataWriter?.Dispose();
                }

                _isDisposed = true;
            }
        }
    }
}

