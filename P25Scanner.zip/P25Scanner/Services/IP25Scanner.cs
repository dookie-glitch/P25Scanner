using System;
using P25Scanner.Models;

namespace P25Scanner.Services
{
    /// <summary>
    /// Interface for P25 Scanner operations
    /// </summary>
    public interface IP25Scanner : IDisposable
    {
        /// <summary>
        /// Event fired when a signal is detected
        /// </summary>
        event EventHandler<SignalDetectedEventArgs> SignalDetected;
        
        /// <summary>
        /// Event fired when the scanning frequency changes
        /// </summary>
        event EventHandler<FrequencyChangedEventArgs> FrequencyChanged;
        
        /// <summary>
        /// Configure the scanner with specified settings
        /// </summary>
        void Configure(ScannerConfiguration configuration);
        
        /// <summary>
        /// Start the scanning process
        /// </summary>
        void Start();
        
        /// <summary>
        /// Stop the scanning process
        /// </summary>
        void Stop();
        
        /// <summary>
        /// Pause the scanning process
        /// </summary>
        void Pause();
        
        /// <summary>
        /// Resume a paused scanning process
        /// </summary>
        void Resume();
    }
}

