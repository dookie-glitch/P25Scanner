using System;
using System.ComponentModel;
using System.Windows;
using Microsoft.Extensions.Logging;
using P25Scanner.ViewModels;

namespace P25Scanner.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly ILogger<MainWindow> _logger;
        private MainWindowViewModel ViewModel => (MainWindowViewModel)DataContext;

        public MainWindow(ILogger<MainWindow> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            
            InitializeComponent();
            
            _logger.LogInformation("MainWindow initialized");
            
            Loaded += MainWindow_Loaded;
            Closing += MainWindow_Closing;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            _logger.LogInformation("MainWindow loaded");
            
            try
            {
                ViewModel.Initialize();
                _logger.LogInformation("ViewModel initialized successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error initializing ViewModel");
                MessageBox.Show($"Failed to initialize application: {ex.Message}", 
                    "Initialization Error", 
                    MessageBoxButton.OK, 
                    MessageBoxImage.Error);
            }
        }

        private void MainWindow_Closing(object sender, CancelEventArgs e)
        {
            _logger.LogInformation("MainWindow closing");
            
            try
            {
                // If scanning is active, ask user to confirm exit
                if (ViewModel.IsScanning)
                {
                    var result = MessageBox.Show(
                        "Scanning is in progress. Are you sure you want to exit?",
                        "Confirm Exit",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Question);
                    
                    if (result == MessageBoxResult.No)
                    {
                        e.Cancel = true;
                        return;
                    }
                }
                
                // Stop any active scanning and cleanup resources
                ViewModel.Cleanup();
                _logger.LogInformation("ViewModel cleanup completed");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during cleanup");
                MessageBox.Show($"An error occurred during shutdown: {ex.Message}", 
                    "Shutdown Error", 
                    MessageBoxButton.OK, 
                    MessageBoxImage.Warning);
            }
        }
    }
}

using P25Scanner.ViewModels;
using System.Windows;

namespace P25Scanner.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly MainWindowViewModel _viewModel;

        public MainWindow()
        {
            InitializeComponent();
            
            // Get the viewmodel from the dependency injection container
            _viewModel = App.GetService<MainWindowViewModel>();
            DataContext = _viewModel;
        }

        protected override void OnClosed(System.EventArgs e)
        {
            // Ensure resources are properly disposed when the window is closed
            _viewModel.StopCommand.Execute(null);
            base.OnClosed(e);
        }
    }
}

