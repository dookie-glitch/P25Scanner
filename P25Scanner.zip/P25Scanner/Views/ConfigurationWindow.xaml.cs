using System;
using System.Windows;
using P25Scanner.ViewModels;
using P25Scanner.Services;

namespace P25Scanner.Views
{
    public partial class ConfigurationWindow : Window
    {
        private readonly ConfigurationViewModel _viewModel;

        public ConfigurationWindow(ConfigurationViewModel viewModel)
        {
            _viewModel = viewModel ?? throw new ArgumentNullException(nameof(viewModel));
            InitializeComponent();
            DataContext = _viewModel;

            // Handle window closing with pending changes
            Closing += ConfigurationWindow_Closing;
        }

        private void ConfigurationWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Prompt to save changes if needed
            if (_viewModel.HasPendingChanges)
            {
                var result = DialogService.ShowMessage(
                    "Do you want to save your changes?",
                    "Save Changes",
                    MessageBoxButton.YesNoCancel,
                    MessageBoxImage.Question);

                switch (result)
                {
                    case MessageBoxResult.Yes:
                        try
                        {
                            _viewModel.SaveCommand.Execute(null);
                        }
                        catch (Exception ex)
                        {
                            DialogService.ShowError(
                                "Failed to save configuration",
                                ex.Message);
                            e.Cancel = true;
                        }
                        break;
                    case MessageBoxResult.Cancel:
                        e.Cancel = true;
                        break;
                }
            }
        }
    }
}

