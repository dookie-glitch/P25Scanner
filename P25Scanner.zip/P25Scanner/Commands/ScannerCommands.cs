using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using P25Scanner.Services;

namespace P25Scanner.Commands
{
    public class ScannerCommands
    {
        private readonly FrequencyScanner _scanner;
        private readonly ILogger<ScannerCommands> _logger;
        private readonly AudioPlaybackManager _audioManager;
        private readonly ChannelListManager _channelManager;

        public AsyncRelayCommand StartScanningCommand { get; }
        public AsyncRelayCommand StopScanningCommand { get; }
        public RelayCommand PauseScanningCommand { get; }
        public RelayCommand ResumeScanningCommand { get; }
        public AsyncRelayCommand<long> HoldFrequencyCommand { get; }
        public AsyncRelayCommand ImportChannelsCommand { get; }
        public AsyncRelayCommand ExportChannelsCommand { get; }
        public RelayCommand<long> SkipFrequencyCommand { get; }
        public RelayCommand MuteAudioCommand { get; }
        public RelayCommand<float> SetVolumeCommand { get; }

        public ScannerCommands(
            FrequencyScanner scanner,
            ILogger<ScannerCommands> logger,
            AudioPlaybackManager audioManager,
            ChannelListManager channelManager)
        {
            _scanner = scanner;
            _logger = logger;
            _audioManager = audioManager;
            _channelManager = channelManager;

            StartScanningCommand = new AsyncRelayCommand(
                async () =>
                {
                    try
                    {
                        await _scanner.StartScanningAsync(default);
                        _logger.LogInformation("Scanner started");
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Failed to start scanner");
                        throw;
                    }
                },
                () => !_scanner.IsScanning);

            StopScanningCommand = new AsyncRelayCommand(
                async () =>
                {
                    try
                    {
                        await _scanner.StopScanningAsync();
                        _logger.LogInformation("Scanner stopped");
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Failed to stop scanner");
                        throw;
                    }
                },
                () => _scanner.IsScanning);

            PauseScanningCommand = new RelayCommand(
                () =>
                {
                    _scanner.PauseScanning();
                    _logger.LogInformation("Scanner paused");
                },
                () => _scanner.IsScanning && !_scanner.IsPaused);

            ResumeScanningCommand = new RelayCommand(
                () =>
                {
                    _scanner.ResumeScanning();
                    _logger.LogInformation("Scanner resumed");
                },
                () => _scanner.IsScanning && _scanner.IsPaused);

            HoldFrequencyCommand = new AsyncRelayCommand<long>(
                async (frequency) =>
                {
                    try
                    {
                        _scanner.PauseScanning();
                        await Task.Delay(100); // Allow current operations to complete
                        await _scanner.SetFrequencyAsync(frequency);
                        _logger.LogInformation("Holding on frequency: {Frequency} Hz", frequency);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Failed to hold frequency");
                        throw;
                    }
                });

            ImportChannelsCommand = new AsyncRelayCommand(
                async () =>
                {
                    try
                    {
                        string filePath = DialogService.ShowOpenFileDialog(
                            "CSV files (*.csv)|*.csv|All files (*.*)|*.*",
                            "Import Channel List");

                        if (!string.IsNullOrEmpty(filePath))
                        {
                            string listName = System.IO.Path.GetFileNameWithoutExtension(filePath);
                            await _channelManager.ImportFromCsvAsync(filePath, listName);
                            _logger.LogInformation("Channels imported from: {FilePath}", filePath);
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Failed to import channels");
                        throw;
                    }
                });

            ExportChannelsCommand = new AsyncRelayCommand(
                async () =>
                {
                    try
                    {
                        string filePath = DialogService.ShowSaveFileDialog(
                            "CSV files (*.csv)|*.csv|All files (*.*)|*.*",
                            "Export Channel List",
                            defaultFileName: "channels.csv");

                        if (!string.IsNullOrEmpty(filePath))
                        {
                            await _channelManager.ExportToCsvAsync(
                                _channelManager.GetChannelLists().First().Key,
                                filePath);
                            _logger.LogInformation("Channels exported to: {FilePath}", filePath);
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Failed to export channels");
                        throw;
                    }
                });

            SkipFrequencyCommand = new RelayCommand<long>(
                (frequency) =>
                {
                    _scanner.RemoveChannel(frequency);
                    _logger.LogInformation("Skipped frequency: {Frequency} Hz", frequency);
                },
                (frequency) => frequency > 0);

            MuteAudioCommand = new RelayCommand(
                () =>
                {
                    _audioManager.IsMuted = !_audioManager.IsMuted;
                    _logger.LogInformation("Audio {Status}", _audioManager.IsMuted ? "muted" : "unmuted");
                });

            SetVolumeCommand = new RelayCommand<float>(
                (volume) =>
                {
                    _audioManager.Volume = Math.Clamp(volume, 0, 1);
                    _logger.LogDebug("Volume set to: {Volume}", _audioManager.Volume);
                });
        }
    }
}

