using System;
using System.Runtime.InteropServices;
using System.Text;

namespace P25Scanner.Native
{
    /// <summary>
    /// Direct P/Invoke bindings for RTL-SDR library
    /// </summary>
    public static class RtlSdr
    {
        #region Constants

        public const int LIBUSB_ERROR_OTHER = -99;
        public const int RTL_TCP_DEFAULT_PORT = 1234;

        // Device strings
        public const int RTLSDR_MAX_DEVICE_NAME_LEN = 32;
        public const int RTLSDR_DEFAULT_BUF_NUMBER = 32;
        public const int RTLSDR_DEFAULT_BUF_LENGTH = (16 * 32 * 512);
        public const int RTLSDR_MAX_GAIN_VALUES = 100;
        
        // Default device values
        public const int RTL_DEFAULT_SAMPLE_RATE = 2048000;
        public const int RTL_DEFAULT_FREQUENCY = 100000000;
        public const int RTL_DEFAULT_GAIN = 0;
        public const int RTL_DEFAULT_ASYNC_BUF_NUMBER = 32;
        public const int RTL_DEFAULT_BUF_LENGTH = 16384;

        // Vendor and Device IDs
        public const int RTL_VENDOR_ID = 0x0bda;
        public const int RTL_DEVICE_ID = 0x2838;

        #endregion

        #region Enums

        /// <summary>
        /// RTL-SDR device parameter types
        /// </summary>
        public enum RtlSdrTunerType
        {
            RTLSDR_TUNER_UNKNOWN = 0,
            RTLSDR_TUNER_E4000,
            RTLSDR_TUNER_FC0012,
            RTLSDR_TUNER_FC0013,
            RTLSDR_TUNER_FC2580,
            RTLSDR_TUNER_R820T,
            RTLSDR_TUNER_R828D
        }

        /// <summary>
        /// RTL-SDR device parameters
        /// </summary>
        public enum RtlSdrDevParam
        {
            RTLSDR_TUNER = 0,
            RTLSDR_XTAL,
            RTLSDR_SLAVE_DEMOD
        }

        /// <summary>
        /// Enum for tuner gains
        /// </summary>
        public enum RtlSdrTunerGain
        {
            Auto = 0,
            Manual = 1,
            AGC = 2
        }

        /// <summary>
        /// RTL-SDR error codes
        /// </summary>
        public enum RtlSdrError
        {
            None = 0,
            NotFound = -1,
            InvalidParam = -2,
            NotSupported = -3,
            AllocFailed = -4,
            InitFailed = -5,
            IOError = -6,
            Invalid = -7,
            Timeout = -8
        }

        /// <summary>
        /// Enum for direct sampling modes
        /// </summary>
        public enum RtlSdrDirectSampling
        {
            Disabled = 0,
            I = 1,
            Q = 2
        }

        #endregion

        #region Delegates

        /// <summary>
        /// Delegate for async read callback
        /// </summary>
        /// <param name="buf">Pointer to the buffer with samples</param>
        /// <param name="len">Length of the buffer</param>
        /// <param name="ctx">User context</param>
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        public delegate void RtlSdrReadAsyncCallback(IntPtr buf, uint len, IntPtr ctx);

        #endregion

        #region PInvoke Declarations

        private const string LibRtlSdr = "rtlsdr.dll";

        /// <summary>
        /// Get the number of detected RTL-SDR devices.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern uint rtlsdr_get_device_count();

        /// <summary>
        /// Get device name by index.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern IntPtr rtlsdr_get_device_name(uint index);

        /// <summary>
        /// Get USB device strings.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_get_device_usb_strings(uint index, StringBuilder manufacturer, StringBuilder product, StringBuilder serial);

        /// <summary>
        /// Get device index by serial string.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_get_index_by_serial(string serial);

        /// <summary>
        /// Open an RTL-SDR device.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_open(out IntPtr dev, uint index);

        /// <summary>
        /// Close an RTL-SDR device.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_close(IntPtr dev);

        /// <summary>
        /// Set crystal oscillator frequencies.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_set_xtal_freq(IntPtr dev, uint rtl_freq, uint tuner_freq);

        /// <summary>
        /// Get crystal oscillator frequencies.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_get_xtal_freq(IntPtr dev, out uint rtl_freq, out uint tuner_freq);

        /// <summary>
        /// Get device information (tuner type, etc).
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_get_usb_strings(IntPtr dev, StringBuilder manufacturer, StringBuilder product, StringBuilder serial);

        /// <summary>
        /// Write data to EEPROM.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_write_eeprom(IntPtr dev, byte[] data, byte offset, ushort len);

        /// <summary>
        /// Read data from EEPROM.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_read_eeprom(IntPtr dev, byte[] data, byte offset, ushort len);

        /// <summary>
        /// Set center frequency.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_set_center_freq(IntPtr dev, uint freq);

        /// <summary>
        /// Get center frequency.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern uint rtlsdr_get_center_freq(IntPtr dev);

        /// <summary>
        /// Set sample rate.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_set_sample_rate(IntPtr dev, uint rate);

        /// <summary>
        /// Get sample rate.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern uint rtlsdr_get_sample_rate(IntPtr dev);

        /// <summary>
        /// Set tuner gain mode.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_set_tuner_gain_mode(IntPtr dev, int manual);

        /// <summary>
        /// Set tuner gain.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_set_tuner_gain(IntPtr dev, int gain);

        /// <summary>
        /// Get tuner gain.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_get_tuner_gain(IntPtr dev);

        /// <summary>
        /// Get a list of supported tuner gain values.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_get_tuner_gains(IntPtr dev, [In, Out] int[] gains);

        /// <summary>
        /// Set the intermediate frequency gain.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_set_tuner_if_gain(IntPtr dev, int stage, int gain);

        /// <summary>
        /// Set the direct sampling mode.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_set_direct_sampling(IntPtr dev, int on);

        /// <summary>
        /// Get the direct sampling mode.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_get_direct_sampling(IntPtr dev);

        /// <summary>
        /// Enable or disable the offset tuning.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_set_offset_tuning(IntPtr dev, int on);

        /// <summary>
        /// Get the offset tuning mode.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_get_offset_tuning(IntPtr dev);

        /// <summary>
        /// Reset the device buffer.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_reset_buffer(IntPtr dev);

        /// <summary>
        /// Read samples from the device.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_read_sync(IntPtr dev, byte[] buf, int len, out int n_read);

        /// <summary>
        /// Start asynchronous reads.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_read_async(IntPtr dev, RtlSdrReadAsyncCallback cb, IntPtr ctx, uint buf_num, uint buf_len);

        /// <summary>
        /// Cancel asynchronous reads.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_cancel_async(IntPtr dev);

        /// <summary>
        /// Enable or disable the bias tee.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_set_bias_tee(IntPtr dev, int on);

        /// <summary>
        /// Set the frequency correction value.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_set_freq_correction(IntPtr dev, int ppm);

        /// <summary>
        /// Get the frequency correction value.
        /// </summary>
        [DllImport(LibRtlSdr, CallingConvention = CallingConvention.Cdecl)]
        public static extern int rtlsdr_get_freq_correction(IntPtr dev);

        #endregion

        #region Helper Methods

        /// <summary>
        /// Gets the device name as a string
        /// </summary>
        public static string GetDeviceName(uint index)
        {
            IntPtr strPtr = rtlsdr_get_device_name(index);
            return strPtr != IntPtr.Zero ? Marshal.PtrToStringAnsi(strPtr) : string.Empty;
        }

        /// <summary>
        /// Helper to check error code and throw exception if needed
        /// </summary>
        public static void CheckError(int errorCode, string operation)
        {
            if (errorCode != 0)
            {
                string message = errorCode switch
                {
                    -1 => "Device not found",
                    -2 => "Invalid parameters",
                    -3 => "Operation not supported",
                    -4 => "Memory allocation error",
                    -5 => "Device initialization failed",
                    -6 => "I/O error",
                    -7 => "Invalid operation",
                    -8 => "Operation timed out",
                    _ => $"Unknown error ({errorCode})"
                };
                throw new RtlSdrException($"RTL-SDR {operation} failed: {message}", errorCode);
            }
        }

        /// <summary>
        /// Converts error code to an RtlSdrError enum value
        /// </summary>
        public static RtlSdrError GetErrorType(int errorCode)
        {
            return errorCode switch
            {
                0 => RtlSdrError.None,
                -1 => RtlSdrError.NotFound,
                -2 => RtlSdrError.InvalidParam,
                -3 => RtlSdrError.NotSupported,
                -4 => RtlSdrError.AllocFailed,
                -5 => RtlSdrError.InitFailed,
                -6 => RtlSdrError.IOError,
                -7 => RtlSdrError.Invalid,
                -8 => RtlSdrError.Timeout,
                _ => RtlSdrError.Invalid // Default to Invalid for unknown error codes
            };
        }
