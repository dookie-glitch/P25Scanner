using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using MaterialDesignColors.Recommended;

namespace P25Scanner.Converters
{
    /// <summary>
    /// Converts scanner status strings to appropriate Material Design colors.
    /// Used to visually represent the current scanner state in the UI.
    /// </summary>
    public class StatusToColorConverter : IValueConverter
    {
        /// <summary>
        /// Converts a scanner status string to a Material Design color.
        /// </summary>
        /// <param name="value">The status string (e.g., "Scanning", "Stopped", "Paused", "Error")</param>
        /// <param name="targetType">The type of the binding target property</param>
        /// <param name="parameter">Optional parameter - if "light" is specified, lighter color variants will be used</param>
        /// <param name="culture">Culture info</param>
        /// <returns>A SolidColorBrush representing the status</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // Default to Gray if null or invalid type
            if (value == null || value is not string status)
            {
                return new SolidColorBrush(Grey.Grey400.Color);
            }

            // Check if light variants should be used
            bool useLightVariant = parameter is string paramStr && 
                                  paramStr.Equals("light", StringComparison.OrdinalIgnoreCase);

            // Convert case-insensitive to handle various casing styles
            return status.ToLowerInvariant() switch
            {
                "scanning" => new SolidColorBrush(useLightVariant ? Green.Green300.Color : Green.Green500.Color),
                "listening" => new SolidColorBrush(useLightVariant ? LightGreen.LightGreen300.Color : LightGreen.LightGreen500.Color),
                "paused" => new SolidColorBrush(useLightVariant ? Amber.Amber300.Color : Amber.Amber500.Color),
                "stopped" => new SolidColorBrush(useLightVariant ? Grey.Grey300.Color : Grey.Grey500.Color),
                "error" => new SolidColorBrush(useLightVariant ? Red.Red300.Color : Red.Red500.Color),
                "connected" => new SolidColorBrush(useLightVariant ? Cyan.Cyan300.Color : Cyan.Cyan500.Color),
                "disconnected" => new SolidColorBrush(useLightVariant ? BlueGrey.BlueGrey300.Color : BlueGrey.BlueGrey500.Color),
                "initializing" => new SolidColorBrush(useLightVariant ? Blue.Blue300.Color : Blue.Blue500.Color),
                "receiving" => new SolidColorBrush(useLightVariant ? Teal.Teal300.Color : Teal.Teal500.Color),
                "active" => new SolidColorBrush(useLightVariant ? LightGreen.LightGreen300.Color : LightGreen.LightGreen500.Color),
                "idle" => new SolidColorBrush(useLightVariant ? BlueGrey.BlueGrey300.Color : BlueGrey.BlueGrey500.Color),
                // Default to Grey400 if status is not recognized
                _ => new SolidColorBrush(Grey.Grey400.Color)
            };
        }

        /// <summary>
        /// Converts a color back to a status string.
        /// </summary>
        /// <remarks>
        /// This conversion is generally not needed for typical binding scenarios but is 
        /// implemented to satisfy the IValueConverter interface. It attempts to match
        /// colors to their closest status value, but exact matching is not guaranteed.
        /// </remarks>
        /// <param name="value">The color brush to convert back</param>
        /// <param name="targetType">The type of the binding target property</param>
        /// <param name="parameter">Optional parameter (not used)</param>
        /// <param name="culture">Culture info</param>
        /// <returns>A status string or null if conversion is not possible</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // If not a brush, we can't convert
            if (value is not SolidColorBrush brush)
            {
                return null;
            }

            // Get the color and try to match to a status
            Color color = brush.Color;

            // Try to match the color to a status by comparing to our known colors
            // This is an approximation as exact color matching can be complex
            if (ColorIsClose(color, Green.Green500.Color)) return "Scanning";
            if (ColorIsClose(color, LightGreen.LightGreen500.Color)) return "Listening";
            if (ColorIsClose(color, Amber.Amber500.Color)) return "Paused";
            if (ColorIsClose(color, Grey.Grey500.Color)) return "Stopped";
            if (ColorIsClose(color, Red.Red500.Color)) return "Error";
            if (ColorIsClose(color, Cyan.Cyan500.Color)) return "Connected";
            if (ColorIsClose(color, BlueGrey.BlueGrey500.Color)) return "Disconnected";
            if (ColorIsClose(color, Blue.Blue500.Color)) return "Initializing";
            if (ColorIsClose(color, Teal.Teal500.Color)) return "Receiving";

            // Fallback to "Unknown" if no match found
            return "Unknown";
        }

        /// <summary>
        /// Helper method to determine if two colors are approximately the same
        /// </summary>
        /// <param name="c1">First color</param>
        /// <param name="c2">Second color</param>
        /// <returns>True if colors are similar, False otherwise</returns>
        private bool ColorIsClose(Color c1, Color c2)
        {
            // Simple implementation - just check if components are within 20 of each other
            return Math.Abs(c1.R - c2.R) < 20 &&
                   Math.Abs(c1.G - c2.G) < 20 &&
                   Math.Abs(c1.B - c2.B) < 20 &&
                   Math.Abs(c1.A - c2.A) < 20;
        }
    }
}

