using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using MaterialDesignColors.Recommended;

namespace P25Scanner.Converters
{
    /// <summary>
    /// Converts device connection status to appropriate MaterialDesign colors and vice versa.
    /// </summary>
    /// <remarks>
    /// This converter maps connection states to visual indicators:
    /// - Connected: Green
    /// - Connecting: Amber
    /// - Disconnected: Red
    /// - Error: DeepOrange
    /// </remarks>
    public class ConnectionStatusToColorConverter : IValueConverter
    {
        /// <summary>
        /// Converts a connection status string to a corresponding SolidColorBrush.
        /// </summary>
        /// <param name="value">The connection status as a string (e.g., "Connected", "Disconnected", "Connecting", "Error")</param>
        /// <param name="targetType">The type of the binding target property (expected to be SolidColorBrush)</param>
        /// <param name="parameter">An optional parameter (not used)</param>
        /// <param name="culture">The culture to use in the converter</param>
        /// <returns>A SolidColorBrush that corresponds to the connection status</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string status)
            {
                return status.ToLowerInvariant() switch
                {
                    "connected" => new SolidColorBrush(Green.Green500),
                    "connecting" => new SolidColorBrush(Amber.Amber500),
                    "disconnected" => new SolidColorBrush(Red.Red500),
                    "error" => new SolidColorBrush(DeepOrange.DeepOrange500),
                    _ => new SolidColorBrush(Grey.Grey500) // Default for unknown status
                };
            }

            return new SolidColorBrush(Grey.Grey500); // Default fallback
        }

        /// <summary>
        /// Converts a SolidColorBrush back to a connection status string.
        /// </summary>
        /// <param name="value">The SolidColorBrush to convert back</param>
        /// <param name="targetType">The type of the binding target property (expected to be string)</param>
        /// <param name="parameter">An optional parameter (not used)</param>
        /// <param name="culture">The culture to use in the converter</param>
        /// <returns>A connection status string corresponding to the color, or null if conversion is not possible</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is SolidColorBrush brush)
            {
                if (ColorEquals(brush.Color, Green.Green500))
                    return "Connected";
                if (ColorEquals(brush.Color, Amber.Amber500))
                    return "Connecting";
                if (ColorEquals(brush.Color, Red.Red500))
                    return "Disconnected";
                if (ColorEquals(brush.Color, DeepOrange.DeepOrange500))
                    return "Error";
            }

            return null; // Unable to convert back
        }

        /// <summary>
        /// Helper method to compare two colors accounting for possible small differences due to serialization or system rendering.
        /// </summary>
        /// <param name="color1">First color to compare</param>
        /// <param name="color2">Second color to compare</param>
        /// <returns>True if the colors are the same or very similar</returns>
        private bool ColorEquals(Color color1, Color color2)
        {
            return color1.A == color2.A && 
                   color1.R == color2.R && 
                   color1.G == color2.G && 
                   color1.B == color2.B;
        }
    }
}

