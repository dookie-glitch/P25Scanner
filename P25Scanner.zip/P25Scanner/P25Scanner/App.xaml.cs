using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using P25Scanner.Services;
using P25Scanner.ViewModels;
using Serilog;
using ReactiveUI;

namespace P25Scanner
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private IServiceProvider _serviceProvider;
        private ILogger<App> _logger;
        
        // Static logger for unhandled exceptions before DI is set up
        private static readonly Serilog.ILogger _staticLogger = new LoggerConfiguration()
            .MinimumLevel.Information()
            .WriteTo.File("logs/p25scanner-startup.log", rollingInterval: RollingInterval.Day)
            .WriteTo.Console()
            .CreateLogger();

        /// <summary>
        /// Application entry point. Sets up dependency injection and starts the application.
        /// </summary>
        /// <param name="e">Startup event args</param>
        protected override void OnStartup(StartupEventArgs e)
        {
            try
            {
                // Configure global exception handler
                AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
                Current.DispatcherUnhandledException += Current_DispatcherUnhandledException;
                TaskScheduler.UnobservedTaskException += TaskScheduler_UnobservedTaskException;

                _staticLogger.Information("P25Scanner starting up...");

                // Ensure log directory exists
                Directory.CreateDirectory("logs");
                
                // Set up services
                var services = new ServiceCollection();
                ConfigureServices(services);
                
                // Build the service provider
                _serviceProvider = services.BuildServiceProvider();
                
                // Get logger from DI
                _logger = _serviceProvider.GetRequiredService<ILogger<App>>();
                _logger.LogInformation("Services initialized successfully");
                
                // Start the main window
                var mainWindow = _serviceProvider.GetRequiredService<MainWindow>();
                mainWindow.Show();
                
                base.OnStartup(e);
                _logger.LogInformation("Application started successfully");
            }
            catch (Exception ex)
            {
                _staticLogger.Fatal(ex, "Fatal error during application startup");
                MessageBox.Show($"A fatal error occurred during startup: {ex.Message}\n\nThe application will now shut down.", 
                    "P25Scanner - Fatal Error", MessageBoxButton.OK, MessageBoxImage.Error);
                Current.Shutdown(-1);
            }
        }

        /// <summary>
        /// Configures the application's services with dependency injection
        /// </summary>
        /// <param name="services">The service collection to configure</param>
        private void ConfigureServices(ServiceCollection services)
        {
            // Configure logging
            ConfigureLogging(services);
            
            // Register services
            services.AddSingleton<IRtlSdrService, RtlSdrService>();
            services.AddSingleton<IAudioService, AudioService>();
            services.AddSingleton<IP25Decoder, P25Decoder>();
            
            // Register ViewModels
            services.AddTransient<MainWindowViewModel>();
            
            // Register views
            services.AddTransient<MainWindow>(provider => 
                new MainWindow { DataContext = provider.GetRequiredService<MainWindowViewModel>() });
        }

        /// <summary>
        /// Configures the logging system
        /// </summary>
        /// <param name="services">The service collection to configure</param>
        private void ConfigureLogging(ServiceCollection services)
        {
            // Create Serilog logger
            var loggerConfiguration = new LoggerConfiguration()
                .MinimumLevel.Information()
                .WriteTo.Console()
                .WriteTo.Debug()
                .WriteTo.File("logs/p25scanner-.log", rollingInterval: RollingInterval.Day);

            // Create the Serilog logger
            var serilogLogger = loggerConfiguration.CreateLogger();
            
            // Add logging
            services.AddLogging(builder =>
            {
                builder.ClearProviders();
                builder.AddSerilog(serilogLogger, dispose: true);
            });
        }

        /// <summary>
        /// Handles application shutdown
        /// </summary>
        /// <param name="e">Exit event args</param>
        protected override void OnExit(ExitEventArgs e)
        {
            try
            {
                _logger?.LogInformation("Application shutting down...");
                
                // Clean up services
                if (_serviceProvider != null)
                {
                    // Explicitly dispose the RTL-SDR service to ensure device is released
                    var rtlSdrService = _serviceProvider.GetService<IRtlSdrService>();
                    (rtlSdrService as IDisposable)?.Dispose();
                    
                    // Dispose the audio service
                    var audioService = _serviceProvider.GetService<IAudioService>();
                    (audioService as IDisposable)?.Dispose();
                    
                    // Dispose the P25 decoder
                    var p25Decoder = _serviceProvider.GetService<IP25Decoder>();
                    (p25Decoder as IDisposable)?.Dispose();
                    
                    // Dispose service provider if it's disposable
                    (_serviceProvider as IDisposable)?.Dispose();
                }
                
                _logger?.LogInformation("Application shutdown complete");
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Error during application shutdown");
                _staticLogger.Error(ex, "Error during application shutdown");
            }
            finally
            {
                base.OnExit(e);
            }
        }

        #region Exception Handlers

        /// <summary>
        /// Handles unhandled exceptions in the AppDomain
        /// </summary>
        private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            var exception = e.ExceptionObject as Exception;
            var logger = _logger ?? _staticLogger;
            
            if (e.IsTerminating)
            {
                logger.Fatal(exception, "Unhandled exception caused application to terminate");
            }
            else
            {
                logger.Error(exception, "Unhandled exception in AppDomain");
            }
        }

        /// <summary>
        /// Handles unhandled exceptions in the Dispatcher
        /// </summary>
        private void Current_DispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            var logger = _logger ?? _staticLogger;
            logger.Error(e.Exception, "Unhandled exception in Dispatcher");
            
            // Mark as handled to prevent application crash
            e.Handled = true;
            
            // Show error message to user
            MessageBox.Show($"An error occurred: {e.Exception.Message}\n\nCheck the log file for details.",
                "P25Scanner - Error", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        /// <summary>
        /// Handles unobserved task exceptions
        /// </summary>
        private void TaskScheduler_UnobservedTaskException(object sender, UnobservedTaskExceptionEventArgs e)
        {
            var logger = _logger ?? _staticLogger;
            logger.Error(e.Exception, "Unobserved task exception");
            
            // Mark as observed to prevent application crash
            e.SetObserved();
        }

        #endregion
    }
}

