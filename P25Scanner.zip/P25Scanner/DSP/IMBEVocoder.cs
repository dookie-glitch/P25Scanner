using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace P25Scanner.DSP
{
    public class IMBEVocoder : IDisposable
    {
        private const int FRAME_SIZE_BITS = 144;
        private const int NUM_HARMONICS = 56;
        private const float SAMPLE_RATE = 8000.0f;
        private bool _isDisposed;
        private readonly float[] _window;
        private readonly float[] _prevPhases;
        private readonly float[] _magSpectrum;

        public IMBEVocoder()
        {
            _window = CreateHanningWindow(160);
            _prevPhases = new float[NUM_HARMONICS];
            _magSpectrum = new float[NUM_HARMONICS];
        }

        public struct IMBEFrame
        {
            public float Pitch;
            public float[] Magnitudes;
            public float[] Phases;
            public bool IsVoiced;
        }

        public float[] DecodeFrame(byte[] frameData)
        {
            if (frameData == null || frameData.Length * 8 < FRAME_SIZE_BITS)
                return new float[160]; // Return silence if invalid frame

            try
            {
                // Extract parameters from frame
                var frame = DecodeIMBEParameters(frameData);

                // Synthesize speech
                return SynthesizeSpeech(frame);
            }
            catch (Exception)
            {
                return new float[160]; // Return silence on error
            }
        }

        private IMBEFrame DecodeIMBEParameters(byte[] frameData)
        {
            var frame = new IMBEFrame
            {
                Magnitudes = new float[NUM_HARMONICS],
                Phases = new float[NUM_HARMONICS]
            };

            // Extract pitch (7 bits)
            int pitch = ExtractBits(frameData, 0, 7);
            frame.Pitch = 50.0f + pitch * 0.5f;

            // Extract voiced/unvoiced decision (1 bit per harmonic)
            int offset = 7;
            for (int i = 0; i < NUM_HARMONICS; i++)
            {
                bool isVoiced = (frameData[offset / 8] & (1 << (7 - (offset % 8)))) != 0;
                if (isVoiced)
                {
                    // Extract magnitude (6 bits) and phase (6 bits) for voiced harmonics
                    frame.Magnitudes[i] = ExtractBits(frameData, offset + 1, 6) / 63.0f;
                    frame.Phases[i] = ExtractBits(frameData, offset + 7, 6) * (2.0f * (float)Math.PI / 64.0f);
                }
                offset += isVoiced ? 13 : 1;
            }

            return frame;
        }

        private float[] SynthesizeSpeech(IMBEFrame frame)
        {
            var samples = new float[160]; // 20ms at 8kHz
            float timeStep = 1.0f / SAMPLE_RATE;
            int numHarmonics = (int)(SAMPLE_RATE / (2 * frame.Pitch));

            for (int n = 0; n < samples.Length; n++)
            {
                float t = n * timeStep;
                float sample = 0;

                for (int h = 0; h < Math.Min(numHarmonics, NUM_HARMONICS); h++)
                {
                    if (frame.Magnitudes[h] > 0)
                    {
                        float frequency = (h + 1) * frame.Pitch;
                        float phase = frame.Phases[h] + 2 * (float)Math.PI * frequency * t;
                        sample += frame.Magnitudes[h] * (float)Math.Cos(phase);
                    }
                }

                samples[n] = sample * _window[n];
            }

            return samples;
        }

        private float[] CreateHanningWindow(int size)
        {
            var window = new float[size];
            for (int i = 0; i < size; i++)
            {
                window[i] = 0.5f * (1 - (float)Math.Cos(2 * Math.PI * i / (size - 1)));
            }
            return window;
        }

        private static int ExtractBits(byte[] data, int startBit, int length)
        {
            int result = 0;
            int byteIndex = startBit / 8;
            int bitIndex = startBit % 8;

            for (int i = 0; i < length; i++)
            {
                if ((data[byteIndex] & (1 << (7 - bitIndex))) != 0)
                {
                    result |= (1 << (length - 1 - i));
                }

                bitIndex++;
                if (bitIndex == 8)
                {
                    bitIndex = 0;
                    byteIndex++;
                }
            }

            return result;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_isDisposed)
            {
                if (disposing)
                {
                    // Clean up managed resources
                }

                _isDisposed = true;
            }
        }
    }

    public static class IMBEConstants
    {
        public static readonly float[] StandardPitchValues = new float[]
        {
            50.0f, 55.0f, 60.0f, 65.0f, 70.0f, 75.0f, 80.0f, 85.0f,
            90.0f, 95.0f, 100.0f, 105.0f, 110.0f, 115.0f, 120.0f, 125.0f
        };

        public static readonly float[] EnhancementWindow = new float[]
        {
            0.1f, 0.2f, 0.3f, 0.4f, 0.5f, 0.6f, 0.7f, 0.8f, 0.9f, 1.0f,
            0.9f, 0.8f, 0.7f, 0.6f, 0.5f, 0.4f, 0.3f, 0.2f, 0.1f
        };
    }
}

