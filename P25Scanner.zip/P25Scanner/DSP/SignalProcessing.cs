using System;
using System.Numerics;

namespace P25Scanner.DSP
{
    public class SignalProcessing
    {
        public class FirFilter
        {
            private readonly float[] _coefficients;
            private readonly Complex[] _buffer;
            private int _bufferIndex;

            public FirFilter(float[] coefficients)
            {
                _coefficients = coefficients;
                _buffer = new Complex[coefficients.Length];
                _bufferIndex = 0;
            }

            public Complex Process(Complex sample)
            {
                _buffer[_bufferIndex] = sample;
                Complex result = Complex.Zero;

                int index = _bufferIndex;
                for (int i = 0; i < _coefficients.Length; i++)
                {
                    result += _buffer[index] * _coefficients[i];
                    index = (index - 1 + _buffer.Length) % _buffer.Length;
                }

                _bufferIndex = (_bufferIndex + 1) % _buffer.Length;
                return result;
            }

            public Complex[] ProcessBlock(Complex[] samples)
            {
                Complex[] result = new Complex[samples.Length];
                for (int i = 0; i < samples.Length; i++)
                {
                    result[i] = Process(samples[i]);
                }
                return result;
            }
        }

        public class FrequencyCorrector
        {
            private double _phase;
            private readonly double _phaseIncrement;

            public FrequencyCorrector(double frequency, double sampleRate)
            {
                _phase = 0;
                _phaseIncrement = 2 * Math.PI * frequency / sampleRate;
            }

            public Complex[] Correct(Complex[] samples)
            {
                Complex[] result = new Complex[samples.Length];
                for (int i = 0; i < samples.Length; i++)
                {
                    double cosPhase = Math.Cos(_phase);
                    double sinPhase = Math.Sin(_phase);
                    result[i] = new Complex(
                        samples[i].Real * cosPhase - samples[i].Imaginary * sinPhase,
                        samples[i].Real * sinPhase + samples[i].Imaginary * cosPhase);
                    _phase += _phaseIncrement;
                    if (_phase >= 2 * Math.PI)
                        _phase -= 2 * Math.PI;
                }
                return result;
            }

            public void Reset()
            {
                _phase = 0;
            }
        }

        public class SymbolSynchronizer
        {
            private readonly FirFilter _matchedFilter;
            private readonly int _samplesPerSymbol;
            private readonly float _gainMu;
            private readonly float _gainOmega;
            private float _mu;
            private float _omega;
            private Complex _lastSample;

            public SymbolSynchronizer(int samplesPerSymbol, float[] matchedFilterCoeffs)
            {
                _matchedFilter = new FirFilter(matchedFilterCoeffs);
                _samplesPerSymbol = samplesPerSymbol;
                _gainMu = 0.01f;
                _gainOmega = _gainMu * _gainMu / 4;
                _mu = 0;
                _omega = samplesPerSymbol;
                _lastSample = Complex.Zero;
            }

            public (Complex[] symbols, int count) ProcessBlock(Complex[] samples)
            {
                Complex[] filtered = _matchedFilter.ProcessBlock(samples);
                Complex[] symbols = new Complex[samples.Length / _samplesPerSymbol + 1];
                int symbolCount = 0;

                int i = 0;
                while (i < filtered.Length)
                {
                    while (_mu < 1 && i < filtered.Length)
                    {
                        _lastSample = filtered[i++];
                        _mu += _omega;
                    }

                    if (i < filtered.Length)
                    {
                        symbols[symbolCount++] = _lastSample;
                        _mu -= 1;
                    }
                }

                return (symbols, symbolCount);
            }
        }

        public class P25Demodulator
        {
            private readonly int _sampleRate;
            private readonly FrequencyCorrector _frequencyCorrector;
            private readonly FirFilter _lpFilter;
            private readonly SymbolSynchronizer _symbolSync;

            public P25Demodulator(int sampleRate, float[] lpFilterCoeffs, float[] matchedFilterCoeffs)
            {
                _sampleRate = sampleRate;
                _frequencyCorrector = new FrequencyCorrector(0, sampleRate);
                _lpFilter = new FirFilter(lpFilterCoeffs);
                _symbolSync = new SymbolSynchronizer(sampleRate / 4800, matchedFilterCoeffs);
            }

            public Complex[] Demodulate(Complex[] samples, float frequencyOffset)
            {
                // Apply frequency correction
                var corrected = _frequencyCorrector.Correct(samples);

                // Apply low-pass filter
                var filtered = _lpFilter.ProcessBlock(corrected);

                // Symbol timing recovery
                var (symbols, count) = _symbolSync.ProcessBlock(filtered);

                // Return only valid symbols
                var result = new Complex[count];
                Array.Copy(symbols, result, count);
                return result;
            }

            public void Reset()
            {
                _frequencyCorrector.Reset();
            }
        }
    }
}

