using System;
using System.Numerics;
using System.Collections.Generic;

namespace P25Scanner.DSP
{
    public class P25Processing
    {
        public class QPSKDemodulator
        {
            private const float PI_4 = (float)(Math.PI / 4);
            private readonly float[] _constellation = new float[]
            {
                1.0f, 1.0f,    // 00
                -1.0f, 1.0f,   // 01
                -1.0f, -1.0f,  // 10
                1.0f, -1.0f    // 11
            };

            public byte[] DemodulateDibit(Complex[] symbols)
            {
                byte[] dibits = new byte[symbols.Length];
                for (int i = 0; i < symbols.Length; i++)
                {
                    float phase = (float)Math.Atan2(symbols[i].Imaginary, symbols[i].Real);
                    // Normalize phase to 0-2π range
                    if (phase < 0) phase += 2 * (float)Math.PI;
                    
                    // Convert phase to dibit
                    float normalizedPhase = phase / PI_4;
                    int dibitIndex = (int)Math.Round(normalizedPhase) % 8;
                    dibits[i] = (byte)(dibitIndex >> 1);
                }
                return dibits;
            }
        }

        public class FrameSynchronizer
        {
            private const uint FRAME_SYNC_PATTERN = 0x5575F5FF;
            private const int SYNC_LENGTH = 24;
            private readonly Queue<byte> _dibits;
            private uint _shiftRegister;
            private int _syncCount;
            private bool _inSync;

            public FrameSynchronizer()
            {
                _dibits = new Queue<byte>();
                _shiftRegister = 0;
                _syncCount = 0;
                _inSync = false;
            }

            public bool IsInSync => _inSync;

            public class SyncResult
            {
                public bool FrameFound { get; set; }
                public byte[] FrameData { get; set; }
                public int SyncErrors { get; set; }
            }

            public SyncResult ProcessDibits(byte[] dibits)
            {
                foreach (byte dibit in dibits)
                {
                    _dibits.Enqueue(dibit);
                    _shiftRegister = (_shiftRegister << 2) | dibit;

                    if (_dibits.Count >= 384) // P25 frame size
                    {
                        int errors = CountSyncErrors(_shiftRegister);
                        if (errors <= 3) // Allow up to 3 bit errors
                        {
                            _inSync = true;
                            _syncCount++;
                            byte[] frameData = _dibits.ToArray();
                            _dibits.Clear();
                            return new SyncResult
                            {
                                FrameFound = true,
                                FrameData = frameData,
                                SyncErrors = errors
                            };
                        }

                        _dibits.Dequeue();
                    }
                }

                return new SyncResult { FrameFound = false };
            }

            private int CountSyncErrors(uint pattern)
            {
                uint xor = pattern ^ FRAME_SYNC_PATTERN;
                int errors = 0;
                while (xor != 0)
                {
                    errors += (int)(xor & 1);
                    xor >>= 1;
                }
                return errors;
            }
        }

        public class P25DataUnit
        {
            public enum DataUnitType
            {
                Header,
                Voice,
                Data,
                Unknown
            }

            public DataUnitType Type { get; private set; }
            public int NAC { get; private set; }
            public int DUID { get; private set; }
            public int TalkgroupId { get; private set; }
            public int SourceId { get; private set; }
            public byte[] Data { get; private set; }

            public static P25DataUnit Parse(byte[] frameData)
            {
                if (frameData == null || frameData.Length < 72)
                    return null;

                var dataUnit = new P25DataUnit();

                // Extract NAC (12 bits)
                dataUnit.NAC = ExtractBits(frameData, 0, 12);

                // Extract DUID (4 bits)
                dataUnit.DUID = ExtractBits(frameData, 12, 4);

                // Determine data unit type
                dataUnit.Type = dataUnit.DUID switch
                {
                    0x0 => DataUnitType.Header,
                    0x3 => DataUnitType.Voice,
                    0x7 => DataUnitType.Data,
                    _ => DataUnitType.Unknown
                };

                // Extract additional fields based on type
                if (dataUnit.Type == DataUnitType.Voice)
                {
                    dataUnit.TalkgroupId = ExtractBits(frameData, 16, 16);
                    dataUnit.SourceId = ExtractBits(frameData, 32, 24);
                    
                    // Extract voice data
                    int dataLength = frameData.Length - 72;
                    dataUnit.Data = new byte[dataLength];
                    Array.Copy(frameData, 72, dataUnit.Data, 0, dataLength);
                }

                return dataUnit;
            }

            private static int ExtractBits(byte[] data, int startBit, int length)
            {
                int result = 0;
                int byteIndex = startBit / 8;
                int bitIndex = startBit % 8;

                for (int i = 0; i < length; i++)
                {
                    if ((data[byteIndex] & (1 << (7 - bitIndex))) != 0)
                    {
                        result |= (1 << (length - 1 - i));
                    }

                    bitIndex++;
                    if (bitIndex == 8)
                    {
                        bitIndex = 0;
                        byteIndex++;
                    }
                }

                return result;
            }
        }

        public class VoiceDecoder
        {
            private const int SUPERFRAME_SIZE = 1728; // 9 voice frames
            private readonly float[] _audioBuffer;
            private int _bufferIndex;

            public VoiceDecoder()
            {
                _audioBuffer = new float[SUPERFRAME_SIZE];
                _bufferIndex = 0;
            }

            public float[] DecodeVoiceFrame(byte[] frameData)
            {
                // TODO: Implement IMBE voice decoding
                // This is a placeholder that generates silence
                var audioSamples = new float[160]; // 20ms at 8kHz
                return audioSamples;
            }

            public void Reset()
            {
                _bufferIndex = 0;
            }
        }
    }
}

