using System;
using System.Numerics;
using System.Collections.Generic;

namespace P25Scanner.DSP
{
    public class SignalAnalyzer
    {
        private const int FFT_SIZE = 2048;
        private const float MIN_SNR_DB = 6.0f;
        private readonly float[] _fftWindow;
        private readonly Queue<float> _snrHistory;
        private readonly Queue<float> _powerHistory;
        private Complex[] _fftBuffer;

        public class SignalMetrics
        {
            public float SNR { get; set; }           // Signal-to-Noise Ratio in dB
            public float SignalPower { get; set; }   // Signal power in dB
            public float FreqOffset { get; set; }    // Frequency offset in Hz
            public float BER { get; set; }           // Bit Error Rate estimation
            public bool IsValidSignal { get; set; }  // Signal validity flag
        }

        public SignalAnalyzer()
        {
            _fftWindow = CreateBlackmanHarrisWindow(FFT_SIZE);
            _fftBuffer = new Complex[FFT_SIZE];
            _snrHistory = new Queue<float>(10);  // 10-sample history
            _powerHistory = new Queue<float>(10);
        }

        public SignalMetrics AnalyzeSignal(Complex[] samples, uint sampleRate)
        {
            var metrics = new SignalMetrics();

            try
            {
                // Calculate power spectrum
                var spectrum = CalculatePowerSpectrum(samples);

                // Find signal peak and noise floor
                (float peakPower, float noiseFloor, int peakBin) = FindSignalPeak(spectrum);

                // Calculate SNR
                metrics.SNR = 10 * (float)Math.Log10(peakPower / noiseFloor);
                _snrHistory.Enqueue(metrics.SNR);
                if (_snrHistory.Count > 10)
                    _snrHistory.Dequeue();

                // Calculate signal power
                metrics.SignalPower = 10 * (float)Math.Log10(peakPower);
                _powerHistory.Enqueue(metrics.SignalPower);
                if (_powerHistory.Count > 10)
                    _powerHistory.Dequeue();

                // Estimate frequency offset
                metrics.FreqOffset = (peakBin - FFT_SIZE / 2) * (float)sampleRate / FFT_SIZE;

                // Estimate BER based on SNR
                metrics.BER = EstimateBER(metrics.SNR);

                // Determine if signal is valid
                metrics.IsValidSignal = IsSignalValid(metrics);
            }
            catch (Exception)
            {
                // Return default metrics on error
                metrics.IsValidSignal = false;
            }

            return metrics;
        }

        private float[] CalculatePowerSpectrum(Complex[] samples)
        {
            int length = Math.Min(samples.Length, FFT_SIZE);
            var spectrum = new float[FFT_SIZE];

            // Apply window and copy to FFT buffer
            for (int i = 0; i < length; i++)
            {
                _fftBuffer[i] = samples[i] * _fftWindow[i];
            }

            // Clear remaining buffer if any
            for (int i = length; i < FFT_SIZE; i++)
            {
                _fftBuffer[i] = Complex.Zero;
            }

            // Perform FFT
            FastFourierTransform(_fftBuffer);

            // Calculate power spectrum
            for (int i = 0; i < FFT_SIZE; i++)
            {
                spectrum[i] = (float)(Math.Pow(_fftBuffer[i].Real, 2) + Math.Pow(_fftBuffer[i].Imaginary, 2));
            }

            return spectrum;
        }

        private (float peakPower, float noiseFloor, int peakBin) FindSignalPeak(float[] spectrum)
        {
            float maxPower = float.MinValue;
            int peakBin = 0;
            float totalPower = 0;

            // Find peak
            for (int i = 0; i < spectrum.Length; i++)
            {
                if (spectrum[i] > maxPower)
                {
                    maxPower = spectrum[i];
                    peakBin = i;
                }
                totalPower += spectrum[i];
            }

            // Calculate noise floor (excluding signal region)
            float noiseFloor = 0;
            int count = 0;
            int exclusionRange = 20; // Bins to exclude around peak

            for (int i = 0; i < spectrum.Length; i++)
            {
                if (Math.Abs(i - peakBin) > exclusionRange)
                {
                    noiseFloor += spectrum[i];
                    count++;
                }
            }

            noiseFloor /= count; // Average noise floor
            return (maxPower, noiseFloor, peakBin);
        }

        private float EstimateBER(float snr)
        {
            // Theoretical BER for QPSK with given SNR
            float snrLinear = (float)Math.Pow(10, snr / 10);
            return (float)SpecialFunctions.Erfc(Math.Sqrt(snrLinear)) / 2;
        }

        private bool IsSignalValid(SignalMetrics metrics)
        {
            // Check if SNR is above minimum threshold
            if (metrics.SNR < MIN_SNR_DB)
                return false;

            // Check if frequency offset is within acceptable range
            if (Math.Abs(metrics.FreqOffset) > 2000) // 2 kHz
                return false;

            // Check if BER is acceptable
            if (metrics.BER > 0.1) // 10% BER threshold
                return false;

            return true;
        }

        private float[] CreateBlackmanHarrisWindow(int size)
        {
            var window = new float[size];
            const float a0 = 0.35875f;
            const float a1 = 0.48829f;
            const float a2 = 0.14128f;
            const float a3 = 0.01168f;

            for (int i = 0; i < size; i++)
            {
                float x = 2 * MathF.PI * i / (size - 1);
                window[i] = a0 - a1 * MathF.Cos(x) + a2 * MathF.Cos(2 * x) - a3 * MathF.Cos(3 * x);
            }

            return window;
        }

        private void FastFourierTransform(Complex[] buffer)
        {
            int n = buffer.Length;
            if (n <= 1) return;

            // Separate even and odd elements
            Complex[] even = new Complex[n / 2];
            Complex[] odd = new Complex[n / 2];
            for (int i = 0; i < n / 2; i++)
            {
                even[i] = buffer[2 * i];
                odd[i] = buffer[2 * i + 1];
            }

            // Recursive FFT on even and odd parts
            FastFourierTransform(even);
            FastFourierTransform(odd);

            // Combine results
            for (int k = 0; k < n / 2; k++)
            {
                float t = (float)(k * 2 * Math.PI / n);
                Complex exp = new Complex(Math.Cos(t), -Math.Sin(t));
                Complex term = exp * odd[k];
                buffer[k] = even[k] + term;
                buffer[k + n / 2] = even[k] - term;
            }
        }
    }

    internal static class SpecialFunctions
    {
        public static double Erfc(double x)
        {
            // Approximation of the complementary error function
            // Accuracy: about 7 decimal places
            double t = 1.0 / (1.0 + 0.3275911 * x);
            double sum = t * (0.254829592 + t * (-0.284496736 + t * (1.421413741
                + t * (-1.453152027 + t * 1.061405429))));
            return sum * Math.Exp(-x * x);
        }
    }
}

